%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Part of the replication package for the paper
%   "Marginal Effects for Probit and Tobit with Endogeneity"
%   by Kirill S. Evdokimov, Ilze Kalnina, and Andrei Zeleneev.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Replicate Figure 1:
disp(datestr(now(), "HH:MM:SS") + " : Starting MC");
MC_replicate_main;

% Replicates Tables 1-2
disp(datestr(now(), "HH:MM:SS") + " : Starting Tobit Empirical");
clear
bProbit = 0;
xobit_empirical_application;

% Replicates Table 3
disp(datestr(now(), "HH:MM:SS") + " : Starting Probit Empirical");
clear
bProbit = 1;
xobit_empirical_application;

disp(datestr(now(), "HH:MM:SS") + " : Done with Empirical");

% Optional codes (unucomment to run)

% Uncomment the following to recreate NLSY/nlsy97_empirical.csv from the raw NLSY data in NLSY/nlsy97_raw/
% disp(datestr(now(), "HH:MM:SS") + " : Starting make_dataset.m");
% make_dataset; 

% Uncomment the following to recreate file stored_grid_CV_for_max_1-sided.mat -- 1-sided critical values for the maximium of bivariate Normal
% disp(datestr(now(), "HH:MM:SS") + " : Starting make_stored_grid_CV_for_max.m");
% make_stored_grid_CV_for_max;

disp(datestr(now(), "HH:MM:SS") + " : Done");
