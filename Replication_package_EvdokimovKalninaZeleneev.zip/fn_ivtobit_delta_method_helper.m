%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Part of the replication package for the paper
%   "Marginal Effects for Probit and Tobit with Endogeneity"
%   by Kirill S. Evdokimov, Ilze Kalnina, and Andrei Zeleneev.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function temp_f = fn_ivtobit_delta_method_helper(th1,gam,sUgV,sV)
%FN_IVTOBIT_DELTA_METHOD_HELPER
%    TEMP_F = FN_IVTOBIT_DELTA_METHOD_HELPER(TH1,GAM,sUgV,sV)
%
%    This function was generated using the Symbolic Math Toolbox version 9.1.

t2 = gam.^2;
t3 = sUgV.^2;
t4 = sV.^2;
t5 = th1.^2;
t6 = gam.*t4.*th1;
t7 = gam.*t4.*2.0;
t8 = sV.*t2.*2.0;
t9 = sV.*t5.*2.0;
t10 = t4.*th1.*2.0;
t11 = t4.*t5;
t13 = t2.*t4;
t12 = t6.*2.0;
t14 = t3+t13;
t15 = t7+t10;
t16 = 1.0./sqrt(t14);
t17 = t6+t14;
t19 = t11+t12+t14;
t18 = t17.^2;
t20 = 1.0./t19;
t21 = t20.^2;
t22 = t15.*t18.*t21;
t23 = -t22;
temp_f = reshape([zeros(size(sV,1),1),gam.*t4.*t16,sUgV.*t16,sV.*t2.*t16,t23+t7.*t17.*t20,t23+t17.*t20.*(t7+t4.*th1).*2.0,sUgV.*t17.*t20.*4.0-sUgV.*t18.*t21.*2.0,-t18.*t21.*(t8+t9+gam.*sV.*th1.*4.0)+t17.*t20.*(t8+gam.*sV.*th1.*2.0).*2.0,-t10,t7,sUgV.*2.0,t8-t9],[4,3]);

