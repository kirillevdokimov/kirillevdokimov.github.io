
label define vlE0013801 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013801 vlE0013801

label define vlE0013802 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013802 vlE0013802

label define vlE0013803 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013803 vlE0013803

label define vlE0013804 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013804 vlE0013804

label define vlE0013805 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013805 vlE0013805

label define vlE0013806 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013806 vlE0013806

label define vlE0013807 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013807 vlE0013807

label define vlE0013808 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013808 vlE0013808

label define vlE0013809 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013809 vlE0013809

label define vlE0013810 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013810 vlE0013810

label define vlE0013811 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013811 vlE0013811

label define vlE0013812 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013812 vlE0013812

label define vlE0013813 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013813 vlE0013813

label define vlE0013814 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013814 vlE0013814

label define vlE0013815 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013815 vlE0013815

label define vlE0013816 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013816 vlE0013816

label define vlE0013817 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013817 vlE0013817

label define vlE0013818 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013818 vlE0013818

label define vlE0013819 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013819 vlE0013819

label define vlE0013820 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013820 vlE0013820

label define vlE0013821 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013821 vlE0013821

label define vlE0013822 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013822 vlE0013822

label define vlE0013823 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013823 vlE0013823

label define vlE0013824 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013824 vlE0013824

label define vlE0013825 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013825 vlE0013825

label define vlE0013826 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013826 vlE0013826

label define vlE0013827 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013827 vlE0013827

label define vlE0013828 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013828 vlE0013828

label define vlE0013829 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013829 vlE0013829

label define vlE0013830 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013830 vlE0013830

label define vlE0013831 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013831 vlE0013831

label define vlE0013832 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013832 vlE0013832

label define vlE0013833 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013833 vlE0013833

label define vlE0013834 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013834 vlE0013834

label define vlE0013835 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013835 vlE0013835

label define vlE0013836 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013836 vlE0013836

label define vlE0013837 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013837 vlE0013837

label define vlE0013838 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013838 vlE0013838

label define vlE0013839 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013839 vlE0013839

label define vlE0013840 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013840 vlE0013840

label define vlE0013841 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013841 vlE0013841

label define vlE0013842 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013842 vlE0013842

label define vlE0013843 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013843 vlE0013843

label define vlE0013844 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013844 vlE0013844

label define vlE0013845 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013845 vlE0013845

label define vlE0013846 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013846 vlE0013846

label define vlE0013847 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013847 vlE0013847

label define vlE0013848 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013848 vlE0013848

label define vlE0013849 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013849 vlE0013849

label define vlE0013850 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013850 vlE0013850

label define vlE0013851 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013851 vlE0013851

label define vlE0013852 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013852 vlE0013852

label define vlE0013901 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013901 vlE0013901

label define vlE0013902 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013902 vlE0013902

label define vlE0013903 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013903 vlE0013903

label define vlE0013904 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013904 vlE0013904

label define vlE0013905 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013905 vlE0013905

label define vlE0013906 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013906 vlE0013906

label define vlE0013907 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013907 vlE0013907

label define vlE0013908 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013908 vlE0013908

label define vlE0013909 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013909 vlE0013909

label define vlE0013910 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013910 vlE0013910

label define vlE0013911 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013911 vlE0013911

label define vlE0013912 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013912 vlE0013912

label define vlE0013913 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013913 vlE0013913

label define vlE0013914 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013914 vlE0013914

label define vlE0013915 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013915 vlE0013915

label define vlE0013916 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013916 vlE0013916

label define vlE0013917 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013917 vlE0013917

label define vlE0013918 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013918 vlE0013918

label define vlE0013919 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013919 vlE0013919

label define vlE0013920 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013920 vlE0013920

label define vlE0013921 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013921 vlE0013921

label define vlE0013922 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013922 vlE0013922

label define vlE0013923 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013923 vlE0013923

label define vlE0013924 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013924 vlE0013924

label define vlE0013925 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013925 vlE0013925

label define vlE0013926 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013926 vlE0013926

label define vlE0013927 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013927 vlE0013927

label define vlE0013928 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013928 vlE0013928

label define vlE0013929 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013929 vlE0013929

label define vlE0013930 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013930 vlE0013930

label define vlE0013931 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013931 vlE0013931

label define vlE0013932 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013932 vlE0013932

label define vlE0013933 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013933 vlE0013933

label define vlE0013934 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013934 vlE0013934

label define vlE0013935 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013935 vlE0013935

label define vlE0013936 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013936 vlE0013936

label define vlE0013937 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013937 vlE0013937

label define vlE0013938 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013938 vlE0013938

label define vlE0013939 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013939 vlE0013939

label define vlE0013940 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013940 vlE0013940

label define vlE0013941 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013941 vlE0013941

label define vlE0013942 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013942 vlE0013942

label define vlE0013943 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013943 vlE0013943

label define vlE0013944 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013944 vlE0013944

label define vlE0013945 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013945 vlE0013945

label define vlE0013946 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013946 vlE0013946

label define vlE0013947 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013947 vlE0013947

label define vlE0013948 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013948 vlE0013948

label define vlE0013949 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013949 vlE0013949

label define vlE0013950 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013950 vlE0013950

label define vlE0013951 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013951 vlE0013951

label define vlE0013952 0 "0: No information reported to account for week; job dates indeterminate"  1 "1: Not associated with an employer, not actively searching for an employer job"  2 "2: Not working (unemployment vs. out of labor force cannot be determined)"  3 "3: Associated with an employer, periods not working for the employer are missing"  4 "4: Unemployed"  5 "5: Out of the labor force"  6 "6: Active military service"  9701 "9701 TO 202199: Employer on roster (see YEMP_UID)" 
label values E0013952 vlE0013952

label define vlE0023801 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023801 vlE0023801

label define vlE0023802 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023802 vlE0023802

label define vlE0023803 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023803 vlE0023803

label define vlE0023804 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023804 vlE0023804

label define vlE0023805 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023805 vlE0023805

label define vlE0023806 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023806 vlE0023806

label define vlE0023807 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023807 vlE0023807

label define vlE0023808 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023808 vlE0023808

label define vlE0023809 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023809 vlE0023809

label define vlE0023810 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023810 vlE0023810

label define vlE0023811 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023811 vlE0023811

label define vlE0023812 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023812 vlE0023812

label define vlE0023813 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023813 vlE0023813

label define vlE0023814 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023814 vlE0023814

label define vlE0023815 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023815 vlE0023815

label define vlE0023816 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023816 vlE0023816

label define vlE0023817 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023817 vlE0023817

label define vlE0023818 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023818 vlE0023818

label define vlE0023819 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023819 vlE0023819

label define vlE0023820 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023820 vlE0023820

label define vlE0023821 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023821 vlE0023821

label define vlE0023822 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023822 vlE0023822

label define vlE0023823 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023823 vlE0023823

label define vlE0023824 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023824 vlE0023824

label define vlE0023825 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023825 vlE0023825

label define vlE0023826 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023826 vlE0023826

label define vlE0023827 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023827 vlE0023827

label define vlE0023828 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023828 vlE0023828

label define vlE0023829 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023829 vlE0023829

label define vlE0023830 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023830 vlE0023830

label define vlE0023831 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023831 vlE0023831

label define vlE0023832 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023832 vlE0023832

label define vlE0023833 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023833 vlE0023833

label define vlE0023834 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023834 vlE0023834

label define vlE0023835 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023835 vlE0023835

label define vlE0023836 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023836 vlE0023836

label define vlE0023837 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023837 vlE0023837

label define vlE0023838 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023838 vlE0023838

label define vlE0023839 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023839 vlE0023839

label define vlE0023840 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023840 vlE0023840

label define vlE0023841 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023841 vlE0023841

label define vlE0023842 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023842 vlE0023842

label define vlE0023843 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023843 vlE0023843

label define vlE0023844 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023844 vlE0023844

label define vlE0023845 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023845 vlE0023845

label define vlE0023846 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023846 vlE0023846

label define vlE0023847 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023847 vlE0023847

label define vlE0023848 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023848 vlE0023848

label define vlE0023849 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023849 vlE0023849

label define vlE0023850 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023850 vlE0023850

label define vlE0023851 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023851 vlE0023851

label define vlE0023852 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023852 vlE0023852

label define vlE0023901 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023901 vlE0023901

label define vlE0023902 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023902 vlE0023902

label define vlE0023903 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023903 vlE0023903

label define vlE0023904 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023904 vlE0023904

label define vlE0023905 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023905 vlE0023905

label define vlE0023906 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023906 vlE0023906

label define vlE0023907 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023907 vlE0023907

label define vlE0023908 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023908 vlE0023908

label define vlE0023909 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023909 vlE0023909

label define vlE0023910 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023910 vlE0023910

label define vlE0023911 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023911 vlE0023911

label define vlE0023912 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023912 vlE0023912

label define vlE0023913 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023913 vlE0023913

label define vlE0023914 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023914 vlE0023914

label define vlE0023915 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023915 vlE0023915

label define vlE0023916 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023916 vlE0023916

label define vlE0023917 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023917 vlE0023917

label define vlE0023918 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023918 vlE0023918

label define vlE0023919 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023919 vlE0023919

label define vlE0023920 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023920 vlE0023920

label define vlE0023921 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023921 vlE0023921

label define vlE0023922 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023922 vlE0023922

label define vlE0023923 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023923 vlE0023923

label define vlE0023924 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023924 vlE0023924

label define vlE0023925 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023925 vlE0023925

label define vlE0023926 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023926 vlE0023926

label define vlE0023927 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023927 vlE0023927

label define vlE0023928 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023928 vlE0023928

label define vlE0023929 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023929 vlE0023929

label define vlE0023930 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023930 vlE0023930

label define vlE0023931 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023931 vlE0023931

label define vlE0023932 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023932 vlE0023932

label define vlE0023933 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023933 vlE0023933

label define vlE0023934 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023934 vlE0023934

label define vlE0023935 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023935 vlE0023935

label define vlE0023936 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023936 vlE0023936

label define vlE0023937 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023937 vlE0023937

label define vlE0023938 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023938 vlE0023938

label define vlE0023939 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023939 vlE0023939

label define vlE0023940 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023940 vlE0023940

label define vlE0023941 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023941 vlE0023941

label define vlE0023942 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023942 vlE0023942

label define vlE0023943 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023943 vlE0023943

label define vlE0023944 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023944 vlE0023944

label define vlE0023945 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023945 vlE0023945

label define vlE0023946 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023946 vlE0023946

label define vlE0023947 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023947 vlE0023947

label define vlE0023948 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023948 vlE0023948

label define vlE0023949 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023949 vlE0023949

label define vlE0023950 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023950 vlE0023950

label define vlE0023951 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023951 vlE0023951

label define vlE0023952 0 "0: Hours"  1 "1 TO 19: Hours"  20 "20 TO 34: Hours"  35 "35 TO 44: Hours"  45 "45 TO 54: Hours"  55 "55 TO 64: Hours"  65 "65 TO 168: Hours"  169 "169 TO 500: Hours" 
label values E0023952 vlE0023952

label define vlE0213501 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213501 vlE0213501

label define vlE0213502 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213502 vlE0213502

label define vlE0213503 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213503 vlE0213503

label define vlE0213504 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213504 vlE0213504

label define vlE0213505 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213505 vlE0213505

label define vlE0213506 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213506 vlE0213506

label define vlE0213507 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213507 vlE0213507

label define vlE0213508 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213508 vlE0213508

label define vlE0213509 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213509 vlE0213509

label define vlE0213510 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213510 vlE0213510

label define vlE0213511 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0213511 vlE0213511

label define vlE0233501 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233501 vlE0233501

label define vlE0233502 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233502 vlE0233502

label define vlE0233503 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233503 vlE0233503

label define vlE0233504 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233504 vlE0233504

label define vlE0233505 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233505 vlE0233505

label define vlE0233506 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233506 vlE0233506

label define vlE0233507 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233507 vlE0233507

label define vlE0233508 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233508 vlE0233508

label define vlE0233509 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233509 vlE0233509

label define vlE0233510 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233510 vlE0233510

label define vlE0233511 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E0233511 vlE0233511

label define vlE1013501 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1013501 vlE1013501

label define vlE1013502 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1013502 vlE1013502

label define vlE1013503 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1013503 vlE1013503

label define vlE1013504 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1013504 vlE1013504

label define vlE1013505 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1013505 vlE1013505

label define vlE1013506 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1013506 vlE1013506

label define vlE1013507 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1013507 vlE1013507

label define vlE1013508 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1013508 vlE1013508

label define vlE1013509 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1013509 vlE1013509

label define vlE1013510 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1013510 vlE1013510

label define vlE1023501 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1023501 vlE1023501

label define vlE1023502 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1023502 vlE1023502

label define vlE1023503 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1023503 vlE1023503

label define vlE1023504 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1023504 vlE1023504

label define vlE1023505 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1023505 vlE1023505

label define vlE1033501 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1033501 vlE1033501

label define vlE1033502 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1033502 vlE1033502

label define vlE1033503 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1033503 vlE1033503

label define vlE1043501 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1043501 vlE1043501

label define vlE1043502 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1043502 vlE1043502

label define vlE1043503 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E1043503 vlE1043503

label define vlE3013501 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3013501 vlE3013501

label define vlE3013502 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3013502 vlE3013502

label define vlE3013503 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3013503 vlE3013503

label define vlE3013504 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3013504 vlE3013504

label define vlE3013505 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3013505 vlE3013505

label define vlE3013506 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3013506 vlE3013506

label define vlE3013507 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3013507 vlE3013507

label define vlE3013508 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3013508 vlE3013508

label define vlE3013509 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3013509 vlE3013509

label define vlE3013510 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3013510 vlE3013510

label define vlE3023501 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3023501 vlE3023501

label define vlE3023502 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3023502 vlE3023502

label define vlE3023503 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3023503 vlE3023503

label define vlE3023504 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3023504 vlE3023504

label define vlE3023505 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3023505 vlE3023505

label define vlE3033501 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3033501 vlE3033501

label define vlE3033502 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3033502 vlE3033502

label define vlE3033503 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3033503 vlE3033503

label define vlE3043501 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3043501 vlE3043501

label define vlE3043502 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3043502 vlE3043502

label define vlE3043503 0 "0: Weeks"  1 "1 TO 13: Weeks"  14 "14 TO 26: Weeks"  27 "27 TO 39: Weeks"  40 "40 TO 48: Weeks"  49 "49 TO 51: Weeks"  52 "52 TO 53: Weeks" 
label values E3043503 vlE3043503

label define vlE6413901 1 "Yes"  0 "No" 
label values E6413901 vlE6413901

label define vlE6413902 1 "Yes"  0 "No" 
label values E6413902 vlE6413902

label define vlE6413903 1 "Yes"  0 "No" 
label values E6413903 vlE6413903

label define vlE6413904 1 "Yes"  0 "No" 
label values E6413904 vlE6413904

label define vlE6413905 1 "Yes"  0 "No" 
label values E6413905 vlE6413905

label define vlE6413906 1 "Yes"  0 "No" 
label values E6413906 vlE6413906

label define vlE6413907 1 "Yes"  0 "No" 
label values E6413907 vlE6413907

label define vlE6413908 1 "Yes"  0 "No" 
label values E6413908 vlE6413908

label define vlE6413909 1 "Yes"  0 "No" 
label values E6413909 vlE6413909

label define vlE6413910 1 "Yes"  0 "No" 
label values E6413910 vlE6413910

label define vlE6413911 1 "Yes"  0 "No" 
label values E6413911 vlE6413911

label define vlE6413912 1 "Yes"  0 "No" 
label values E6413912 vlE6413912

label define vlE6443501 0 "0: Months"  1 "1 TO 24: Months"  25 "25 TO 49: Months"  50 "50 TO 74: Months"  75 "75 TO 99: Months"  100 "100 TO 124: Months"  125 "125 TO 149: Months"  150 "150 TO 174: Months"  175 "175 TO 199: Months"  200 "200 TO 224: Months"  225 "225 TO 249: Months"  250 "250 TO 274: Months"  275 "275 TO 299: Months"  300 "300 TO 324: Months"  325 "325 TO 349: Months"  350 "350 TO 399: Months"  400 "400 TO 449: Months"  450 "450 TO 499: Months"  500 "500 TO 549: Months"  550 "550 TO 599: Months"  600 "600 TO 649: Months" 
label values E6443501 vlE6443501

label define vlE6443502 0 "0: Months"  1 "1 TO 24: Months"  25 "25 TO 49: Months"  50 "50 TO 74: Months"  75 "75 TO 99: Months"  100 "100 TO 124: Months"  125 "125 TO 149: Months"  150 "150 TO 174: Months"  175 "175 TO 199: Months"  200 "200 TO 224: Months"  225 "225 TO 249: Months"  250 "250 TO 274: Months"  275 "275 TO 299: Months"  300 "300 TO 324: Months"  325 "325 TO 349: Months"  350 "350 TO 399: Months"  400 "400 TO 449: Months"  450 "450 TO 499: Months"  500 "500 TO 549: Months"  550 "550 TO 599: Months"  600 "600 TO 649: Months" 
label values E6443502 vlE6443502

label define vlE6443503 0 "0: Months"  1 "1 TO 24: Months"  25 "25 TO 49: Months"  50 "50 TO 74: Months"  75 "75 TO 99: Months"  100 "100 TO 124: Months"  125 "125 TO 149: Months"  150 "150 TO 174: Months"  175 "175 TO 199: Months"  200 "200 TO 224: Months"  225 "225 TO 249: Months"  250 "250 TO 274: Months"  275 "275 TO 299: Months"  300 "300 TO 324: Months"  325 "325 TO 349: Months"  350 "350 TO 399: Months"  400 "400 TO 449: Months"  450 "450 TO 499: Months"  500 "500 TO 549: Months"  550 "550 TO 599: Months"  600 "600 TO 649: Months" 
label values E6443503 vlE6443503

label define vlE6443504 0 "0: Months"  1 "1 TO 24: Months"  25 "25 TO 49: Months"  50 "50 TO 74: Months"  75 "75 TO 99: Months"  100 "100 TO 124: Months"  125 "125 TO 149: Months"  150 "150 TO 174: Months"  175 "175 TO 199: Months"  200 "200 TO 224: Months"  225 "225 TO 249: Months"  250 "250 TO 274: Months"  275 "275 TO 299: Months"  300 "300 TO 324: Months"  325 "325 TO 349: Months"  350 "350 TO 399: Months"  400 "400 TO 449: Months"  450 "450 TO 499: Months"  500 "500 TO 549: Months"  550 "550 TO 599: Months"  600 "600 TO 649: Months" 
label values E6443504 vlE6443504

label define vlE6453501 0 "0: Months"  1 "1 TO 24: Months"  25 "25 TO 49: Months"  50 "50 TO 74: Months"  75 "75 TO 99: Months"  100 "100 TO 124: Months"  125 "125 TO 149: Months"  150 "150 TO 174: Months"  175 "175 TO 199: Months"  200 "200 TO 224: Months"  225 "225 TO 249: Months"  250 "250 TO 274: Months"  275 "275 TO 299: Months"  300 "300 TO 324: Months"  325 "325 TO 349: Months"  350 "350 TO 399: Months"  400 "400 TO 449: Months"  450 "450 TO 499: Months"  500 "500 TO 549: Months"  550 "550 TO 599: Months"  600 "600 TO 649: Months" 
label values E6453501 vlE6453501

label define vlE6453502 0 "0: Months"  1 "1 TO 24: Months"  25 "25 TO 49: Months"  50 "50 TO 74: Months"  75 "75 TO 99: Months"  100 "100 TO 124: Months"  125 "125 TO 149: Months"  150 "150 TO 174: Months"  175 "175 TO 199: Months"  200 "200 TO 224: Months"  225 "225 TO 249: Months"  250 "250 TO 274: Months"  275 "275 TO 299: Months"  300 "300 TO 324: Months"  325 "325 TO 349: Months"  350 "350 TO 399: Months"  400 "400 TO 449: Months"  450 "450 TO 499: Months"  500 "500 TO 549: Months"  550 "550 TO 599: Months"  600 "600 TO 649: Months" 
label values E6453502 vlE6453502

label define vlE6453503 0 "0: Months"  1 "1 TO 24: Months"  25 "25 TO 49: Months"  50 "50 TO 74: Months"  75 "75 TO 99: Months"  100 "100 TO 124: Months"  125 "125 TO 149: Months"  150 "150 TO 174: Months"  175 "175 TO 199: Months"  200 "200 TO 224: Months"  225 "225 TO 249: Months"  250 "250 TO 274: Months"  275 "275 TO 299: Months"  300 "300 TO 324: Months"  325 "325 TO 349: Months"  350 "350 TO 399: Months"  400 "400 TO 449: Months"  450 "450 TO 499: Months"  500 "500 TO 549: Months"  550 "550 TO 599: Months"  600 "600 TO 649: Months" 
label values E6453503 vlE6453503

label define vlE6453504 0 "0: Months"  1 "1 TO 24: Months"  25 "25 TO 49: Months"  50 "50 TO 74: Months"  75 "75 TO 99: Months"  100 "100 TO 124: Months"  125 "125 TO 149: Months"  150 "150 TO 174: Months"  175 "175 TO 199: Months"  200 "200 TO 224: Months"  225 "225 TO 249: Months"  250 "250 TO 274: Months"  275 "275 TO 299: Months"  300 "300 TO 324: Months"  325 "325 TO 349: Months"  350 "350 TO 399: Months"  400 "400 TO 449: Months"  450 "450 TO 499: Months"  500 "500 TO 549: Months"  550 "550 TO 599: Months"  600 "600 TO 649: Months" 
label values E6453504 vlE6453504

label define vlE6473501 1 "Respondent reported participation dates"  2 "Start month imputed"  3 "Start month and year imputed"  4 "Stop month imputed"  5 "Stop month and year imputed"  6 "Start and stop dates imputed"  7 "Unknown receipt gap dates" 
label values E6473501 vlE6473501

label define vlE6473502 1 "Respondent reported participation dates"  2 "Start month imputed"  3 "Start month and year imputed"  4 "Stop month imputed"  5 "Stop month and year imputed"  6 "Start and stop dates imputed"  7 "Unknown receipt gap dates" 
label values E6473502 vlE6473502

label define vlE6473503 1 "Respondent reported participation dates"  2 "Start month imputed"  3 "Start month and year imputed"  4 "Stop month imputed"  5 "Stop month and year imputed"  6 "Start and stop dates imputed"  7 "Unknown receipt gap dates" 
label values E6473503 vlE6473503

label define vlE6473504 1 "Respondent reported participation dates"  2 "Start month imputed"  3 "Start month and year imputed"  4 "Stop month imputed"  5 "Stop month and year imputed"  6 "Start and stop dates imputed"  7 "Unknown receipt gap dates" 
label values E6473504 vlE6473504

label define vlE7013801 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013801 vlE7013801

label define vlE7013802 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013802 vlE7013802

label define vlE7013803 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013803 vlE7013803

label define vlE7013804 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013804 vlE7013804

label define vlE7013805 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013805 vlE7013805

label define vlE7013806 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013806 vlE7013806

label define vlE7013807 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013807 vlE7013807

label define vlE7013808 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013808 vlE7013808

label define vlE7013809 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013809 vlE7013809

label define vlE7013810 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013810 vlE7013810

label define vlE7013811 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013811 vlE7013811

label define vlE7013812 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013812 vlE7013812

label define vlE7013901 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013901 vlE7013901

label define vlE7013902 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013902 vlE7013902

label define vlE7013903 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013903 vlE7013903

label define vlE7013904 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013904 vlE7013904

label define vlE7013905 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013905 vlE7013905

label define vlE7013906 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013906 vlE7013906

label define vlE7013907 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013907 vlE7013907

label define vlE7013908 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013908 vlE7013908

label define vlE7013909 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013909 vlE7013909

label define vlE7013910 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013910 vlE7013910

label define vlE7013911 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013911 vlE7013911

label define vlE7013912 0 "Never Married, Not Cohabitating"  1 "Never Married, Cohabiting"  2 "Married"  3 "Legally Separated"  4 "Divorced"  5 "Widowed" 
label values E7013912 vlE7013912

label define vlE7023801 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023801 vlE7023801

label define vlE7023802 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023802 vlE7023802

label define vlE7023803 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023803 vlE7023803

label define vlE7023804 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023804 vlE7023804

label define vlE7023805 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023805 vlE7023805

label define vlE7023806 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023806 vlE7023806

label define vlE7023807 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023807 vlE7023807

label define vlE7023808 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023808 vlE7023808

label define vlE7023809 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023809 vlE7023809

label define vlE7023810 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023810 vlE7023810

label define vlE7023811 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023811 vlE7023811

label define vlE7023812 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023812 vlE7023812

label define vlE7023901 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023901 vlE7023901

label define vlE7023902 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023902 vlE7023902

label define vlE7023903 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023903 vlE7023903

label define vlE7023904 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023904 vlE7023904

label define vlE7023905 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023905 vlE7023905

label define vlE7023906 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023906 vlE7023906

label define vlE7023907 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023907 vlE7023907

label define vlE7023908 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023908 vlE7023908

label define vlE7023909 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023909 vlE7023909

label define vlE7023910 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023910 vlE7023910

label define vlE7023911 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023911 vlE7023911

label define vlE7023912 101 "Cohabiting with partner 1"  102 "Cohabiting with partner 2"  103 "Cohabiting with partner 3"  104 "Cohabiting with partner 4"  105 "Cohabiting with partner 5"  106 "Cohabiting with partner 6"  107 "Cohabiting with partner 7"  108 "Cohabiting with partner 8"  109 "Cohabiting with partner 9"  110 "Cohabiting with partner 10"  111 "Cohabiting with partner 11"  201 "Cohabiting with spouse 1"  202 "Cohabiting with spouse 2"  203 "Cohabiting with spouse 3"  204 "Cohabiting with spouse 4"  205 "Cohabiting with spouse 5"  206 "Cohabiting with spouse 6"  207 "Cohabiting with spouse 7"  208 "Cohabiting with spouse 8"  209 "Cohabiting with spouse 9"  210 "Cohabiting with spouse 10" 
label values E7023912 vlE7023912

label define vlE7043500 0 "0: R did not live with more than one partner during any month since dli"  1 "1: R lived with more than one partner in a month since dli" 
label values E7043500 vlE7043500

label define vlE8023901 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023901 vlE8023901

label define vlE8023902 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023902 vlE8023902

label define vlE8023903 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023903 vlE8023903

label define vlE8023904 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023904 vlE8023904

label define vlE8023905 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023905 vlE8023905

label define vlE8023906 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023906 vlE8023906

label define vlE8023907 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023907 vlE8023907

label define vlE8023908 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023908 vlE8023908

label define vlE8023909 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023909 vlE8023909

label define vlE8023910 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023910 vlE8023910

label define vlE8023911 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023911 vlE8023911

label define vlE8023912 0 "0: R not incarcerated in this month and not incarcerated in a previous month"  1 "1: R was incarcerated during all or some of this month"  99 "99: R incarcerated previously but not in this month" 
label values E8023912 vlE8023912

label define vlE8043100 0 "0: No incarcerations"  1 "1 TO 2: incarcerations"  3 "3 TO 4: incarcerations"  5 "5 TO 6: incarcerations"  7 "7 TO 8: incarcerations"  9 "9 TO 10: incarcerations"  11 "11 TO 12: incarcerations"  13 "13 TO 14: incarcerations"  15 "15 TO 16: incarcerations"  17 "17 TO 18: incarcerations"  19 "19 TO 20: incarcerations" 
label values E8043100 vlE8043100

label define vlE8043600 1 "Yes"  0 "No" 
label values E8043600 vlE8043600

label define vlR0000100 0 "0"  1 "1 TO 999"  1000 "1000 TO 1999"  2000 "2000 TO 2999"  3000 "3000 TO 3999"  4000 "4000 TO 4999"  5000 "5000 TO 5999"  6000 "6000 TO 6999"  7000 "7000 TO 7999"  8000 "8000 TO 8999"  9000 "9000 TO 9999" 
label values R0000100 vlR0000100

label define vlR0536300 1 "Male"  2 "Female"  0 "No Information" 
label values R0536300 vlR0536300

label define vlR0536401 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values R0536401 vlR0536401

label define vlR0536600 0 "0 TO 11: LESS THAN 12"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19 TO 999: GREATER THAN 18" 
label values R0536600 vlR0536600

label define vlR0536700 0 "0 TO 11: LESS THAN 12"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19 TO 999: GREATER THAN 18" 
label values R0536700 vlR0536700

label define vlR1097800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1097800 vlR1097800

label define vlR1097900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1097900 vlR1097900

label define vlR1098000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1098000 vlR1098000

label define vlR1098100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1098100 vlR1098100

label define vlR1098200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1098200 vlR1098200

label define vlR1098300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1098300 vlR1098300

label define vlR1098400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1098400 vlR1098400

label define vlR1098500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1098500 vlR1098500

label define vlR1098600 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1098600 vlR1098600

label define vlR1098700 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1098700 vlR1098700

label define vlR1098800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1098800 vlR1098800

label define vlR1098900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1098900 vlR1098900

label define vlR1099000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1099000 vlR1099000

label define vlR1099100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1099100 vlR1099100

label define vlR1099200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1099200 vlR1099200

label define vlR1099300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1099300 vlR1099300

label define vlR1101000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1101000 vlR1101000

label define vlR1101100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1101100 vlR1101100

label define vlR1101200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1101200 vlR1101200

label define vlR1101300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1101300 vlR1101300

label define vlR1101400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1101400 vlR1101400

label define vlR1101500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1101500 vlR1101500

label define vlR1101600 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1101600 vlR1101600

label define vlR1101700 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1101700 vlR1101700

label define vlR1101800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1101800 vlR1101800

label define vlR1101900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1101900 vlR1101900

label define vlR1102000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1102000 vlR1102000

label define vlR1102100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1102100 vlR1102100

label define vlR1102200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1102200 vlR1102200

label define vlR1102300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1102300 vlR1102300

label define vlR1102400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1102400 vlR1102400

label define vlR1102500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1102500 vlR1102500

label define vlR1102501 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values R1102501 vlR1102501

label define vlR1193000 0 "0"  1 "1 TO 999"  1000 "1000 TO 1999"  2000 "2000 TO 2999"  3000 "3000 TO 3999"  4000 "4000 TO 4999"  5000 "5000 TO 5999"  6000 "6000 TO 6999"  7000 "7000 TO 7999"  8000 "8000 TO 8999"  9000 "9000 TO 9999" 
label values R1193000 vlR1193000

label define vlR1235800 1 "Cross-sectional"  0 "Oversample" 
label values R1235800 vlR1235800

label define vlR1482600 1 "Black"  2 "Hispanic"  3 "Mixed Race (Non-Hispanic)"  4 "Non-Black / Non-Hispanic" 
label values R1482600 vlR1482600

label define vlT6656400 1 "Not enrolled, no high school degree, no GED"  2 "Not enrolled, GED"  3 "Not enrolled, high school degree"  4 "Not enrolled, some college"  5 "Not enrolled, 2-year college graduate"  6 "Not enrolled, 4-year college graduate"  7 "Not enrolled, graduate degree"  8 "Enrolled in grades 1-12, not a high school graduate"  9 "Enrolled in a 2-year college"  10 "Enrolled in a 4-year college"  11 "Enrolled in a graduate program" 
label values T6656400 vlT6656400

label define vlT6657200 0 "None"  1 "GED"  2 "High school diploma (Regular 12 year program)"  3 "Associate/Junior college (AA)"  4 "Bachelor's degree (BA, BS)"  5 "Master's degree (MA, MS)"  6 "PhD"  7 "Professional degree (DDS, JD, MD)" 
label values T6657200 vlT6657200

label define vlT6657300 0 "None"  1 "GED"  2 "High school diploma (Regular 12 year program)"  3 "Associate/Junior college (AA)"  4 "Bachelor's degree (BA, BS)"  5 "Master's degree (MA, MS)"  6 "PhD"  7 "Professional degree (DDS, JD, MD)" 
label values T6657300 vlT6657300

label define vlU0008700 1 "Not enrolled, no high school degree, no GED"  2 "Not enrolled, GED"  3 "Not enrolled, high school degree"  4 "Not enrolled, some college"  5 "Not enrolled, 2-year college graduate"  6 "Not enrolled, 4-year college graduate"  7 "Not enrolled, graduate degree"  8 "Enrolled in grades 1-12, not a high school graduate"  9 "Enrolled in a 2-year college"  10 "Enrolled in a 4-year college"  11 "Enrolled in a graduate program" 
label values U0008700 vlU0008700

label define vlU0009400 0 "None"  1 "GED"  2 "High school diploma (Regular 12 year program)"  3 "Associate/Junior college (AA)"  4 "Bachelor's degree (BA, BS)"  5 "Master's degree (MA, MS)"  6 "PhD"  7 "Professional degree (DDS, JD, MD)" 
label values U0009400 vlU0009400

label define vlU3300300 60 "Completed in person"  61 "Completed by phone"  62 "Comp in person/conv"  63 "Comp by phone/conv"  64 "Comp by proxy parent/R disabled"  65 "Comp by proxy nonparent/R disabled"  66 "Comp in person/incarcerated"  67 "Comp by phone/incarcerated"  68 "Military complete"  80 "Prior deceased blocked (not fielded)"  89 "NIR blocked"  90 "Final unlocatable"  91 "Very hostile refusal"  92 "Gatekeeper Refusal"  93 "Respondent inaccessible"  94 "R too ill/handicapped"  95 "Respondent unavailable entire field period"  96 "Refusal"  97 "Hostile refusal"  98 "Deceased (current round)"  99 "Other"  101 "Refusal - by avoidance"  121 "Refusal - Incentive issue" 
label values U3300300 vlU3300300

label define vlU3316800 1 "White"  0 "NOT SELECTED" 
label values U3316800 vlU3316800

label define vlU3316801 1 "Black or African American"  0 "NOT SELECTED" 
label values U3316801 vlU3316801

label define vlU3316802 1 "Asian"  0 "NOT SELECTED" 
label values U3316802 vlU3316802

label define vlU3316803 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3316803 vlU3316803

label define vlU3316804 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3316804 vlU3316804

label define vlU3316805 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3316805 vlU3316805

label define vlU3316806 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3316806 vlU3316806

label define vlU3316807 1 "Unknown"  0 "NOT SELECTED" 
label values U3316807 vlU3316807

label define vlU3316808 1 "Added - Multiracial"  0 "NOT SELECTED" 
label values U3316808 vlU3316808

label define vlU3316809 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3316809 vlU3316809

label define vlU3316900 1 "White"  0 "NOT SELECTED" 
label values U3316900 vlU3316900

label define vlU3316901 1 "Black or African American"  0 "NOT SELECTED" 
label values U3316901 vlU3316901

label define vlU3316902 1 "Asian"  0 "NOT SELECTED" 
label values U3316902 vlU3316902

label define vlU3316903 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3316903 vlU3316903

label define vlU3316904 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3316904 vlU3316904

label define vlU3316905 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3316905 vlU3316905

label define vlU3316906 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3316906 vlU3316906

label define vlU3316907 1 "Unknown"  0 "NOT SELECTED" 
label values U3316907 vlU3316907

label define vlU3316908 1 "Added - Multiracial"  0 "NOT SELECTED" 
label values U3316908 vlU3316908

label define vlU3316909 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3316909 vlU3316909

label define vlU3317000 1 "White"  0 "NOT SELECTED" 
label values U3317000 vlU3317000

label define vlU3317001 1 "Black or African American"  0 "NOT SELECTED" 
label values U3317001 vlU3317001

label define vlU3317002 1 "Asian"  0 "NOT SELECTED" 
label values U3317002 vlU3317002

label define vlU3317003 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3317003 vlU3317003

label define vlU3317004 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3317004 vlU3317004

label define vlU3317005 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3317005 vlU3317005

label define vlU3317006 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3317006 vlU3317006

label define vlU3317007 1 "Unknown"  0 "NOT SELECTED" 
label values U3317007 vlU3317007

label define vlU3317008 1 "Added - Multiracial"  0 "NOT SELECTED" 
label values U3317008 vlU3317008

label define vlU3317009 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3317009 vlU3317009

label define vlU3317100 1 "White"  0 "NOT SELECTED" 
label values U3317100 vlU3317100

label define vlU3317101 1 "Black or African American"  0 "NOT SELECTED" 
label values U3317101 vlU3317101

label define vlU3317102 1 "Asian"  0 "NOT SELECTED" 
label values U3317102 vlU3317102

label define vlU3317103 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3317103 vlU3317103

label define vlU3317104 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3317104 vlU3317104

label define vlU3317105 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3317105 vlU3317105

label define vlU3317106 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3317106 vlU3317106

label define vlU3317107 1 "Unknown"  0 "NOT SELECTED" 
label values U3317107 vlU3317107

label define vlU3317109 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3317109 vlU3317109

label define vlU3317200 1 "White"  0 "NOT SELECTED" 
label values U3317200 vlU3317200

label define vlU3317201 1 "Black or African American"  0 "NOT SELECTED" 
label values U3317201 vlU3317201

label define vlU3317202 1 "Asian"  0 "NOT SELECTED" 
label values U3317202 vlU3317202

label define vlU3317203 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3317203 vlU3317203

label define vlU3317204 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3317204 vlU3317204

label define vlU3317205 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3317205 vlU3317205

label define vlU3317206 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3317206 vlU3317206

label define vlU3317209 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3317209 vlU3317209

label define vlU3317300 1 "White"  0 "NOT SELECTED" 
label values U3317300 vlU3317300

label define vlU3317301 1 "Black or African American"  0 "NOT SELECTED" 
label values U3317301 vlU3317301

label define vlU3317302 1 "Asian"  0 "NOT SELECTED" 
label values U3317302 vlU3317302

label define vlU3317303 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3317303 vlU3317303

label define vlU3317304 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3317304 vlU3317304

label define vlU3317305 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3317305 vlU3317305

label define vlU3317306 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3317306 vlU3317306

label define vlU3317308 1 "Added - Multiracial"  0 "NOT SELECTED" 
label values U3317308 vlU3317308

label define vlU3317309 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3317309 vlU3317309

label define vlU3317400 1 "White"  0 "NOT SELECTED" 
label values U3317400 vlU3317400

label define vlU3317401 1 "Black or African American"  0 "NOT SELECTED" 
label values U3317401 vlU3317401

label define vlU3317402 1 "Asian"  0 "NOT SELECTED" 
label values U3317402 vlU3317402

label define vlU3317403 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3317403 vlU3317403

label define vlU3317404 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3317404 vlU3317404

label define vlU3317405 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3317405 vlU3317405

label define vlU3317406 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3317406 vlU3317406

label define vlU3317409 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3317409 vlU3317409

label define vlU3317500 1 "White"  0 "NOT SELECTED" 
label values U3317500 vlU3317500

label define vlU3317501 1 "Black or African American"  0 "NOT SELECTED" 
label values U3317501 vlU3317501

label define vlU3317502 1 "Asian"  0 "NOT SELECTED" 
label values U3317502 vlU3317502

label define vlU3317503 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3317503 vlU3317503

label define vlU3317504 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3317504 vlU3317504

label define vlU3317505 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3317505 vlU3317505

label define vlU3317506 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3317506 vlU3317506

label define vlU3317509 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3317509 vlU3317509

label define vlU3317600 1 "White"  0 "NOT SELECTED" 
label values U3317600 vlU3317600

label define vlU3317601 1 "Black or African American"  0 "NOT SELECTED" 
label values U3317601 vlU3317601

label define vlU3317602 1 "Asian"  0 "NOT SELECTED" 
label values U3317602 vlU3317602

label define vlU3317603 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3317603 vlU3317603

label define vlU3317604 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3317604 vlU3317604

label define vlU3317605 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3317605 vlU3317605

label define vlU3317606 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3317606 vlU3317606

label define vlU3317609 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3317609 vlU3317609

label define vlU3317700 1 "White"  0 "NOT SELECTED" 
label values U3317700 vlU3317700

label define vlU3317701 1 "Black or African American"  0 "NOT SELECTED" 
label values U3317701 vlU3317701

label define vlU3317702 1 "Asian"  0 "NOT SELECTED" 
label values U3317702 vlU3317702

label define vlU3317703 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3317703 vlU3317703

label define vlU3317704 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3317704 vlU3317704

label define vlU3317705 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3317705 vlU3317705

label define vlU3317706 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3317706 vlU3317706

label define vlU3317800 1 "White"  0 "NOT SELECTED" 
label values U3317800 vlU3317800

label define vlU3317801 1 "Black or African American"  0 "NOT SELECTED" 
label values U3317801 vlU3317801

label define vlU3317802 1 "Asian"  0 "NOT SELECTED" 
label values U3317802 vlU3317802

label define vlU3317803 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3317803 vlU3317803

label define vlU3317804 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3317804 vlU3317804

label define vlU3317805 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3317805 vlU3317805

label define vlU3317806 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3317806 vlU3317806

label define vlU3317809 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3317809 vlU3317809

label define vlU3317900 1 "White"  0 "NOT SELECTED" 
label values U3317900 vlU3317900

label define vlU3317901 1 "Black or African American"  0 "NOT SELECTED" 
label values U3317901 vlU3317901

label define vlU3317902 1 "Asian"  0 "NOT SELECTED" 
label values U3317902 vlU3317902

label define vlU3317903 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3317903 vlU3317903

label define vlU3317904 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3317904 vlU3317904

label define vlU3317905 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3317905 vlU3317905

label define vlU3317906 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3317906 vlU3317906

label define vlU3318000 1 "White"  0 "NOT SELECTED" 
label values U3318000 vlU3318000

label define vlU3318001 1 "Black or African American"  0 "NOT SELECTED" 
label values U3318001 vlU3318001

label define vlU3318002 1 "Asian"  0 "NOT SELECTED" 
label values U3318002 vlU3318002

label define vlU3318003 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3318003 vlU3318003

label define vlU3318004 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3318004 vlU3318004

label define vlU3318005 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3318005 vlU3318005

label define vlU3318006 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3318006 vlU3318006

label define vlU3318009 1 "UNCODABLE"  0 "NOT SELECTED" 
label values U3318009 vlU3318009

label define vlU3318100 1 "White"  0 "NOT SELECTED" 
label values U3318100 vlU3318100

label define vlU3318101 1 "Black or African American"  0 "NOT SELECTED" 
label values U3318101 vlU3318101

label define vlU3318102 1 "Asian"  0 "NOT SELECTED" 
label values U3318102 vlU3318102

label define vlU3318103 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3318103 vlU3318103

label define vlU3318104 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3318104 vlU3318104

label define vlU3318105 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3318105 vlU3318105

label define vlU3318106 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3318106 vlU3318106

label define vlU3318200 1 "White"  0 "NOT SELECTED" 
label values U3318200 vlU3318200

label define vlU3318201 1 "Black or African American"  0 "NOT SELECTED" 
label values U3318201 vlU3318201

label define vlU3318202 1 "Asian"  0 "NOT SELECTED" 
label values U3318202 vlU3318202

label define vlU3318203 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3318203 vlU3318203

label define vlU3318204 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3318204 vlU3318204

label define vlU3318205 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3318205 vlU3318205

label define vlU3318206 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3318206 vlU3318206

label define vlU3318300 1 "White"  0 "NOT SELECTED" 
label values U3318300 vlU3318300

label define vlU3318301 1 "Black or African American"  0 "NOT SELECTED" 
label values U3318301 vlU3318301

label define vlU3318302 1 "Asian"  0 "NOT SELECTED" 
label values U3318302 vlU3318302

label define vlU3318303 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3318303 vlU3318303

label define vlU3318304 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3318304 vlU3318304

label define vlU3318305 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3318305 vlU3318305

label define vlU3318306 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3318306 vlU3318306

label define vlU3318400 1 "White"  0 "NOT SELECTED" 
label values U3318400 vlU3318400

label define vlU3318401 1 "Black or African American"  0 "NOT SELECTED" 
label values U3318401 vlU3318401

label define vlU3318402 1 "Asian"  0 "NOT SELECTED" 
label values U3318402 vlU3318402

label define vlU3318403 1 "Native Hawaiian or other Pacific Islander"  0 "NOT SELECTED" 
label values U3318403 vlU3318403

label define vlU3318404 1 "American Indian or Alaska Native"  0 "NOT SELECTED" 
label values U3318404 vlU3318404

label define vlU3318405 1 "OTHER? (SPECIFY)"  0 "NOT SELECTED" 
label values U3318405 vlU3318405

label define vlU3318406 1 "DO NOT READ ALOUD: HISPANIC/LATINO"  0 "NOT SELECTED" 
label values U3318406 vlU3318406

label define vlU3418800 1 "YES"  0 "NO" 
label values U3418800 vlU3418800

label define vlU3418900 1 "YES"  0 "NO" 
label values U3418900 vlU3418900

label define vlU3419000 1 "YES"  0 "NO" 
label values U3419000 vlU3419000

label define vlU3419100 1 "YES"  0 "NO" 
label values U3419100 vlU3419100

label define vlU3419200 1 "YES"  0 "NO" 
label values U3419200 vlU3419200

label define vlU3419300 1 "YES"  0 "NO" 
label values U3419300 vlU3419300

label define vlU3419400 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3419400 vlU3419400

label define vlU3419401 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U3419401 vlU3419401

label define vlU3419500 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3419500 vlU3419500

label define vlU3419501 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U3419501 vlU3419501

label define vlU3419600 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3419600 vlU3419600

label define vlU3419601 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U3419601 vlU3419601

label define vlU3419700 1 "MARRIED AND LIVING WITH RESPONDENT"  2 "SEPARATED"  3 "DIVORCED"  4 "SPOUSE - DECEASED"  5 "NOT MARRIED BUT LIVING WITH RESPONDENT"  6 "BROKEN UP"  7 "ANNULMENT"  8 "PARTNER - DECEASED"  9 "MARRIED - BUT NOT LIVING WITH RESPONDENT"  10 "PARTNER - BUT NOT LIVING WITH RESPONDENT" 
label values U3419700 vlU3419700

label define vlU3419800 1 "MARRIED AND LIVING WITH RESPONDENT"  2 "SEPARATED"  3 "DIVORCED"  4 "SPOUSE - DECEASED"  5 "NOT MARRIED BUT LIVING WITH RESPONDENT"  6 "BROKEN UP"  7 "ANNULMENT"  8 "PARTNER - DECEASED"  9 "MARRIED - BUT NOT LIVING WITH RESPONDENT"  10 "PARTNER - BUT NOT LIVING WITH RESPONDENT" 
label values U3419800 vlU3419800

label define vlU3419900 1 "MARRIED AND LIVING WITH RESPONDENT"  2 "SEPARATED"  3 "DIVORCED"  4 "SPOUSE - DECEASED"  5 "NOT MARRIED BUT LIVING WITH RESPONDENT"  6 "BROKEN UP"  7 "ANNULMENT"  8 "PARTNER - DECEASED"  9 "MARRIED - BUT NOT LIVING WITH RESPONDENT"  10 "PARTNER - BUT NOT LIVING WITH RESPONDENT" 
label values U3419900 vlU3419900

label define vlU3420000 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3420000 vlU3420000

label define vlU3420001 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U3420001 vlU3420001

label define vlU3420100 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3420100 vlU3420100

label define vlU3420101 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U3420101 vlU3420101

label define vlU3420200 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3420200 vlU3420200

label define vlU3420201 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U3420201 vlU3420201

label define vlU3437900 33 "33"  34 "34"  35 "35"  36 "36"  37 "37"  38 "38"  39 "39"  40 "40" 
label values U3437900 vlU3437900

label define vlU3438000 1 "Northeast (CT, ME, MA, NH, NJ, NY, PA, RI, VT)"  2 "North Central (IL, IN, IA, KS, MI, MN, MO, NE, OH, ND, SD, WI)"  3 "South (AL, AR, DE, DC, FL, GA, KY, LA, MD, MS, NC, OK, SC, TN , TX, VA, WV)"  4 "West (AK, AZ, CA, CO, HI, ID, MT, NV, NM, OR, UT, WA, WY)" 
label values U3438000 vlU3438000

label define vlU3438100 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3438100 vlU3438100

label define vlU3438200 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3438200 vlU3438200

label define vlU3438300 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3438300 vlU3438300

label define vlU3438400 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3438400 vlU3438400

label define vlU3438500 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3438500 vlU3438500

label define vlU3438600 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3438600 vlU3438600

label define vlU3438700 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3438700 vlU3438700

label define vlU3438800 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3438800 vlU3438800

label define vlU3438900 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3438900 vlU3438900

label define vlU3439000 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3439000 vlU3439000

label define vlU3439100 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3439100 vlU3439100

label define vlU3439200 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3439200 vlU3439200

label define vlU3439300 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3439300 vlU3439300

label define vlU3442500 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3442500 vlU3442500

label define vlU3442600 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3442600 vlU3442600

label define vlU3442700 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3442700 vlU3442700

label define vlU3442800 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3442800 vlU3442800

label define vlU3442900 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3442900 vlU3442900

label define vlU3443000 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3443000 vlU3443000

label define vlU3443100 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3443100 vlU3443100

label define vlU3443200 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3443200 vlU3443200

label define vlU3443300 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3443300 vlU3443300

label define vlU3443400 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3443400 vlU3443400

label define vlU3443500 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3443500 vlU3443500

label define vlU3443600 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3443600 vlU3443600

label define vlU3443700 1 "Non-resident adopted out"  2 "Deceased"  3 "Non-resident, not with Bio parent"  4 "Resident with other Bio parent all of the time"  5 "Resident"  6 "Deleted from roster by R"  7 "Not reported: child over 18" 
label values U3443700 vlU3443700

label define vlU3443800 1 "Not enrolled, no high school degree, no GED"  2 "Not enrolled, GED"  3 "Not enrolled, high school degree"  4 "Not enrolled, some college"  5 "Not enrolled, 2-year college graduate"  6 "Not enrolled, 4-year college graduate"  7 "Not enrolled, graduate degree"  8 "Enrolled in grades 1-12, not a high school graduate"  9 "Enrolled in a 2-year college"  10 "Enrolled in a 4-year college"  11 "Enrolled in a graduate program" 
label values U3443800 vlU3443800

label define vlU3443900 0 "NONE"  1 "1ST GRADE"  2 "2ND GRADE"  3 "3RD GRADE"  4 "4TH GRADE"  5 "5TH GRADE"  6 "6TH GRADE"  7 "7TH GRADE"  8 "8TH GRADE"  9 "9TH GRADE"  10 "10TH GRADE"  11 "11TH GRADE"  12 "12TH GRADE"  13 "1ST YEAR COLLEGE"  14 "2ND YEAR COLLEGE"  15 "3RD YEAR COLLEGE"  16 "4TH YEAR COLLEGE"  17 "5TH YEAR COLLEGE"  18 "6TH YEAR COLLEGE"  19 "7TH YEAR COLLEGE"  20 "8TH YEAR COLLEGE OR MORE"  95 "UNGRADED" 
label values U3443900 vlU3443900

label define vlU3444000 -999999 "-999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999: 200001+" 
label values U3444000 vlU3444000

label define vlU3444100 0 "0"  1 "1 TO 99: .01-.99"  100 "100 TO 199: 1.00-1.99"  200 "200 TO 299: 2.00-2.99"  300 "300 TO 399: 3.00-3.99"  400 "400 TO 499: 4.00-4.99"  500 "500 TO 599: 5.00-5.99"  600 "600 TO 699: 6.00-6.99"  700 "700 TO 799: 7.00-7.99"  800 "800 TO 899: 8.00-8.99"  900 "900 TO 999: 9.00-9.99"  1000 "1000 TO 1099: 10.00-10.99"  1100 "1100 TO 1199: 11.00-11.99"  1200 "1200 TO 1299: 12.00-12.99"  1300 "1300 TO 1399: 13.00-13.99"  1400 "1400 TO 1499: 14.00-14.99"  1500 "1500 TO 1599: 15.00-15.99"  1600 "1600 TO 1699: 16.00-16.99"  1700 "1700 TO 1799: 17.00-17.99"  1800 "1800 TO 1899: 18.00-18.99"  1900 "1900 TO 1999: 19.00-19.99"  2000 "2000 TO 2999: 20.00-29.99"  3000 "3000 TO 9999: 30.00+" 
label values U3444100 vlU3444100

label define vlU3444200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values U3444200 vlU3444200

label define vlU3444300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values U3444300 vlU3444300

label define vlU3444400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values U3444400 vlU3444400

label define vlU3444500 0 "None"  1 "GED"  2 "High school diploma (Regular 12 year program)"  3 "Associate/Junior college (AA)"  4 "Bachelor's degree (BA, BS)"  5 "Master's degree (MA, MS)"  6 "PhD"  7 "Professional degree (DDS, JD, MD)" 
label values U3444500 vlU3444500

label define vlU3444600 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3444600 vlU3444600

label define vlU3444700 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3444700 vlU3444700

label define vlU3444800 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3444800 vlU3444800

label define vlU3444900 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3444900 vlU3444900

label define vlU3445000 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3445000 vlU3445000

label define vlU3445100 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3445100 vlU3445100

label define vlU3445200 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3445200 vlU3445200

label define vlU3445300 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3445300 vlU3445300

label define vlU3445400 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3445400 vlU3445400

label define vlU3445500 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3445500 vlU3445500

label define vlU3445600 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3445600 vlU3445600

label define vlU3445700 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3445700 vlU3445700

label define vlU3445800 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3445800 vlU3445800

label define vlU3445900 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3445900 vlU3445900

label define vlU3446000 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3446000 vlU3446000

label define vlU3446100 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3446100 vlU3446100

label define vlU3446200 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3446200 vlU3446200

label define vlU3446300 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3446300 vlU3446300

label define vlU3446400 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3446400 vlU3446400

label define vlU3446500 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3446500 vlU3446500

label define vlU3446600 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3446600 vlU3446600

label define vlU3446700 0 "0"  1 "1 TO 599: 0.01-5.99"  600 "600 TO 999: 6.00-9.99"  1000 "1000 TO 2099: 10.00-20.99"  2100 "2100 TO 4099: 21.00-40.99"  4100 "4100 TO 6099: 41.00-60.99"  6100 "6100 TO 9999: 61.00-99.99"  10000 "10000 TO 9999999: 100.00+" 
label values U3446700 vlU3446700

label define vlU3450201 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U3450201 vlU3450201

label define vlU3450202 2019 "2019"  2020 "2020" 
label values U3450202 vlU3450202

label define vlU3450300 1 "YES"  0 "NO" 
label values U3450300 vlU3450300

label define vlU3450400 1 "YES"  0 "NO" 
label values U3450400 vlU3450400

label define vlU3450500 1 "YES"  0 "NO" 
label values U3450500 vlU3450500

label define vlU3450600 1 "YES"  0 "NO" 
label values U3450600 vlU3450600

label define vlU3450700 1 "YES"  0 "NO" 
label values U3450700 vlU3450700

label define vlU3450800 1 "YES"  0 "NO" 
label values U3450800 vlU3450800

label define vlU3450900 1 "YES"  0 "NO" 
label values U3450900 vlU3450900

label define vlU3451000 1 "YES"  0 "NO" 
label values U3451000 vlU3451000

label define vlU3451100 1 "YES"  0 "NO" 
label values U3451100 vlU3451100

label define vlU3451200 1 "YES"  0 "NO" 
label values U3451200 vlU3451200

label define vlU3451300 1 "YES"  0 "NO" 
label values U3451300 vlU3451300

label define vlU3451400 1 "Never married, cohabiting"  2 "Never married, not cohabiting"  3 "Married, spouse present"  4 "Married, spouse absent"  5 "Separated, cohabiting"  6 "Separated, not cohabiting"  7 "Divorced, cohabiting"  8 "Divorced, not cohabiting"  9 "Widowed, cohabiting"  10 "Widowed, not cohabiting" 
label values U3451400 vlU3451400

label define vlU3451500 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U3451500 vlU3451500

label define vlU3451600 1 "Not in CBSA"  2 "In CBSA, not in central city"  3 "In CBSA, in central city"  4 "In CBSA, not known"  5 "Not in country" 
label values U3451600 vlU3451600

label define vlU3451900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values U3451900 vlU3451900

label define vlU3452000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values U3452000 vlU3452000

label define vlU3453600 0 "Rural"  1 "Urban"  2 "Unknown" 
label values U3453600 vlU3453600

label define vlU3453700 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 124"  125 "125 TO 149"  150 "150 TO 174"  175 "175 TO 199"  200 "200 TO 249"  250 "250 TO 299"  300 "300 TO 349"  350 "350 TO 399"  400 "400 TO 449"  450 "450 TO 499"  500 "500 TO 2000: 500+" 
label values U3453700 vlU3453700

label define vlU3453800 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 124"  125 "125 TO 149"  150 "150 TO 174"  175 "175 TO 199"  200 "200 TO 249"  250 "250 TO 299"  300 "300 TO 349"  350 "350 TO 399"  400 "400 TO 449"  450 "450 TO 499"  500 "500 TO 2000: 500+" 
label values U3453800 vlU3453800

label define vlU3453900 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 124"  125 "125 TO 149"  150 "150 TO 174"  175 "175 TO 199"  200 "200 TO 249"  250 "250 TO 299"  300 "300 TO 349"  350 "350 TO 399"  400 "400 TO 449"  450 "450 TO 499"  500 "500 TO 2000: 500+" 
label values U3453900 vlU3453900

label define vlU3455100 1 "Current working at a job"  0 "Not currently working at a job"  2 "Military service (but no job) reported" 
label values U3455100 vlU3455100

label define vlU3455200 0 "Less than 30 hours"  1 "30 hours or more" 
label values U3455200 vlU3455200

label define vlU3455400 0 "0"  1 "1 TO 4"  5 "5 TO 9"  10 "10 TO 14"  15 "15 TO 21" 
label values U3455400 vlU3455400

label define vlU3455500 0 "0"  30000 "30000 TO 59999: 300.00-599.99"  60000 "60000 TO 99999: 600.00-999.99"  100000 "100000 TO 149999: 1000.00-1499.99"  150000 "150000 TO 199999: 1500.00-1999.99"  200000 "200000 TO 249999: 2000.00-2499.99"  250000 "250000 TO 299999: 2500.00-2999.99"  300000 "300000 TO 349999: 3000.00-3499.99"  350000 "350000 TO 399999: 3500.00-3999.99"  400000 "400000 TO 449999: 4000.00-4499.99"  450000 "450000 TO 499999: 4500.00-4999.99"  500000 "500000 TO 549999: 5000.00-5499.99"  550000 "550000 TO 599999: 5500.00-5999.99"  600000 "600000 TO 649999: 6000.00-6499.99"  650000 "650000 TO 699999: 6500.00-6999.99"  700000 "700000 TO 749999: 7000.00-7499.99"  750000 "750000 TO 799999: 7500.00-7999.99"  800000 "800000 TO 849999: 8000.00-8499.99"  850000 "850000 TO 9999999: 8500.00+" 
label values U3455500 vlU3455500

label define vlU3455600 0 "0"  30000 "30000 TO 59999: 300.00-599.99"  60000 "60000 TO 99999: 600.00-999.99"  100000 "100000 TO 149999: 1000.00-1499.99"  150000 "150000 TO 199999: 1500.00-1999.99"  200000 "200000 TO 249999: 2000.00-2499.99"  250000 "250000 TO 299999: 2500.00-2999.99"  300000 "300000 TO 349999: 3000.00-3499.99"  350000 "350000 TO 399999: 3500.00-3999.99"  400000 "400000 TO 449999: 4000.00-4499.99"  450000 "450000 TO 499999: 4500.00-4999.99"  500000 "500000 TO 549999: 5000.00-5499.99"  550000 "550000 TO 599999: 5500.00-5999.99"  600000 "600000 TO 649999: 6000.00-6499.99"  650000 "650000 TO 699999: 6500.00-6999.99"  700000 "700000 TO 749999: 7000.00-7499.99"  750000 "750000 TO 799999: 7500.00-7999.99"  800000 "800000 TO 849999: 8000.00-8499.99"  850000 "850000 TO 9999999: 8500.00+" 
label values U3455600 vlU3455600

label define vlU3459400 0 "0: 0%"  1 "1 TO 10: 1%-10%"  11 "11 TO 20: 11%-20%"  21 "21 TO 30: 21%-30%"  31 "31 TO 40: 31%-40%"  41 "41 TO 50: 41%-50%"  51 "51 TO 60: 51%-60%"  61 "61 TO 70: 61%-70%"  71 "71 TO 80: 71%-80%"  81 "81 TO 90: 81%-90%"  91 "91 TO 100: 91%-100%" 
label values U3459400 vlU3459400

label define vlU3459500 0 "0: 0%"  1 "1 TO 10: 1%-10%"  11 "11 TO 20: 11%-20%"  21 "21 TO 30: 21%-30%"  31 "31 TO 40: 31%-40%"  41 "41 TO 50: 41%-50%"  51 "51 TO 60: 51%-60%"  61 "61 TO 70: 61%-70%"  71 "71 TO 80: 71%-80%"  81 "81 TO 90: 81%-90%"  91 "91 TO 100: 91%-100%" 
label values U3459500 vlU3459500

label define vlU3461400 0 "0"  1 "1 TO 10000: .1 to 1000.0"  10001 "10001 TO 20000: 1000.1 to 2000.0"  20001 "20001 TO 30000: 2000.1 to 3000.0"  30001 "30001 TO 40000: 3000.1 to 4000.0"  40001 "40001 TO 50000: 4000.1 to 5000.0"  50001 "50001 TO 60000: 5000.1 to 6000.0"  60001 "60001 TO 70000: 6000.1 to 7000.0"  70001 "70001 TO 80000: 7000.1 to 8000.0"  80001 "80001 TO 90000: 8000.1 to 9000.0"  90001 "90001 TO 100000: 9000.1 to 10000.0"  100001 "100001 TO 200000: 10000.1 to 20000.0"  200001 "200001 TO 300000: 20000.1 to 30000.0" 
label values U3461400 vlU3461400

label define vlU3571600 1 "YES"  0 "NO" 
label values U3571600 vlU3571600

label define vlU3572700 1 "None"  2 "GED"  3 "High school diploma (Regular 12 year program)"  4 "Associate/Junior college (AA)"  5 "Bachelor's degree (BA, BS)"  6 "Master's degree (MA, MS)"  7 "PhD"  8 "Professional degree (DDS, JD, MD)" 
label values U3572700 vlU3572700

label define vlU3673600 1 "YES"  0 "NO" 
label values U3673600 vlU3673600

label define vlU3673700 1 "YES"  0 "NO" 
label values U3673700 vlU3673700

label define vlU3673800 1 "YES"  0 "NO" 
label values U3673800 vlU3673800

label define vlU3694400 1 "YES"  0 "NO" 
label values U3694400 vlU3694400

label define vlU3694500 1 "YES"  0 "NO" 
label values U3694500 vlU3694500

label define vlU3694600 1 "YES"  0 "NO" 
label values U3694600 vlU3694600

label define vlU3694700 1 "YES"  0 "NO" 
label values U3694700 vlU3694700

label define vlU3694800 1 "YES"  0 "NO" 
label values U3694800 vlU3694800

label define vlU3694900 1 "YES"  0 "NO" 
label values U3694900 vlU3694900

label define vlU3695000 1 "YES"  0 "NO" 
label values U3695000 vlU3695000

label define vlU3695100 1 "YES"  0 "NO" 
label values U3695100 vlU3695100

label define vlU3695200 1 "YES"  0 "NO" 
label values U3695200 vlU3695200

label define vlU3695300 1 "YES"  0 "NO" 
label values U3695300 vlU3695300

label define vlU3840200 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3840200 vlU3840200

label define vlU3840300 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3840300 vlU3840300

label define vlU3840400 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3840400 vlU3840400

label define vlU3840500 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3840500 vlU3840500

label define vlU3840600 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3840600 vlU3840600

label define vlU3840700 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3840700 vlU3840700

label define vlU3840800 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3840800 vlU3840800

label define vlU3912100 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3912100 vlU3912100

label define vlU3912200 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3912200 vlU3912200

label define vlU3912300 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3912300 vlU3912300

label define vlU3912400 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3912400 vlU3912400

label define vlU3912500 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3912500 vlU3912500

label define vlU3912600 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3912600 vlU3912600

label define vlU3912700 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U3912700 vlU3912700

label define vlU4009600 21 "Business failed or bankruptcy"  22 "Sold business to another person or firm"  23 "Business temporarily inactive"  24 "Closed business down or dissolved partnership"  99 "OTHER (SPECIFY)" 
label values U4009600 vlU4009600

label define vlU4009700 21 "Business failed or bankruptcy"  22 "Sold business to another person or firm"  23 "Business temporarily inactive"  24 "Closed business down or dissolved partnership"  99 "OTHER (SPECIFY)" 
label values U4009700 vlU4009700

label define vlU4009800 21 "Business failed or bankruptcy"  22 "Sold business to another person or firm"  23 "Business temporarily inactive"  24 "Closed business down or dissolved partnership"  99 "OTHER (SPECIFY)" 
label values U4009800 vlU4009800

label define vlU4009900 21 "Business failed or bankruptcy"  22 "Sold business to another person or firm"  23 "Business temporarily inactive"  24 "Closed business down or dissolved partnership"  99 "OTHER (SPECIFY)" 
label values U4009900 vlU4009900

label define vlU4010000 21 "Business failed or bankruptcy"  22 "Sold business to another person or firm"  23 "Business temporarily inactive"  24 "Closed business down or dissolved partnership"  99 "OTHER (SPECIFY)" 
label values U4010000 vlU4010000

label define vlU4010100 21 "Business failed or bankruptcy"  22 "Sold business to another person or firm"  23 "Business temporarily inactive"  24 "Closed business down or dissolved partnership"  99 "OTHER (SPECIFY)" 
label values U4010100 vlU4010100

label define vlU4010200 21 "Business failed or bankruptcy"  22 "Sold business to another person or firm"  23 "Business temporarily inactive"  24 "Closed business down or dissolved partnership"  99 "OTHER (SPECIFY)" 
label values U4010200 vlU4010200

label define vlU4010300 21 "Business failed or bankruptcy"  22 "Sold business to another person or firm"  23 "Business temporarily inactive"  24 "Closed business down or dissolved partnership"  99 "OTHER (SPECIFY)" 
label values U4010300 vlU4010300

label define vlU4010400 21 "Business failed or bankruptcy"  22 "Sold business to another person or firm"  23 "Business temporarily inactive"  24 "Closed business down or dissolved partnership"  99 "OTHER (SPECIFY)" 
label values U4010400 vlU4010400

label define vlU4021000 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4021000 vlU4021000

label define vlU4021100 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4021100 vlU4021100

label define vlU4021200 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4021200 vlU4021200

label define vlU4021300 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4021300 vlU4021300

label define vlU4021400 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4021400 vlU4021400

label define vlU4021500 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4021500 vlU4021500

label define vlU4021600 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4021600 vlU4021600

label define vlU4021700 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4021700 vlU4021700

label define vlU4021800 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4021800 vlU4021800

label define vlU4021900 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4021900 vlU4021900

label define vlU4022000 1 "REGULAR DAY SHIFT"  2 "REGULAR EVENING SHIFT"  3 "REGULAR NIGHT SHIFT"  4 "SHIFT ROTATES (CHANGES PERIODICALLY FROM DAYS TO EVENINGS OR NIGHTS)"  5 "SPLIT SHIFT (CONSISTS OF TWO DISTINCT PERIODS EACH DAY)"  6 "IRREGULAR SCHEDULE OR HOURS"  7 "OTHER (SPECIFY)"  8 "WEEKENDS"  9 "PART TIME WITH REGULAR SCHEDULE"  999 "UNCODABLE" 
label values U4022000 vlU4022000

label define vlU4032400 1 "YES"  0 "NO" 
label values U4032400 vlU4032400

label define vlU4032500 1 "YES"  0 "NO" 
label values U4032500 vlU4032500

label define vlU4032600 1 "YES"  0 "NO" 
label values U4032600 vlU4032600

label define vlU4032700 1 "YES"  0 "NO" 
label values U4032700 vlU4032700

label define vlU4032800 1 "YES"  0 "NO" 
label values U4032800 vlU4032800

label define vlU4032900 1 "YES"  0 "NO" 
label values U4032900 vlU4032900

label define vlU4033000 1 "YES"  0 "NO" 
label values U4033000 vlU4033000

label define vlU4033100 1 "YES"  0 "NO" 
label values U4033100 vlU4033100

label define vlU4033200 1 "YES"  0 "NO" 
label values U4033200 vlU4033200

label define vlU4041900 1 "YES"  0 "NO" 
label values U4041900 vlU4041900

label define vlU4042000 1 "YES"  0 "NO" 
label values U4042000 vlU4042000

label define vlU4042100 1 "YES"  0 "NO" 
label values U4042100 vlU4042100

label define vlU4042200 1 "YES"  0 "NO" 
label values U4042200 vlU4042200

label define vlU4042300 1 "YES"  0 "NO" 
label values U4042300 vlU4042300

label define vlU4042400 1 "YES"  0 "NO" 
label values U4042400 vlU4042400

label define vlU4042500 1 "YES"  0 "NO" 
label values U4042500 vlU4042500

label define vlU4042600 1 "YES"  0 "NO" 
label values U4042600 vlU4042600

label define vlU4042700 1 "YES"  0 "NO" 
label values U4042700 vlU4042700

label define vlU4044700 1 "YES"  0 "NO" 
label values U4044700 vlU4044700

label define vlU4044800 1 "YES"  0 "NO" 
label values U4044800 vlU4044800

label define vlU4044900 1 "YES"  0 "NO" 
label values U4044900 vlU4044900

label define vlU4045000 1 "YES"  0 "NO" 
label values U4045000 vlU4045000

label define vlU4045100 1 "YES"  0 "NO" 
label values U4045100 vlU4045100

label define vlU4045200 1 "YES"  0 "NO" 
label values U4045200 vlU4045200

label define vlU4045300 1 "YES"  0 "NO" 
label values U4045300 vlU4045300

label define vlU4045400 1 "YES"  0 "NO" 
label values U4045400 vlU4045400

label define vlU4045500 1 "YES"  0 "NO" 
label values U4045500 vlU4045500

label define vlU4051400 1 "YES"  0 "NO" 
label values U4051400 vlU4051400

label define vlU4051500 1 "YES"  0 "NO" 
label values U4051500 vlU4051500

label define vlU4051600 1 "YES"  0 "NO" 
label values U4051600 vlU4051600

label define vlU4051700 1 "YES"  0 "NO" 
label values U4051700 vlU4051700

label define vlU4051800 1 "YES"  0 "NO" 
label values U4051800 vlU4051800

label define vlU4051900 1 "YES"  0 "NO" 
label values U4051900 vlU4051900

label define vlU4052000 1 "YES"  0 "NO" 
label values U4052000 vlU4052000

label define vlU4052100 1 "YES"  0 "NO" 
label values U4052100 vlU4052100

label define vlU4052200 1 "YES"  0 "NO" 
label values U4052200 vlU4052200

label define vlU4052300 1 "YES"  0 "NO" 
label values U4052300 vlU4052300

label define vlU4052400 1 "YES"  0 "NO" 
label values U4052400 vlU4052400

label define vlU4057301 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4057301 vlU4057301

label define vlU4057302 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4057302 vlU4057302

label define vlU4057401 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4057401 vlU4057401

label define vlU4057402 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4057402 vlU4057402

label define vlU4057501 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4057501 vlU4057501

label define vlU4057502 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4057502 vlU4057502

label define vlU4057601 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4057601 vlU4057601

label define vlU4057602 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4057602 vlU4057602

label define vlU4057701 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4057701 vlU4057701

label define vlU4057702 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4057702 vlU4057702

label define vlU4057801 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4057801 vlU4057801

label define vlU4057802 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4057802 vlU4057802

label define vlU4057901 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4057901 vlU4057901

label define vlU4057902 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4057902 vlU4057902

label define vlU4058001 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4058001 vlU4058001

label define vlU4058002 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4058002 vlU4058002

label define vlU4058101 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4058101 vlU4058101

label define vlU4058102 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4058102 vlU4058102

label define vlU4058201 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4058201 vlU4058201

label define vlU4058202 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4058202 vlU4058202

label define vlU4058301 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4058301 vlU4058301

label define vlU4058302 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4058302 vlU4058302

label define vlU4058401 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4058401 vlU4058401

label define vlU4058402 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4058402 vlU4058402

label define vlU4060900 1 "YES"  0 "NO" 
label values U4060900 vlU4060900

label define vlU4061000 1 "YES"  0 "NO" 
label values U4061000 vlU4061000

label define vlU4061100 1 "YES"  0 "NO" 
label values U4061100 vlU4061100

label define vlU4061200 1 "YES"  0 "NO" 
label values U4061200 vlU4061200

label define vlU4061300 1 "YES"  0 "NO" 
label values U4061300 vlU4061300

label define vlU4061400 1 "YES"  0 "NO" 
label values U4061400 vlU4061400

label define vlU4061500 1 "YES"  0 "NO" 
label values U4061500 vlU4061500

label define vlU4061600 1 "YES"  0 "NO" 
label values U4061600 vlU4061600

label define vlU4061700 1 "YES"  0 "NO" 
label values U4061700 vlU4061700

label define vlU4061800 1 "YES"  0 "NO" 
label values U4061800 vlU4061800

label define vlU4061900 1 "YES"  0 "NO" 
label values U4061900 vlU4061900

label define vlU4062000 1 "YES"  0 "NO" 
label values U4062000 vlU4062000

label define vlU4062100 1 "YES"  0 "NO" 
label values U4062100 vlU4062100

label define vlU4062200 1 "YES"  0 "NO" 
label values U4062200 vlU4062200

label define vlU4062300 1 "YES"  0 "NO" 
label values U4062300 vlU4062300

label define vlU4062400 1 "YES"  0 "NO" 
label values U4062400 vlU4062400

label define vlU4062500 1 "YES"  0 "NO" 
label values U4062500 vlU4062500

label define vlU4062600 1 "YES"  0 "NO" 
label values U4062600 vlU4062600

label define vlU4062701 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4062701 vlU4062701

label define vlU4062702 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4062702 vlU4062702

label define vlU4062801 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4062801 vlU4062801

label define vlU4062802 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4062802 vlU4062802

label define vlU4062901 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4062901 vlU4062901

label define vlU4062902 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4062902 vlU4062902

label define vlU4063001 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4063001 vlU4063001

label define vlU4063002 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4063002 vlU4063002

label define vlU4063101 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4063101 vlU4063101

label define vlU4063102 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4063102 vlU4063102

label define vlU4087000 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4087000 vlU4087000

label define vlU4087100 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4087100 vlU4087100

label define vlU4087200 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4087200 vlU4087200

label define vlU4087300 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4087300 vlU4087300

label define vlU4087400 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4087400 vlU4087400

label define vlU4087500 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4087500 vlU4087500

label define vlU4087600 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4087600 vlU4087600

label define vlU4087700 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4087700 vlU4087700

label define vlU4087800 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4087800 vlU4087800

label define vlU4087900 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4087900 vlU4087900

label define vlU4088000 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4088000 vlU4088000

label define vlU4088100 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4088100 vlU4088100

label define vlU4088200 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4088200 vlU4088200

label define vlU4088300 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4088300 vlU4088300

label define vlU4088400 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4088400 vlU4088400

label define vlU4088500 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4088500 vlU4088500

label define vlU4088600 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4088600 vlU4088600

label define vlU4088700 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4088700 vlU4088700

label define vlU4088800 1 "No clients / customers"  2 "Didn't have materials / equipment needed"  3 "Financial problems"  4 "Temporary or season job ended for period but later resumed"  5 "Unpaid vacation"  6 "Going to school"  7 "In the Armed Forces"  8 "Pregnancy"  9 "Had health problems"  10 "Had problems with child care"  11 "Had other personal or family reason"  13 "Did not want to work"  14 "Some other reason" 
label values U4088800 vlU4088800

label define vlU4091900 0 "0: 0 Weeks"  1 "1 TO 5: 1-5 Weeks"  6 "6 TO 10: 6-10 Weeks"  11 "11 TO 15: 11-15 Weeks"  16 "16 TO 20: 16-20 Weeks"  21 "21 TO 25: 21-25 Weeks"  26 "26 TO 30: 26-30 Weeks"  31 "31 TO 35: 31-35 Weeks"  36 "36 TO 40: 36-40 Weeks"  41 "41 TO 45: 41-45 Weeks"  46 "46 TO 50: 46-50 Weeks"  51 "51 TO 999: 51+ Weeks" 
label values U4091900 vlU4091900

label define vlU4092000 0 "0: 0 Weeks"  1 "1 TO 5: 1-5 Weeks"  6 "6 TO 10: 6-10 Weeks"  11 "11 TO 15: 11-15 Weeks"  16 "16 TO 20: 16-20 Weeks"  21 "21 TO 25: 21-25 Weeks"  26 "26 TO 30: 26-30 Weeks"  31 "31 TO 35: 31-35 Weeks"  36 "36 TO 40: 36-40 Weeks"  41 "41 TO 45: 41-45 Weeks"  46 "46 TO 50: 46-50 Weeks"  51 "51 TO 999: 51+ Weeks" 
label values U4092000 vlU4092000

label define vlU4092100 0 "0: 0 Weeks"  1 "1 TO 5: 1-5 Weeks"  6 "6 TO 10: 6-10 Weeks"  11 "11 TO 15: 11-15 Weeks"  16 "16 TO 20: 16-20 Weeks"  21 "21 TO 25: 21-25 Weeks"  26 "26 TO 30: 26-30 Weeks"  31 "31 TO 35: 31-35 Weeks"  36 "36 TO 40: 36-40 Weeks"  41 "41 TO 45: 41-45 Weeks"  46 "46 TO 50: 46-50 Weeks"  51 "51 TO 999: 51+ Weeks" 
label values U4092100 vlU4092100

label define vlU4178100 1 "None"  2 "GED"  3 "High school diploma (Regular 12 year program)"  4 "Associate/Junior college (AA)"  5 "Bachelor's degree (BA, BS)"  6 "Master's degree (MA, MS)"  7 "PhD"  8 "Professional degree (DDS, JD, MD)" 
label values U4178100 vlU4178100

label define vlU4178200 1 "None"  2 "GED"  3 "High school diploma (Regular 12 year program)"  4 "Associate/Junior college (AA)"  5 "Bachelor's degree (BA, BS)"  6 "Master's degree (MA, MS)"  7 "PhD"  8 "Professional degree (DDS, JD, MD)" 
label values U4178200 vlU4178200

label define vlU4178300 1 "None"  2 "GED"  3 "High school diploma (Regular 12 year program)"  4 "Associate/Junior college (AA)"  5 "Bachelor's degree (BA, BS)"  6 "Master's degree (MA, MS)"  7 "PhD"  8 "Professional degree (DDS, JD, MD)" 
label values U4178300 vlU4178300

label define vlU4178400 1 "None"  2 "GED"  3 "High school diploma (Regular 12 year program)"  4 "Associate/Junior college (AA)"  5 "Bachelor's degree (BA, BS)"  6 "Master's degree (MA, MS)"  7 "PhD"  8 "Professional degree (DDS, JD, MD)" 
label values U4178400 vlU4178400

label define vlU4178500 1 "None"  2 "GED"  3 "High school diploma (Regular 12 year program)"  4 "Associate/Junior college (AA)"  5 "Bachelor's degree (BA, BS)"  6 "Master's degree (MA, MS)"  7 "PhD"  8 "Professional degree (DDS, JD, MD)" 
label values U4178500 vlU4178500

label define vlU4178600 1 "None"  2 "GED"  3 "High school diploma (Regular 12 year program)"  4 "Associate/Junior college (AA)"  5 "Bachelor's degree (BA, BS)"  6 "Master's degree (MA, MS)"  7 "PhD"  8 "Professional degree (DDS, JD, MD)" 
label values U4178600 vlU4178600

label define vlU4282100 1 "YES"  0 "NO" 
label values U4282100 vlU4282100

label define vlU4282300 0 "0"  1 "1 TO 4999"  5000 "5000 TO 9999"  10000 "10000 TO 14999"  15000 "15000 TO 19999"  20000 "20000 TO 24999"  25000 "25000 TO 29999"  30000 "30000 TO 39999"  40000 "40000 TO 49999"  50000 "50000 TO 59999"  60000 "60000 TO 69999"  70000 "70000 TO 79999"  80000 "80000 TO 89999"  90000 "90000 TO 99999"  100000 "100000 TO 149999"  150000 "150000 TO 99999999: 150000+" 
label values U4282300 vlU4282300

label define vlU4282400 1 "A. $1 - $5,000"  2 "B. $5,001 - $10,000"  3 "C. $10,001 - $25,000"  4 "D. $25,001 - $50,000"  5 "E. $50,001 - $100,000"  6 "F. $100,001 - $250,000"  7 "G. More than $250,000" 
label values U4282400 vlU4282400

label define vlU4283200 1 "YES"  0 "NO" 
label values U4283200 vlU4283200

label define vlU4283400 0 "0"  1 "1 TO 4"  5 "5 TO 8"  9 "9 TO 14"  15 "15 TO 19"  20 "20 TO 24"  25 "25 TO 29"  30 "30 TO 34"  35 "35 TO 39"  40 "40 TO 44"  45 "45 TO 49"  50 "50 TO 99999999: 50+" 
label values U4283400 vlU4283400

label define vlU4283600 0 "0"  1 "1 TO 4999"  5000 "5000 TO 9999"  10000 "10000 TO 14999"  15000 "15000 TO 19999"  20000 "20000 TO 24999"  25000 "25000 TO 29999"  30000 "30000 TO 39999"  40000 "40000 TO 49999"  50000 "50000 TO 59999"  60000 "60000 TO 69999"  70000 "70000 TO 79999"  80000 "80000 TO 89999"  90000 "90000 TO 99999"  100000 "100000 TO 149999"  150000 "150000 TO 99999999: 150000+" 
label values U4283600 vlU4283600

label define vlU4283700 1 "A. $1 - $5,000"  2 "B. $5,001 - $10,000"  3 "C. $10,001 - $25,000"  4 "D. $25,001 - $50,000"  5 "E. $50,001 - $100,000"  6 "F. $100,001 - $250,000"  7 "G. More than $250,000" 
label values U4283700 vlU4283700

label define vlU4285700 1 "YES"  0 "NO" 
label values U4285700 vlU4285700

label define vlU4285800 1 "YES"  0 "NO" 
label values U4285800 vlU4285800

label define vlU4286100 1 "YES"  0 "NO" 
label values U4286100 vlU4286100

label define vlU4286200 1 "A single taxpayer"  2 "Married, filing a joint return"  3 "Married, filing separate"  4 "Unmarried head of household"  5 "Qualifying widow(er) with dependent child" 
label values U4286200 vlU4286200

label define vlU4286300 1 "Self-prepared manually"  2 "Tax software"  3 "Friend or relative"  4 "Professional tax preparer" 
label values U4286300 vlU4286300

label define vlU4393300 1 "YES"  0 "NO" 
label values U4393300 vlU4393300

label define vlU4393400 1 "YES"  0 "NO" 
label values U4393400 vlU4393400

label define vlU4393500 1 "YES"  0 "NO" 
label values U4393500 vlU4393500

label define vlU4393600 1 "YES"  0 "NO" 
label values U4393600 vlU4393600

label define vlU4393700 1 "YES"  0 "NO" 
label values U4393700 vlU4393700

label define vlU4393800 1 "YES"  0 "NO" 
label values U4393800 vlU4393800

label define vlU4393900 1 "YES"  0 "NO" 
label values U4393900 vlU4393900

label define vlU4394000 1 "YES"  0 "NO" 
label values U4394000 vlU4394000

label define vlU4394100 1 "YES"  0 "NO" 
label values U4394100 vlU4394100

label define vlU4394200 1 "YES"  0 "NO" 
label values U4394200 vlU4394200

label define vlU4394300 1 "YES"  0 "NO" 
label values U4394300 vlU4394300

label define vlU4394400 1 "YES"  0 "NO" 
label values U4394400 vlU4394400

label define vlU4394500 1 "YES"  0 "NO" 
label values U4394500 vlU4394500

label define vlU4394600 1 "YES"  0 "NO" 
label values U4394600 vlU4394600

label define vlU4394700 1 "YES"  0 "NO" 
label values U4394700 vlU4394700

label define vlU4394800 1 "YES"  0 "NO" 
label values U4394800 vlU4394800

label define vlU4394900 1 "YES"  0 "NO" 
label values U4394900 vlU4394900

label define vlU4396700 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4396700 vlU4396700

label define vlU4396800 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4396800 vlU4396800

label define vlU4396900 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4396900 vlU4396900

label define vlU4397000 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4397000 vlU4397000

label define vlU4397100 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4397100 vlU4397100

label define vlU4397200 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4397200 vlU4397200

label define vlU4397300 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4397300 vlU4397300

label define vlU4397400 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4397400 vlU4397400

label define vlU4397500 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4397500 vlU4397500

label define vlU4397600 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4397600 vlU4397600

label define vlU4397700 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4397700 vlU4397700

label define vlU4397800 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4397800 vlU4397800

label define vlU4397900 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4397900 vlU4397900

label define vlU4398000 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4398000 vlU4398000

label define vlU4398100 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4398100 vlU4398100

label define vlU4398200 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4398200 vlU4398200

label define vlU4398300 0 "0"  1 "1 TO 9"  10 "10 TO 19"  20 "20 TO 29"  30 "30 TO 39"  40 "40 TO 49"  50 "50 TO 59"  60 "60 TO 69"  70 "70 TO 79"  80 "80 TO 89"  90 "90 TO 99"  100 "100 TO 99999999: 100+" 
label values U4398300 vlU4398300

label define vlU4398400 1 "MALE"  2 "FEMALE" 
label values U4398400 vlU4398400

label define vlU4398500 1 "MALE"  2 "FEMALE" 
label values U4398500 vlU4398500

label define vlU4398600 1 "MALE"  2 "FEMALE" 
label values U4398600 vlU4398600

label define vlU4398700 1 "MALE"  2 "FEMALE" 
label values U4398700 vlU4398700

label define vlU4398800 1 "MALE"  2 "FEMALE" 
label values U4398800 vlU4398800

label define vlU4398900 1 "MALE"  2 "FEMALE" 
label values U4398900 vlU4398900

label define vlU4399000 1 "MALE"  2 "FEMALE" 
label values U4399000 vlU4399000

label define vlU4399100 1 "MALE"  2 "FEMALE" 
label values U4399100 vlU4399100

label define vlU4399200 1 "MALE"  2 "FEMALE" 
label values U4399200 vlU4399200

label define vlU4399300 1 "MALE"  2 "FEMALE" 
label values U4399300 vlU4399300

label define vlU4399400 1 "MALE"  2 "FEMALE" 
label values U4399400 vlU4399400

label define vlU4399500 1 "MALE"  2 "FEMALE" 
label values U4399500 vlU4399500

label define vlU4399600 1 "MALE"  2 "FEMALE" 
label values U4399600 vlU4399600

label define vlU4399700 1 "MALE"  2 "FEMALE" 
label values U4399700 vlU4399700

label define vlU4399800 1 "MALE"  2 "FEMALE" 
label values U4399800 vlU4399800

label define vlU4399900 1 "MALE"  2 "FEMALE" 
label values U4399900 vlU4399900

label define vlU4400000 1 "MALE"  2 "FEMALE" 
label values U4400000 vlU4400000

label define vlU4400100 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U4400100 vlU4400100

label define vlU4400200 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U4400200 vlU4400200

label define vlU4400300 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U4400300 vlU4400300

label define vlU4400400 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U4400400 vlU4400400

label define vlU4400500 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U4400500 vlU4400500

label define vlU4400600 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U4400600 vlU4400600

label define vlU4400700 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U4400700 vlU4400700

label define vlU4400800 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U4400800 vlU4400800

label define vlU4400900 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U4400900 vlU4400900

label define vlU4401000 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values U4401000 vlU4401000

label define vlU4402000 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4402000 vlU4402000

label define vlU4402100 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4402100 vlU4402100

label define vlU4402200 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4402200 vlU4402200

label define vlU4402300 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4402300 vlU4402300

label define vlU4402400 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4402400 vlU4402400

label define vlU4402500 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4402500 vlU4402500

label define vlU4402600 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4402600 vlU4402600

label define vlU4402700 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4402700 vlU4402700

label define vlU4402800 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4402800 vlU4402800

label define vlU4402900 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4402900 vlU4402900

label define vlU4403000 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4403000 vlU4403000

label define vlU4403100 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4403100 vlU4403100

label define vlU4403200 1 "Full-time"  2 "Part-time"  3 "Not at all" 
label values U4403200 vlU4403200

label define vlU4405000 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4405000 vlU4405000

label define vlU4405100 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4405100 vlU4405100

label define vlU4405200 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4405200 vlU4405200

label define vlU4405300 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4405300 vlU4405300

label define vlU4405400 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4405400 vlU4405400

label define vlU4405500 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4405500 vlU4405500

label define vlU4405600 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4405600 vlU4405600

label define vlU4405700 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4405700 vlU4405700

label define vlU4405800 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4405800 vlU4405800

label define vlU4405900 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4405900 vlU4405900

label define vlU4406000 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year of college"  14 "2nd year of college"  15 "3rd year of college"  16 "4th year of college"  17 "5th year of college"  18 "6th year of college"  19 "7th  year of college"  20 "8th year of college"  93 "Pre-kindergarten"  94 "Kindergarten"  95 "Ungraded" 
label values U4406000 vlU4406000

label define vlU4406100 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4406100 vlU4406100

label define vlU4406200 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4406200 vlU4406200

label define vlU4406300 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4406300 vlU4406300

label define vlU4406400 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4406400 vlU4406400

label define vlU4406500 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4406500 vlU4406500

label define vlU4406600 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4406600 vlU4406600

label define vlU4406700 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4406700 vlU4406700

label define vlU4406800 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4406800 vlU4406800

label define vlU4406900 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4406900 vlU4406900

label define vlU4407000 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4407000 vlU4407000

label define vlU4407100 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4407100 vlU4407100

label define vlU4407200 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4407200 vlU4407200

label define vlU4407300 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4407300 vlU4407300

label define vlU4407400 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4407400 vlU4407400

label define vlU4407500 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4407500 vlU4407500

label define vlU4407600 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4407600 vlU4407600

label define vlU4407700 0 "Identity"  1 "Wife"  2 "Husband"  3 "Mother"  4 "Father"  5 "Adoptive mother"  6 "Adoptive father"  7 "Step-mother"  8 "Step-father"  9 "Foster mother"  10 "Foster father"  11 "Mother-in-law"  12 "Father-in-law"  13 "Sister (FULL)"  14 "Brother (FULL)"  15 "Sister (HALF - Same mother)"  16 "Sister (HALF - Same father)"  17 "Sister (HALF - don't know)"  18 "Brother (HALF - Same mother)"  19 "Brother (HALF - Same father)"  20 "Brother (HALF - don't know)"  21 "Sister (STEP)"  22 "Brother (STEP)"  23 "Sister (ADOPTIVE)"  24 "Brother (ADOPTIVE)"  25 "Sister (FOSTER)"  26 "Brother (FOSTER)"  27 "Brother-in-law"  28 "Sister-in-law"  29 "Maternal Grandmother"  30 "Paternal Grandmother"  31 "Social Grandmother"  32 "Grandmother (don't know or refused)"  33 "Maternal Grandfather"  34 "Paternal Grandfather"  35 "Social Grandfather"  36 "Grandfather (don't know or refused)"  37 "Maternal Great-Grandmother"  38 "Paternal Great-Grandmother"  39 "Social Great-Grandmother"  40 "Great-Grandmother (don't know or refused)"  41 "Maternal Great-Grandfather"  42 "Paternal Great-Grandfather"  43 "Social Great-Grandfather"  44 "Great-Grandfather (don't know or refused)"  45 "Great Great Grandmother"  46 "Great Great Grandfather"  47 "Granddaughter (Biological or social)"  48 "Grandson (Biological or social)"  49 "Daughter (Biological)"  50 "Son (Biological)"  51 "Step-daughter"  52 "Step-son"  53 "Adoptive daughter"  54 "Adoptive son"  55 "Foster daughter"  56 "Foster son"  57 "Daughter of lover/partner"  58 "Son of lover/partner"  59 "Daughter-in-law"  60 "Son-in-law"  61 "Grandmother-in-law"  62 "Grandfather-in-law"  63 "Aunt-in-law"  64 "Uncle-in-law"  65 "Cousin-in-law"  66 "Great-Grandmother-in-law"  67 "Great-Grandfather-in-law"  68 "Roommate"  69 "Lover/partner"  70 "Aunt (biological or social)"  71 "Great Aunt"  72 "Uncle (biological or social)"  73 "Great Uncle"  74 "Niece (biological or social)"  75 "Step Niece (biological or social)"  76 "Foster Niece (biological or social)"  77 "Adoptive Niece (biological or social)"  78 "Nephew (biological or social)"  79 "Step Nephew (biological or social)"  80 "Foster Nephew (biological or social)"  81 "Adoptive Nephew (biological or social)"  82 "Female cousin (biological or social)"  83 "Male cousin (biological or social)"  84 "Other relative"  85 "Other non-relative"  86 "Great Grandson"  87 "Great Granddaughter"  88 "Mother's Boyfriend/partner"  89 "Father's Girlfriend/partner"  90 "Parent of R's child"  99 "Missing"  999 "UNCODABLE" 
label values U4407700 vlU4407700

label define vlU4410300 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4410300 vlU4410300

label define vlU4410400 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4410400 vlU4410400

label define vlU4410500 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4410500 vlU4410500

label define vlU4410600 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4410600 vlU4410600

label define vlU4410700 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4410700 vlU4410700

label define vlU4410800 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4410800 vlU4410800

label define vlU4410900 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4410900 vlU4410900

label define vlU4411000 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4411000 vlU4411000

label define vlU4411100 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4411100 vlU4411100

label define vlU4411200 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4411200 vlU4411200

label define vlU4411300 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4411300 vlU4411300

label define vlU4411400 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4411400 vlU4411400

label define vlU4411500 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4411500 vlU4411500

label define vlU4411600 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4411600 vlU4411600

label define vlU4411700 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4411700 vlU4411700

label define vlU4411800 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4411800 vlU4411800

label define vlU4411900 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4411900 vlU4411900

label define vlU4412001 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4412001 vlU4412001

label define vlU4412002 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4412002 vlU4412002

label define vlU4412101 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4412101 vlU4412101

label define vlU4412102 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4412102 vlU4412102

label define vlU4412201 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4412201 vlU4412201

label define vlU4412202 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4412202 vlU4412202

label define vlU4412301 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4412301 vlU4412301

label define vlU4412302 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4412302 vlU4412302

label define vlU4412401 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4412401 vlU4412401

label define vlU4412402 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4412402 vlU4412402

label define vlU4412501 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4412501 vlU4412501

label define vlU4412502 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4412502 vlU4412502

label define vlU4412601 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4412601 vlU4412601

label define vlU4412602 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4412602 vlU4412602

label define vlU4412701 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4412701 vlU4412701

label define vlU4412702 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4412702 vlU4412702

label define vlU4412801 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4412801 vlU4412801

label define vlU4412802 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4412802 vlU4412802

label define vlU4412901 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4412901 vlU4412901

label define vlU4412902 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4412902 vlU4412902

label define vlU4413001 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4413001 vlU4413001

label define vlU4413002 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4413002 vlU4413002

label define vlU4413101 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values U4413101 vlU4413101

label define vlU4413102 1978 "1978"  1979 "1979"  1980 "1980"  1981 "1981"  1982 "1982"  1983 "1983"  1984 "1984"  1985 "1985"  1986 "1986"  1987 "1987"  1988 "1988"  1989 "1989"  1990 "1990"  1991 "1991"  1992 "1992"  1993 "1993"  1994 "1994"  1995 "1995"  1996 "1996"  1997 "1997"  1998 "1998"  1999 "1999"  2000 "2000"  2001 "2001"  2002 "2002"  2003 "2003"  2004 "2004"  2005 "2005"  2006 "2006"  2007 "2007"  2008 "2008"  2009 "2009"  2010 "2010"  2011 "2011"  2012 "2012"  2013 "2013"  2014 "2014"  2015 "2015"  2016 "2016"  2017 "2017"  2018 "2018"  2019 "2019"  2020 "2020" 
label values U4413102 vlU4413102

label define vlU4414400 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4414400 vlU4414400

label define vlU4414500 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4414500 vlU4414500

label define vlU4414600 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4414600 vlU4414600

label define vlU4414700 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4414700 vlU4414700

label define vlU4414800 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4414800 vlU4414800

label define vlU4414900 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4414900 vlU4414900

label define vlU4415000 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4415000 vlU4415000

label define vlU4415100 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4415100 vlU4415100

label define vlU4415200 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4415200 vlU4415200

label define vlU4415300 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4415300 vlU4415300

label define vlU4415400 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4415400 vlU4415400

label define vlU4415500 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4415500 vlU4415500

label define vlU4492100 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4492100 vlU4492100

label define vlU4492200 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4492200 vlU4492200

label define vlU4492300 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4492300 vlU4492300

label define vlU4492400 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4492400 vlU4492400

label define vlU4492500 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4492500 vlU4492500

label define vlU4492600 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4492600 vlU4492600

label define vlU4492700 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4492700 vlU4492700

label define vlU4492800 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4492800 vlU4492800

label define vlU4492900 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4492900 vlU4492900

label define vlU4493000 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4493000 vlU4493000

label define vlU4493100 0 "0"  9701 "9701 TO 9707"  9800 "9800 TO 9809"  199901 "199901 TO 199999"  200001 "200001 TO 200099"  200100 "200100 TO 200109"  200201 "200201 TO 200209"  200301 "200301 TO 200309"  200401 "200401 TO 200405"  200501 "200501 TO 200507"  200601 "200601 TO 200606"  200701 "200701 TO 200706"  200801 "200801 TO 200805"  200901 "200901 TO 200908"  201001 "201001 TO 201008"  201101 "201101 TO 201113"  201301 "201301 TO 201309"  201501 "201501 TO 201512"  201701 "201701 TO 201715"  201901 "201901 TO 201915" 
label values U4493100 vlU4493100

label define vlU4501300 1 "YES"  0 "NO" 
label values U4501300 vlU4501300

label define vlU4501400 1 "YES"  0 "NO" 
label values U4501400 vlU4501400

label define vlU4501500 1 "YES"  0 "NO" 
label values U4501500 vlU4501500

label define vlU4501600 1 "YES"  0 "NO" 
label values U4501600 vlU4501600

label define vlU4501700 1 "YES"  0 "NO" 
label values U4501700 vlU4501700

label define vlU4501800 1 "YES"  0 "NO" 
label values U4501800 vlU4501800

label define vlU4501900 1 "YES"  0 "NO" 
label values U4501900 vlU4501900

label define vlU4502000 1 "YES"  0 "NO" 
label values U4502000 vlU4502000

label define vlU4502100 1 "YES"  0 "NO" 
label values U4502100 vlU4502100

label define vlU4502200 1 "YES"  0 "NO" 
label values U4502200 vlU4502200

label define vlU4502300 1 "YES"  0 "NO" 
label values U4502300 vlU4502300

label define vlU4549100 1 "MALE"  2 "FEMALE" 
label values U4549100 vlU4549100

label define vlU4549200 1 "MALE"  2 "FEMALE" 
label values U4549200 vlU4549200

label define vlU4549300 1 "MALE"  2 "FEMALE" 
label values U4549300 vlU4549300

label define vlU4549400 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4549400 vlU4549400

label define vlU4549500 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4549500 vlU4549500

label define vlU4549600 101 "101 TO 199"  201 "201 TO 261"  199606 "199606"  199801 "199801 TO 199861"  199901 "199901 TO 199961"  200001 "200001 TO 200061"  200101 "200101 TO 200161"  200201 "200201 TO 200261"  200301 "200301 TO 200361"  200401 "200401 TO 200461"  200501 "200501 TO 200561"  200601 "200601 TO 200661"  200701 "200701 TO 200761"  200801 "200801 TO 200861"  200901 "200901 TO 200961"  201001 "201001 TO 201061"  201101 "201101 TO 201161"  201301 "201301 TO 201362"  201501 "201501 TO 201562"  201701 "201701 TO 201762"  201901 "201901 TO 201962" 
label values U4549600 vlU4549600

label define vlZ9032100 1 "Round 1"  2 "Round 2"  3 "Round 3"  4 "Round 4"  5 "Round 5"  6 "Round 6"  7 "Round 7"  8 "Round 8"  9 "Round 9"  10 "Round 10"  11 "Round 11"  12 "Round 12"  13 "Round 13"  14 "Round 14"  15 "Round 15"  16 "Round 16"  17 "Round 17"  18 "Round 18"  19 "Round 19"  20 "Round 20" 
label values Z9032100 vlZ9032100

label define vlZ9032200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values Z9032200 vlZ9032200

label define vlZ9032300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10"  11 "11"  12 "12"  13 "13"  14 "14"  15 "15"  16 "16"  17 "17"  18 "18"  19 "19"  20 "20 TO 99: 20+" 
label values Z9032300 vlZ9032300

label define vlZ9033700 1 "200 - 300"  2 "301 - 400"  3 "401 - 500"  4 "501 - 600"  5 "601 - 700"  6 "701 - 800"  0 "Have not yet received the scores" 
label values Z9033700 vlZ9033700

label define vlZ9033800 1 "Round 1"  2 "Round 2"  3 "Round 3"  4 "Round 4"  5 "Round 5"  6 "Round 6"  7 "Round 7"  8 "Round 8"  9 "Round 9"  10 "Round 10"  11 "Round 11"  12 "Round 12"  13 "Round 13"  14 "Round 14"  15 "Round 15"  16 "Round 16"  17 "Round 17"  18 "Round 18"  19 "Round 19"  20 "Round 20" 
label values Z9033800 vlZ9033800

label define vlZ9033900 1 "200 - 300"  2 "301 - 400"  3 "401 - 500"  4 "501 - 600"  5 "601 - 700"  6 "701 - 800"  0 "Have not yet received the scores" 
label values Z9033900 vlZ9033900

label define vlZ9034000 1 "Round 1"  2 "Round 2"  3 "Round 3"  4 "Round 4"  5 "Round 5"  6 "Round 6"  7 "Round 7"  8 "Round 8"  9 "Round 9"  10 "Round 10"  11 "Round 11"  12 "Round 12"  13 "Round 13"  14 "Round 14"  15 "Round 15"  16 "Round 16"  17 "Round 17"  18 "Round 18"  19 "Round 19"  20 "Round 20" 
label values Z9034000 vlZ9034000

label define vlZ9034100 1 "0 - 6"  2 "7 - 12"  3 "13 - 18"  4 "19 - 24"  5 "25 - 30"  6 "31 - 36"  0 "Have not yet received the scores" 
label values Z9034100 vlZ9034100

label define vlZ9034200 1 "Round 1"  2 "Round 2"  3 "Round 3"  4 "Round 4"  5 "Round 5"  6 "Round 6"  7 "Round 7"  8 "Round 8"  9 "Round 9"  10 "Round 10"  11 "Round 11"  12 "Round 12"  13 "Round 13"  14 "Round 14"  15 "Round 15"  16 "Round 16"  17 "Round 17"  18 "Round 18"  19 "Round 19"  20 "Round 20" 
label values Z9034200 vlZ9034200

label define vlZ9050501 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9050501 vlZ9050501

label define vlZ9050601 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9050601 vlZ9050601

label define vlZ9050701 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9050701 vlZ9050701

label define vlZ9050800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9050800 vlZ9050800

label define vlZ9050900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9050900 vlZ9050900

label define vlZ9051000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051000 vlZ9051000

label define vlZ9051100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051100 vlZ9051100

label define vlZ9051200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051200 vlZ9051200

label define vlZ9051300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051300 vlZ9051300

label define vlZ9051400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051400 vlZ9051400

label define vlZ9051500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051500 vlZ9051500

label define vlZ9051600 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051600 vlZ9051600

label define vlZ9051700 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051700 vlZ9051700

label define vlZ9051701 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051701 vlZ9051701

label define vlZ9051702 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051702 vlZ9051702

label define vlZ9051703 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051703 vlZ9051703

label define vlZ9051704 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051704 vlZ9051704

label define vlZ9051705 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051705 vlZ9051705

label define vlZ9051706 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051706 vlZ9051706

label define vlZ9051707 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051707 vlZ9051707

label define vlZ9051708 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051708 vlZ9051708

label define vlZ9051709 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051709 vlZ9051709

label define vlZ9051710 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051710 vlZ9051710

label define vlZ9051711 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051711 vlZ9051711

label define vlZ9051712 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051712 vlZ9051712

label define vlZ9051713 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051713 vlZ9051713

label define vlZ9051800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051800 vlZ9051800

label define vlZ9051900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9051900 vlZ9051900

label define vlZ9052000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9052000 vlZ9052000

label define vlZ9052100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9052100 vlZ9052100

label define vlZ9052200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9052200 vlZ9052200

label define vlZ9052300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9052300 vlZ9052300

label define vlZ9052400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9052400 vlZ9052400

label define vlZ9052500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9052500 vlZ9052500

label define vlZ9052600 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9052600 vlZ9052600

label define vlZ9052700 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9052700 vlZ9052700

label define vlZ9052800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9052800 vlZ9052800

label define vlZ9052900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9052900 vlZ9052900

label define vlZ9053000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9053000 vlZ9053000

label define vlZ9053100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9053100 vlZ9053100

label define vlZ9053200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9053200 vlZ9053200

label define vlZ9053300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9053300 vlZ9053300

label define vlZ9053400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9053400 vlZ9053400

label define vlZ9053500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9053500 vlZ9053500

label define vlZ9053600 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9053600 vlZ9053600

label define vlZ9053700 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9053700 vlZ9053700

label define vlZ9053800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9053800 vlZ9053800

label define vlZ9053900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9053900 vlZ9053900

label define vlZ9054000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054000 vlZ9054000

label define vlZ9054100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054100 vlZ9054100

label define vlZ9054200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054200 vlZ9054200

label define vlZ9054300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054300 vlZ9054300

label define vlZ9054400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054400 vlZ9054400

label define vlZ9054500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054500 vlZ9054500

label define vlZ9054600 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054600 vlZ9054600

label define vlZ9054700 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054700 vlZ9054700

label define vlZ9054701 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054701 vlZ9054701

label define vlZ9054702 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054702 vlZ9054702

label define vlZ9054703 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054703 vlZ9054703

label define vlZ9054704 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054704 vlZ9054704

label define vlZ9054705 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054705 vlZ9054705

label define vlZ9054706 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054706 vlZ9054706

label define vlZ9054707 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054707 vlZ9054707

label define vlZ9054708 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054708 vlZ9054708

label define vlZ9054709 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054709 vlZ9054709

label define vlZ9054710 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054710 vlZ9054710

label define vlZ9054711 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054711 vlZ9054711

label define vlZ9054712 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054712 vlZ9054712

label define vlZ9054713 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054713 vlZ9054713

label define vlZ9054800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054800 vlZ9054800

label define vlZ9054900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9054900 vlZ9054900

label define vlZ9055000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9055000 vlZ9055000

label define vlZ9055100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9055100 vlZ9055100

label define vlZ9055200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9055200 vlZ9055200

label define vlZ9055300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9055300 vlZ9055300

label define vlZ9055400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9055400 vlZ9055400

label define vlZ9055500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9055500 vlZ9055500

label define vlZ9055600 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9055600 vlZ9055600

label define vlZ9055700 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9055700 vlZ9055700

label define vlZ9055800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9055800 vlZ9055800

label define vlZ9055900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9055900 vlZ9055900

label define vlZ9056000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9056000 vlZ9056000

label define vlZ9056100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9056100 vlZ9056100

label define vlZ9056200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9056200 vlZ9056200

label define vlZ9056300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9056300 vlZ9056300

label define vlZ9056400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9056400 vlZ9056400

label define vlZ9056500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9056500 vlZ9056500

label define vlZ9056600 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9056600 vlZ9056600

label define vlZ9056700 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9056700 vlZ9056700

label define vlZ9056800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9056800 vlZ9056800

label define vlZ9056900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9056900 vlZ9056900

label define vlZ9057000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057000 vlZ9057000

label define vlZ9057100 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057100 vlZ9057100

label define vlZ9057200 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057200 vlZ9057200

label define vlZ9057300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057300 vlZ9057300

label define vlZ9057400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057400 vlZ9057400

label define vlZ9057500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057500 vlZ9057500

label define vlZ9057600 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057600 vlZ9057600

label define vlZ9057700 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057700 vlZ9057700

label define vlZ9057701 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057701 vlZ9057701

label define vlZ9057702 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057702 vlZ9057702

label define vlZ9057703 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057703 vlZ9057703

label define vlZ9057704 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057704 vlZ9057704

label define vlZ9057705 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057705 vlZ9057705

label define vlZ9057706 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057706 vlZ9057706

label define vlZ9057707 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057707 vlZ9057707

label define vlZ9057708 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057708 vlZ9057708

label define vlZ9057709 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057709 vlZ9057709

label define vlZ9057710 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057710 vlZ9057710

label define vlZ9057711 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057711 vlZ9057711

label define vlZ9057712 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057712 vlZ9057712

label define vlZ9057713 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057713 vlZ9057713

label define vlZ9057800 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057800 vlZ9057800

label define vlZ9057900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9057900 vlZ9057900

label define vlZ9058000 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058000 vlZ9058000

label define vlZ9058100 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058100 vlZ9058100

label define vlZ9058200 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058200 vlZ9058200

label define vlZ9058300 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058300 vlZ9058300

label define vlZ9058400 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058400 vlZ9058400

label define vlZ9058500 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058500 vlZ9058500

label define vlZ9058600 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058600 vlZ9058600

label define vlZ9058700 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058700 vlZ9058700

label define vlZ9058800 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058800 vlZ9058800

label define vlZ9058900 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058900 vlZ9058900

label define vlZ9058901 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058901 vlZ9058901

label define vlZ9058902 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058902 vlZ9058902

label define vlZ9058903 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058903 vlZ9058903

label define vlZ9058904 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058904 vlZ9058904

label define vlZ9058905 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058905 vlZ9058905

label define vlZ9058906 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058906 vlZ9058906

label define vlZ9058907 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058907 vlZ9058907

label define vlZ9058908 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058908 vlZ9058908

label define vlZ9058909 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058909 vlZ9058909

label define vlZ9058910 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058910 vlZ9058910

label define vlZ9058911 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058911 vlZ9058911

label define vlZ9058912 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058912 vlZ9058912

label define vlZ9058913 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9058913 vlZ9058913

label define vlZ9059000 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9059000 vlZ9059000

label define vlZ9059100 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9059100 vlZ9059100

label define vlZ9059200 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9059200 vlZ9059200

label define vlZ9059300 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9059300 vlZ9059300

label define vlZ9059400 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9059400 vlZ9059400

label define vlZ9059500 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9059500 vlZ9059500

label define vlZ9059600 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9059600 vlZ9059600

label define vlZ9059700 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9059700 vlZ9059700

label define vlZ9059800 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9059800 vlZ9059800

label define vlZ9059900 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9059900 vlZ9059900

label define vlZ9060000 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9060000 vlZ9060000

label define vlZ9060100 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9060100 vlZ9060100

label define vlZ9060200 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9060200 vlZ9060200

label define vlZ9060300 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9060300 vlZ9060300

label define vlZ9060400 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9060400 vlZ9060400

label define vlZ9060500 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9060500 vlZ9060500

label define vlZ9060600 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9060600 vlZ9060600

label define vlZ9060700 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9060700 vlZ9060700

label define vlZ9060800 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9060800 vlZ9060800

label define vlZ9060900 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9060900 vlZ9060900

label define vlZ9061000 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061000 vlZ9061000

label define vlZ9061100 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061100 vlZ9061100

label define vlZ9061200 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061200 vlZ9061200

label define vlZ9061300 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061300 vlZ9061300

label define vlZ9061400 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061400 vlZ9061400

label define vlZ9061500 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061500 vlZ9061500

label define vlZ9061600 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061600 vlZ9061600

label define vlZ9061700 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061700 vlZ9061700

label define vlZ9061800 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061800 vlZ9061800

label define vlZ9061900 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061900 vlZ9061900

label define vlZ9061901 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061901 vlZ9061901

label define vlZ9061902 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061902 vlZ9061902

label define vlZ9061903 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061903 vlZ9061903

label define vlZ9061904 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061904 vlZ9061904

label define vlZ9061905 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061905 vlZ9061905

label define vlZ9061906 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061906 vlZ9061906

label define vlZ9061907 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061907 vlZ9061907

label define vlZ9061908 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061908 vlZ9061908

label define vlZ9061909 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061909 vlZ9061909

label define vlZ9061910 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061910 vlZ9061910

label define vlZ9061911 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061911 vlZ9061911

label define vlZ9061912 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061912 vlZ9061912

label define vlZ9061913 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9061913 vlZ9061913

label define vlZ9062000 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9062000 vlZ9062000

label define vlZ9062100 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9062100 vlZ9062100

label define vlZ9062200 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9062200 vlZ9062200

label define vlZ9062300 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9062300 vlZ9062300

label define vlZ9062400 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9062400 vlZ9062400

label define vlZ9062500 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9062500 vlZ9062500

label define vlZ9062600 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9062600 vlZ9062600

label define vlZ9062700 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9062700 vlZ9062700

label define vlZ9062800 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9062800 vlZ9062800

label define vlZ9062900 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9062900 vlZ9062900

label define vlZ9063000 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9063000 vlZ9063000

label define vlZ9063100 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9063100 vlZ9063100

label define vlZ9063200 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9063200 vlZ9063200

label define vlZ9063300 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9063300 vlZ9063300

label define vlZ9063400 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9063400 vlZ9063400

label define vlZ9063500 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9063500 vlZ9063500

label define vlZ9063600 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9063600 vlZ9063600

label define vlZ9063700 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9063700 vlZ9063700

label define vlZ9063800 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9063800 vlZ9063800

label define vlZ9063900 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9063900 vlZ9063900

label define vlZ9064000 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064000 vlZ9064000

label define vlZ9064100 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064100 vlZ9064100

label define vlZ9064200 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064200 vlZ9064200

label define vlZ9064300 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064300 vlZ9064300

label define vlZ9064400 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064400 vlZ9064400

label define vlZ9064500 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064500 vlZ9064500

label define vlZ9064600 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064600 vlZ9064600

label define vlZ9064700 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064700 vlZ9064700

label define vlZ9064800 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064800 vlZ9064800

label define vlZ9064900 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064900 vlZ9064900

label define vlZ9064901 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064901 vlZ9064901

label define vlZ9064902 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064902 vlZ9064902

label define vlZ9064903 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064903 vlZ9064903

label define vlZ9064904 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064904 vlZ9064904

label define vlZ9064905 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064905 vlZ9064905

label define vlZ9064906 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064906 vlZ9064906

label define vlZ9064907 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064907 vlZ9064907

label define vlZ9064908 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064908 vlZ9064908

label define vlZ9064909 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064909 vlZ9064909

label define vlZ9064910 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064910 vlZ9064910

label define vlZ9064911 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064911 vlZ9064911

label define vlZ9064912 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064912 vlZ9064912

label define vlZ9064913 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9064913 vlZ9064913

label define vlZ9065000 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9065000 vlZ9065000

label define vlZ9065100 0 "0: weeks"  1 "1 TO 5: weeks"  6 "6 TO 10: weeks"  11 "11 TO 15: weeks"  16 "16 TO 20: weeks"  21 "21 TO 25: weeks"  26 "26 TO 30: weeks"  31 "31 TO 35: weeks"  36 "36 TO 40: weeks"  41 "41 TO 45: weeks"  46 "46 TO 50: weeks"  51 "51 TO 999: weeks" 
label values Z9065100 vlZ9065100

label define vlZ9065800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9065800 vlZ9065800

label define vlZ9065900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9065900 vlZ9065900

label define vlZ9066000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066000 vlZ9066000

label define vlZ9066100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066100 vlZ9066100

label define vlZ9066200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066200 vlZ9066200

label define vlZ9066300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066300 vlZ9066300

label define vlZ9066400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066400 vlZ9066400

label define vlZ9066500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066500 vlZ9066500

label define vlZ9066600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066600 vlZ9066600

label define vlZ9066700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066700 vlZ9066700

label define vlZ9066701 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066701 vlZ9066701

label define vlZ9066702 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066702 vlZ9066702

label define vlZ9066703 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066703 vlZ9066703

label define vlZ9066704 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066704 vlZ9066704

label define vlZ9066705 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066705 vlZ9066705

label define vlZ9066706 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066706 vlZ9066706

label define vlZ9066707 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066707 vlZ9066707

label define vlZ9066708 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066708 vlZ9066708

label define vlZ9066709 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066709 vlZ9066709

label define vlZ9066710 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066710 vlZ9066710

label define vlZ9066711 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066711 vlZ9066711

label define vlZ9066712 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066712 vlZ9066712

label define vlZ9066713 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066713 vlZ9066713

label define vlZ9066800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066800 vlZ9066800

label define vlZ9066900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9066900 vlZ9066900

label define vlZ9067000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9067000 vlZ9067000

label define vlZ9067100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9067100 vlZ9067100

label define vlZ9067200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9067200 vlZ9067200

label define vlZ9067300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9067300 vlZ9067300

label define vlZ9067400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9067400 vlZ9067400

label define vlZ9067500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9067500 vlZ9067500

label define vlZ9067600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9067600 vlZ9067600

label define vlZ9067700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9067700 vlZ9067700

label define vlZ9067800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9067800 vlZ9067800

label define vlZ9067900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9067900 vlZ9067900

label define vlZ9068000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9068000 vlZ9068000

label define vlZ9068100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9068100 vlZ9068100

label define vlZ9068200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9068200 vlZ9068200

label define vlZ9068300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9068300 vlZ9068300

label define vlZ9068400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9068400 vlZ9068400

label define vlZ9068500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9068500 vlZ9068500

label define vlZ9068600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9068600 vlZ9068600

label define vlZ9068700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9068700 vlZ9068700

label define vlZ9068800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9068800 vlZ9068800

label define vlZ9068900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9068900 vlZ9068900

label define vlZ9069000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069000 vlZ9069000

label define vlZ9069100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069100 vlZ9069100

label define vlZ9069200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069200 vlZ9069200

label define vlZ9069300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069300 vlZ9069300

label define vlZ9069400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069400 vlZ9069400

label define vlZ9069500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069500 vlZ9069500

label define vlZ9069600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069600 vlZ9069600

label define vlZ9069700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069700 vlZ9069700

label define vlZ9069701 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069701 vlZ9069701

label define vlZ9069702 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069702 vlZ9069702

label define vlZ9069703 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069703 vlZ9069703

label define vlZ9069704 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069704 vlZ9069704

label define vlZ9069705 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069705 vlZ9069705

label define vlZ9069706 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069706 vlZ9069706

label define vlZ9069707 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069707 vlZ9069707

label define vlZ9069708 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069708 vlZ9069708

label define vlZ9069709 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069709 vlZ9069709

label define vlZ9069710 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069710 vlZ9069710

label define vlZ9069711 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069711 vlZ9069711

label define vlZ9069712 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069712 vlZ9069712

label define vlZ9069713 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069713 vlZ9069713

label define vlZ9069800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069800 vlZ9069800

label define vlZ9069900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9069900 vlZ9069900

label define vlZ9070000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9070000 vlZ9070000

label define vlZ9070100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9070100 vlZ9070100

label define vlZ9070200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9070200 vlZ9070200

label define vlZ9070300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9070300 vlZ9070300

label define vlZ9070400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9070400 vlZ9070400

label define vlZ9070500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9070500 vlZ9070500

label define vlZ9070600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9070600 vlZ9070600

label define vlZ9070700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9070700 vlZ9070700

label define vlZ9070800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9070800 vlZ9070800

label define vlZ9070900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9070900 vlZ9070900

label define vlZ9071000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9071000 vlZ9071000

label define vlZ9071100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9071100 vlZ9071100

label define vlZ9071200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9071200 vlZ9071200

label define vlZ9071300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9071300 vlZ9071300

label define vlZ9071400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9071400 vlZ9071400

label define vlZ9071500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9071500 vlZ9071500

label define vlZ9071600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9071600 vlZ9071600

label define vlZ9071700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9071700 vlZ9071700

label define vlZ9071800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9071800 vlZ9071800

label define vlZ9071900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9071900 vlZ9071900

label define vlZ9072000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072000 vlZ9072000

label define vlZ9072100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072100 vlZ9072100

label define vlZ9072200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072200 vlZ9072200

label define vlZ9072300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072300 vlZ9072300

label define vlZ9072400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072400 vlZ9072400

label define vlZ9072500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072500 vlZ9072500

label define vlZ9072600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072600 vlZ9072600

label define vlZ9072700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072700 vlZ9072700

label define vlZ9072701 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072701 vlZ9072701

label define vlZ9072702 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072702 vlZ9072702

label define vlZ9072703 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072703 vlZ9072703

label define vlZ9072704 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072704 vlZ9072704

label define vlZ9072705 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072705 vlZ9072705

label define vlZ9072706 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072706 vlZ9072706

label define vlZ9072707 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072707 vlZ9072707

label define vlZ9072708 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072708 vlZ9072708

label define vlZ9072709 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072709 vlZ9072709

label define vlZ9072710 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072710 vlZ9072710

label define vlZ9072711 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072711 vlZ9072711

label define vlZ9072712 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072712 vlZ9072712

label define vlZ9072713 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072713 vlZ9072713

label define vlZ9072800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072800 vlZ9072800

label define vlZ9072900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 99999999: 5000+" 
label values Z9072900 vlZ9072900

label define vlZ9073000 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values Z9073000 vlZ9073000

label define vlZ9073200 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values Z9073200 vlZ9073200

label define vlZ9073400 1 "Divorced"  2 "Widowed"  3 "Unknown - includes legal annulments" 
label values Z9073400 vlZ9073400

label define vlZ9073500 1 "1: January"  2 "2: February"  3 "3: March"  4 "4: April"  5 "5: May"  6 "6: June"  7 "7: July"  8 "8: August"  9 "9: September"  10 "10: October"  11 "11: November"  12 "12: December" 
label values Z9073500 vlZ9073500

label define vlZ9073700 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9073700 vlZ9073700

label define vlZ9073800 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9073800 vlZ9073800

label define vlZ9073900 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9073900 vlZ9073900

label define vlZ9074000 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074000 vlZ9074000

label define vlZ9074100 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074100 vlZ9074100

label define vlZ9074200 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074200 vlZ9074200

label define vlZ9074300 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074300 vlZ9074300

label define vlZ9074400 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074400 vlZ9074400

label define vlZ9074500 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074500 vlZ9074500

label define vlZ9074600 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074600 vlZ9074600

label define vlZ9074601 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074601 vlZ9074601

label define vlZ9074602 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074602 vlZ9074602

label define vlZ9074603 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074603 vlZ9074603

label define vlZ9074604 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074604 vlZ9074604

label define vlZ9074605 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074605 vlZ9074605

label define vlZ9074606 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074606 vlZ9074606

label define vlZ9074607 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074607 vlZ9074607

label define vlZ9074608 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074608 vlZ9074608

label define vlZ9074609 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074609 vlZ9074609

label define vlZ9074610 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074610 vlZ9074610

label define vlZ9074611 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074611 vlZ9074611

label define vlZ9074612 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074612 vlZ9074612

label define vlZ9074613 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074613 vlZ9074613

label define vlZ9074700 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074700 vlZ9074700

label define vlZ9074800 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074800 vlZ9074800

label define vlZ9074900 0 "0: None"  1 "1 TO 3: spells"  4 "4 TO 6: spells"  7 "7 TO 9: spells"  10 "10 TO 12: spells" 
label values Z9074900 vlZ9074900

label define vlZ9075000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9075000 vlZ9075000

label define vlZ9075100 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9075100 vlZ9075100

label define vlZ9075200 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9075200 vlZ9075200

label define vlZ9075300 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9075300 vlZ9075300

label define vlZ9075400 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9075400 vlZ9075400

label define vlZ9075500 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9075500 vlZ9075500

label define vlZ9075600 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9075600 vlZ9075600

label define vlZ9075700 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9075700 vlZ9075700

label define vlZ9075800 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9075800 vlZ9075800

label define vlZ9075900 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9075900 vlZ9075900

label define vlZ9076000 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076000 vlZ9076000

label define vlZ9076001 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076001 vlZ9076001

label define vlZ9076002 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076002 vlZ9076002

label define vlZ9076003 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076003 vlZ9076003

label define vlZ9076004 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076004 vlZ9076004

label define vlZ9076005 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076005 vlZ9076005

label define vlZ9076006 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076006 vlZ9076006

label define vlZ9076007 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076007 vlZ9076007

label define vlZ9076008 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076008 vlZ9076008

label define vlZ9076009 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076009 vlZ9076009

label define vlZ9076010 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076010 vlZ9076010

label define vlZ9076011 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076011 vlZ9076011

label define vlZ9076012 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076012 vlZ9076012

label define vlZ9076013 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076013 vlZ9076013

label define vlZ9076100 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076100 vlZ9076100

label define vlZ9076200 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076200 vlZ9076200

label define vlZ9076300 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076300 vlZ9076300

label define vlZ9076400 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076400 vlZ9076400

label define vlZ9076500 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076500 vlZ9076500

label define vlZ9076600 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076600 vlZ9076600

label define vlZ9076700 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076700 vlZ9076700

label define vlZ9076800 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076800 vlZ9076800

label define vlZ9076900 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9076900 vlZ9076900

label define vlZ9077000 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9077000 vlZ9077000

label define vlZ9077100 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9077100 vlZ9077100

label define vlZ9077200 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9077200 vlZ9077200

label define vlZ9077300 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9077300 vlZ9077300

label define vlZ9077400 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9077400 vlZ9077400

label define vlZ9077500 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9077500 vlZ9077500

label define vlZ9077600 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9077600 vlZ9077600

label define vlZ9077700 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9077700 vlZ9077700

label define vlZ9077800 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9077800 vlZ9077800

label define vlZ9077900 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9077900 vlZ9077900

label define vlZ9078000 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9078000 vlZ9078000

label define vlZ9078100 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9078100 vlZ9078100

label define vlZ9078200 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9078200 vlZ9078200

label define vlZ9078300 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9078300 vlZ9078300

label define vlZ9078400 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9078400 vlZ9078400

label define vlZ9078500 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9078500 vlZ9078500

label define vlZ9078600 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9078600 vlZ9078600

label define vlZ9078700 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9078700 vlZ9078700

label define vlZ9078800 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9078800 vlZ9078800

label define vlZ9078900 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9078900 vlZ9078900

label define vlZ9079000 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9079000 vlZ9079000

label define vlZ9079100 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9079100 vlZ9079100

label define vlZ9079200 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9079200 vlZ9079200

label define vlZ9079300 0 "0: None"  1 "1 TO 3: months"  4 "4 TO 6: months"  7 "7 TO 9: months"  10 "10 TO 12: months" 
label values Z9079300 vlZ9079300

label define vlZ9079400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9079400 vlZ9079400

label define vlZ9079500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9079500 vlZ9079500

label define vlZ9079600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9079600 vlZ9079600

label define vlZ9079700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9079700 vlZ9079700

label define vlZ9079800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9079800 vlZ9079800

label define vlZ9079900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9079900 vlZ9079900

label define vlZ9080000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9080000 vlZ9080000

label define vlZ9080100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9080100 vlZ9080100

label define vlZ9080200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9080200 vlZ9080200

label define vlZ9080300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9080300 vlZ9080300

label define vlZ9080400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9080400 vlZ9080400

label define vlZ9080500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9080500 vlZ9080500

label define vlZ9080600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9080600 vlZ9080600

label define vlZ9080700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9080700 vlZ9080700

label define vlZ9080800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9080800 vlZ9080800

label define vlZ9080900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9080900 vlZ9080900

label define vlZ9081000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9081000 vlZ9081000

label define vlZ9081100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9081100 vlZ9081100

label define vlZ9081200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9081200 vlZ9081200

label define vlZ9081300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9081300 vlZ9081300

label define vlZ9081400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9081400 vlZ9081400

label define vlZ9081500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9081500 vlZ9081500

label define vlZ9081600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9081600 vlZ9081600

label define vlZ9081700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9081700 vlZ9081700

label define vlZ9081800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9081800 vlZ9081800

label define vlZ9081900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9081900 vlZ9081900

label define vlZ9082000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9082000 vlZ9082000

label define vlZ9082100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9082100 vlZ9082100

label define vlZ9082200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9082200 vlZ9082200

label define vlZ9082300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9082300 vlZ9082300

label define vlZ9082400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9082400 vlZ9082400

label define vlZ9082500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9082500 vlZ9082500

label define vlZ9082600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9082600 vlZ9082600

label define vlZ9082700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9082700 vlZ9082700

label define vlZ9082800 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9082800 vlZ9082800

label define vlZ9082900 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9082900 vlZ9082900

label define vlZ9083000 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083000 vlZ9083000

label define vlZ9083100 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083100 vlZ9083100

label define vlZ9083200 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083200 vlZ9083200

label define vlZ9083300 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083300 vlZ9083300

label define vlZ9083400 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083400 vlZ9083400

label define vlZ9083401 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083401 vlZ9083401

label define vlZ9083402 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083402 vlZ9083402

label define vlZ9083403 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083403 vlZ9083403

label define vlZ9083404 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083404 vlZ9083404

label define vlZ9083405 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083405 vlZ9083405

label define vlZ9083406 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083406 vlZ9083406

label define vlZ9083407 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083407 vlZ9083407

label define vlZ9083408 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083408 vlZ9083408

label define vlZ9083409 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083409 vlZ9083409

label define vlZ9083410 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083410 vlZ9083410

label define vlZ9083411 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083411 vlZ9083411

label define vlZ9083412 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083412 vlZ9083412

label define vlZ9083413 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083413 vlZ9083413

label define vlZ9083500 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083500 vlZ9083500

label define vlZ9083600 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083600 vlZ9083600

label define vlZ9083700 0 "0"  1 "1 TO 499"  500 "500 TO 999"  1000 "1000 TO 1499"  1500 "1500 TO 1999"  2000 "2000 TO 2499"  2500 "2500 TO 2999"  3000 "3000 TO 3499"  3500 "3500 TO 3999"  4000 "4000 TO 4499"  4500 "4500 TO 4999"  5000 "5000 TO 6999"  7000 "7000 TO 99999999: 7000+" 
label values Z9083700 vlZ9083700

label define vlZ9083800 0 "None"  1 "1st grade"  2 "2nd grade"  3 "3rd grade"  4 "4th grade"  5 "5th grade"  6 "6th grade"  7 "7th grade"  8 "8th grade"  9 "9th grade"  10 "10th grade"  11 "11th grade"  12 "12th grade"  13 "1st year college"  14 "2nd year college"  15 "3rd year college"  16 "4th year college"  17 "5th year college"  18 "6th year college"  19 "7th year college"  20 "8th year college or more"  95 "Ungraded" 
label values Z9083800 vlZ9083800

label define vlZ9083900 0 "None"  1 "GED"  2 "High school diploma (Regular 12 year program)"  3 "Associate/Junior college (AA)"  4 "Bachelor's degree (BA, BS)"  5 "Master's degree (MA, MS)"  6 "PhD"  7 "Professional degree (DDS, JD, MD)" 
label values Z9083900 vlZ9083900

label define vlZ9084000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9084000 vlZ9084000

label define vlZ9085100 1 "Round 1"  2 "Round 2"  3 "Round 3"  4 "Round 4"  5 "Round 5"  6 "Round 6"  7 "Round 7"  8 "Round 8"  9 "Round 9"  10 "Round 10"  11 "Round 11"  12 "Round 12"  13 "Round 13"  14 "Round 14"  15 "Round 15"  16 "Round 16"  17 "Round 17"  18 "Round 18"  19 "Round 19"  20 "Round 20" 
label values Z9085100 vlZ9085100

label define vlZ9085200 0 "Did not serve in the military"  1 "Served in one of the active military branches"  2 "Served in one of the military reserve branches"  3 "Served in one of the national guard branches" 
label values Z9085200 vlZ9085200

label define vlZ9085300 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9085300 vlZ9085300

label define vlZ9085400 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9085400 vlZ9085400

label define vlZ9121900 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9121900 vlZ9121900

label define vlZ9122000 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9122000 vlZ9122000

label define vlZ9122100 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9122100 vlZ9122100

label define vlZ9122200 1 "House"  2 "Ranch/Farm"  3 "Mobile Home"  6 "R does not own"  9 "Owns other residence type" 
label values Z9122200 vlZ9122200

label define vlZ9122300 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9122300 vlZ9122300

label define vlZ9122400 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9122400 vlZ9122400

label define vlZ9122500 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9122500 vlZ9122500

label define vlZ9122600 14 "Round 14"  15 "Round 15"  16 "Round 16"  17 "Round 17"  18 "Round 18" 
label values Z9122600 vlZ9122600

label define vlZ9122900 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9122900 vlZ9122900

label define vlZ9123000 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9123000 vlZ9123000

label define vlZ9141400 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9141400 vlZ9141400

label define vlZ9141500 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9141500 vlZ9141500

label define vlZ9141600 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9141600 vlZ9141600

label define vlZ9141700 1 "House"  2 "Ranch/Farm"  3 "Mobile Home"  6 "R does not own"  9 "Owns other residence type" 
label values Z9141700 vlZ9141700

label define vlZ9141800 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9141800 vlZ9141800

label define vlZ9141900 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9141900 vlZ9141900

label define vlZ9142000 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9142000 vlZ9142000

label define vlZ9142100 17 "Round 17"  18 "Round 18"  19 "Round 19"  20 "Round 20" 
label values Z9142100 vlZ9142100

label define vlZ9149100 0 "Never-married"  1 "Married"  2 "Separated"  3 "Divorced"  4 "Widowed" 
label values Z9149100 vlZ9149100

label define vlZ9156500 0 "0"  1 "1"  2 "2"  3 "3"  4 "4"  5 "5"  6 "6"  7 "7"  8 "8"  9 "9"  10 "10 TO 999: 10+" 
label values Z9156500 vlZ9156500

label define vlZ9164500 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9164500 vlZ9164500

label define vlZ9164700 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9164700 vlZ9164700

label define vlZ9164900 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9164900 vlZ9164900

label define vlZ9165100 1 "House"  2 "Ranch/Farm"  3 "Mobile Home"  6 "R does not own"  9 "Owns other residence type" 
label values Z9165100 vlZ9165100

label define vlZ9165200 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9165200 vlZ9165200

label define vlZ9165400 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9165400 vlZ9165400

label define vlZ9165600 -9999999 "-9999999 TO -3000: < -2999"  -2999 "-2999 TO -2000"  -1999 "-1999 TO -1000"  -999 "-999 TO -1"  0 "0"  1 "1 TO 1000"  1001 "1001 TO 2000"  2001 "2001 TO 3000"  3001 "3001 TO 5000"  5001 "5001 TO 10000"  10001 "10001 TO 20000"  20001 "20001 TO 30000"  30001 "30001 TO 40000"  40001 "40001 TO 50000"  50001 "50001 TO 65000"  65001 "65001 TO 80000"  80001 "80001 TO 100000"  100001 "100001 TO 150000"  150001 "150001 TO 200000"  200001 "200001 TO 999999999: 200001+" 
label values Z9165600 vlZ9165600

label define vlZ9165800 17 "Round 17"  18 "Round 18"  19 "Round 19"  20 "Round 20" 
label values Z9165800 vlZ9165800
/* Crosswalk for Reference number & Question name
 * Uncomment and edit this RENAME statement to rename variables for ease of use.
 * This command does not guarantee uniqueness
 */
  /* *start* */
/*
  rename E0013801 EMP_STATUS_2018_01_XRND   // EMP_STATUS_2018.01
  rename E0013802 EMP_STATUS_2018_02_XRND   // EMP_STATUS_2018.02
  rename E0013803 EMP_STATUS_2018_03_XRND   // EMP_STATUS_2018.03
  rename E0013804 EMP_STATUS_2018_04_XRND   // EMP_STATUS_2018.04
  rename E0013805 EMP_STATUS_2018_05_XRND   // EMP_STATUS_2018.05
  rename E0013806 EMP_STATUS_2018_06_XRND   // EMP_STATUS_2018.06
  rename E0013807 EMP_STATUS_2018_07_XRND   // EMP_STATUS_2018.07
  rename E0013808 EMP_STATUS_2018_08_XRND   // EMP_STATUS_2018.08
  rename E0013809 EMP_STATUS_2018_09_XRND   // EMP_STATUS_2018.09
  rename E0013810 EMP_STATUS_2018_10_XRND   // EMP_STATUS_2018.10
  rename E0013811 EMP_STATUS_2018_11_XRND   // EMP_STATUS_2018.11
  rename E0013812 EMP_STATUS_2018_12_XRND   // EMP_STATUS_2018.12
  rename E0013813 EMP_STATUS_2018_13_XRND   // EMP_STATUS_2018.13
  rename E0013814 EMP_STATUS_2018_14_XRND   // EMP_STATUS_2018.14
  rename E0013815 EMP_STATUS_2018_15_XRND   // EMP_STATUS_2018.15
  rename E0013816 EMP_STATUS_2018_16_XRND   // EMP_STATUS_2018.16
  rename E0013817 EMP_STATUS_2018_17_XRND   // EMP_STATUS_2018.17
  rename E0013818 EMP_STATUS_2018_18_XRND   // EMP_STATUS_2018.18
  rename E0013819 EMP_STATUS_2018_19_XRND   // EMP_STATUS_2018.19
  rename E0013820 EMP_STATUS_2018_20_XRND   // EMP_STATUS_2018.20
  rename E0013821 EMP_STATUS_2018_21_XRND   // EMP_STATUS_2018.21
  rename E0013822 EMP_STATUS_2018_22_XRND   // EMP_STATUS_2018.22
  rename E0013823 EMP_STATUS_2018_23_XRND   // EMP_STATUS_2018.23
  rename E0013824 EMP_STATUS_2018_24_XRND   // EMP_STATUS_2018.24
  rename E0013825 EMP_STATUS_2018_25_XRND   // EMP_STATUS_2018.25
  rename E0013826 EMP_STATUS_2018_26_XRND   // EMP_STATUS_2018.26
  rename E0013827 EMP_STATUS_2018_27_XRND   // EMP_STATUS_2018.27
  rename E0013828 EMP_STATUS_2018_28_XRND   // EMP_STATUS_2018.28
  rename E0013829 EMP_STATUS_2018_29_XRND   // EMP_STATUS_2018.29
  rename E0013830 EMP_STATUS_2018_30_XRND   // EMP_STATUS_2018.30
  rename E0013831 EMP_STATUS_2018_31_XRND   // EMP_STATUS_2018.31
  rename E0013832 EMP_STATUS_2018_32_XRND   // EMP_STATUS_2018.32
  rename E0013833 EMP_STATUS_2018_33_XRND   // EMP_STATUS_2018.33
  rename E0013834 EMP_STATUS_2018_34_XRND   // EMP_STATUS_2018.34
  rename E0013835 EMP_STATUS_2018_35_XRND   // EMP_STATUS_2018.35
  rename E0013836 EMP_STATUS_2018_36_XRND   // EMP_STATUS_2018.36
  rename E0013837 EMP_STATUS_2018_37_XRND   // EMP_STATUS_2018.37
  rename E0013838 EMP_STATUS_2018_38_XRND   // EMP_STATUS_2018.38
  rename E0013839 EMP_STATUS_2018_39_XRND   // EMP_STATUS_2018.39
  rename E0013840 EMP_STATUS_2018_40_XRND   // EMP_STATUS_2018.40
  rename E0013841 EMP_STATUS_2018_41_XRND   // EMP_STATUS_2018.41
  rename E0013842 EMP_STATUS_2018_42_XRND   // EMP_STATUS_2018.42
  rename E0013843 EMP_STATUS_2018_43_XRND   // EMP_STATUS_2018.43
  rename E0013844 EMP_STATUS_2018_44_XRND   // EMP_STATUS_2018.44
  rename E0013845 EMP_STATUS_2018_45_XRND   // EMP_STATUS_2018.45
  rename E0013846 EMP_STATUS_2018_46_XRND   // EMP_STATUS_2018.46
  rename E0013847 EMP_STATUS_2018_47_XRND   // EMP_STATUS_2018.47
  rename E0013848 EMP_STATUS_2018_48_XRND   // EMP_STATUS_2018.48
  rename E0013849 EMP_STATUS_2018_49_XRND   // EMP_STATUS_2018.49
  rename E0013850 EMP_STATUS_2018_50_XRND   // EMP_STATUS_2018.50
  rename E0013851 EMP_STATUS_2018_51_XRND   // EMP_STATUS_2018.51
  rename E0013852 EMP_STATUS_2018_52_XRND   // EMP_STATUS_2018.52
  rename E0013901 EMP_STATUS_2019_01_XRND   // EMP_STATUS_2019.01
  rename E0013902 EMP_STATUS_2019_02_XRND   // EMP_STATUS_2019.02
  rename E0013903 EMP_STATUS_2019_03_XRND   // EMP_STATUS_2019.03
  rename E0013904 EMP_STATUS_2019_04_XRND   // EMP_STATUS_2019.04
  rename E0013905 EMP_STATUS_2019_05_XRND   // EMP_STATUS_2019.05
  rename E0013906 EMP_STATUS_2019_06_XRND   // EMP_STATUS_2019.06
  rename E0013907 EMP_STATUS_2019_07_XRND   // EMP_STATUS_2019.07
  rename E0013908 EMP_STATUS_2019_08_XRND   // EMP_STATUS_2019.08
  rename E0013909 EMP_STATUS_2019_09_XRND   // EMP_STATUS_2019.09
  rename E0013910 EMP_STATUS_2019_10_XRND   // EMP_STATUS_2019.10
  rename E0013911 EMP_STATUS_2019_11_XRND   // EMP_STATUS_2019.11
  rename E0013912 EMP_STATUS_2019_12_XRND   // EMP_STATUS_2019.12
  rename E0013913 EMP_STATUS_2019_13_XRND   // EMP_STATUS_2019.13
  rename E0013914 EMP_STATUS_2019_14_XRND   // EMP_STATUS_2019.14
  rename E0013915 EMP_STATUS_2019_15_XRND   // EMP_STATUS_2019.15
  rename E0013916 EMP_STATUS_2019_16_XRND   // EMP_STATUS_2019.16
  rename E0013917 EMP_STATUS_2019_17_XRND   // EMP_STATUS_2019.17
  rename E0013918 EMP_STATUS_2019_18_XRND   // EMP_STATUS_2019.18
  rename E0013919 EMP_STATUS_2019_19_XRND   // EMP_STATUS_2019.19
  rename E0013920 EMP_STATUS_2019_20_XRND   // EMP_STATUS_2019.20
  rename E0013921 EMP_STATUS_2019_21_XRND   // EMP_STATUS_2019.21
  rename E0013922 EMP_STATUS_2019_22_XRND   // EMP_STATUS_2019.22
  rename E0013923 EMP_STATUS_2019_23_XRND   // EMP_STATUS_2019.23
  rename E0013924 EMP_STATUS_2019_24_XRND   // EMP_STATUS_2019.24
  rename E0013925 EMP_STATUS_2019_25_XRND   // EMP_STATUS_2019.25
  rename E0013926 EMP_STATUS_2019_26_XRND   // EMP_STATUS_2019.26
  rename E0013927 EMP_STATUS_2019_27_XRND   // EMP_STATUS_2019.27
  rename E0013928 EMP_STATUS_2019_28_XRND   // EMP_STATUS_2019.28
  rename E0013929 EMP_STATUS_2019_29_XRND   // EMP_STATUS_2019.29
  rename E0013930 EMP_STATUS_2019_30_XRND   // EMP_STATUS_2019.30
  rename E0013931 EMP_STATUS_2019_31_XRND   // EMP_STATUS_2019.31
  rename E0013932 EMP_STATUS_2019_32_XRND   // EMP_STATUS_2019.32
  rename E0013933 EMP_STATUS_2019_33_XRND   // EMP_STATUS_2019.33
  rename E0013934 EMP_STATUS_2019_34_XRND   // EMP_STATUS_2019.34
  rename E0013935 EMP_STATUS_2019_35_XRND   // EMP_STATUS_2019.35
  rename E0013936 EMP_STATUS_2019_36_XRND   // EMP_STATUS_2019.36
  rename E0013937 EMP_STATUS_2019_37_XRND   // EMP_STATUS_2019.37
  rename E0013938 EMP_STATUS_2019_38_XRND   // EMP_STATUS_2019.38
  rename E0013939 EMP_STATUS_2019_39_XRND   // EMP_STATUS_2019.39
  rename E0013940 EMP_STATUS_2019_40_XRND   // EMP_STATUS_2019.40
  rename E0013941 EMP_STATUS_2019_41_XRND   // EMP_STATUS_2019.41
  rename E0013942 EMP_STATUS_2019_42_XRND   // EMP_STATUS_2019.42
  rename E0013943 EMP_STATUS_2019_43_XRND   // EMP_STATUS_2019.43
  rename E0013944 EMP_STATUS_2019_44_XRND   // EMP_STATUS_2019.44
  rename E0013945 EMP_STATUS_2019_45_XRND   // EMP_STATUS_2019.45
  rename E0013946 EMP_STATUS_2019_46_XRND   // EMP_STATUS_2019.46
  rename E0013947 EMP_STATUS_2019_47_XRND   // EMP_STATUS_2019.47
  rename E0013948 EMP_STATUS_2019_48_XRND   // EMP_STATUS_2019.48
  rename E0013949 EMP_STATUS_2019_49_XRND   // EMP_STATUS_2019.49
  rename E0013950 EMP_STATUS_2019_50_XRND   // EMP_STATUS_2019.50
  rename E0013951 EMP_STATUS_2019_51_XRND   // EMP_STATUS_2019.51
  rename E0013952 EMP_STATUS_2019_52_XRND   // EMP_STATUS_2019.52
  rename E0023801 EMP_HOURS_2018_01_XRND   // EMP_HOURS_2018.01
  rename E0023802 EMP_HOURS_2018_02_XRND   // EMP_HOURS_2018.02
  rename E0023803 EMP_HOURS_2018_03_XRND   // EMP_HOURS_2018.03
  rename E0023804 EMP_HOURS_2018_04_XRND   // EMP_HOURS_2018.04
  rename E0023805 EMP_HOURS_2018_05_XRND   // EMP_HOURS_2018.05
  rename E0023806 EMP_HOURS_2018_06_XRND   // EMP_HOURS_2018.06
  rename E0023807 EMP_HOURS_2018_07_XRND   // EMP_HOURS_2018.07
  rename E0023808 EMP_HOURS_2018_08_XRND   // EMP_HOURS_2018.08
  rename E0023809 EMP_HOURS_2018_09_XRND   // EMP_HOURS_2018.09
  rename E0023810 EMP_HOURS_2018_10_XRND   // EMP_HOURS_2018.10
  rename E0023811 EMP_HOURS_2018_11_XRND   // EMP_HOURS_2018.11
  rename E0023812 EMP_HOURS_2018_12_XRND   // EMP_HOURS_2018.12
  rename E0023813 EMP_HOURS_2018_13_XRND   // EMP_HOURS_2018.13
  rename E0023814 EMP_HOURS_2018_14_XRND   // EMP_HOURS_2018.14
  rename E0023815 EMP_HOURS_2018_15_XRND   // EMP_HOURS_2018.15
  rename E0023816 EMP_HOURS_2018_16_XRND   // EMP_HOURS_2018.16
  rename E0023817 EMP_HOURS_2018_17_XRND   // EMP_HOURS_2018.17
  rename E0023818 EMP_HOURS_2018_18_XRND   // EMP_HOURS_2018.18
  rename E0023819 EMP_HOURS_2018_19_XRND   // EMP_HOURS_2018.19
  rename E0023820 EMP_HOURS_2018_20_XRND   // EMP_HOURS_2018.20
  rename E0023821 EMP_HOURS_2018_21_XRND   // EMP_HOURS_2018.21
  rename E0023822 EMP_HOURS_2018_22_XRND   // EMP_HOURS_2018.22
  rename E0023823 EMP_HOURS_2018_23_XRND   // EMP_HOURS_2018.23
  rename E0023824 EMP_HOURS_2018_24_XRND   // EMP_HOURS_2018.24
  rename E0023825 EMP_HOURS_2018_25_XRND   // EMP_HOURS_2018.25
  rename E0023826 EMP_HOURS_2018_26_XRND   // EMP_HOURS_2018.26
  rename E0023827 EMP_HOURS_2018_27_XRND   // EMP_HOURS_2018.27
  rename E0023828 EMP_HOURS_2018_28_XRND   // EMP_HOURS_2018.28
  rename E0023829 EMP_HOURS_2018_29_XRND   // EMP_HOURS_2018.29
  rename E0023830 EMP_HOURS_2018_30_XRND   // EMP_HOURS_2018.30
  rename E0023831 EMP_HOURS_2018_31_XRND   // EMP_HOURS_2018.31
  rename E0023832 EMP_HOURS_2018_32_XRND   // EMP_HOURS_2018.32
  rename E0023833 EMP_HOURS_2018_33_XRND   // EMP_HOURS_2018.33
  rename E0023834 EMP_HOURS_2018_34_XRND   // EMP_HOURS_2018.34
  rename E0023835 EMP_HOURS_2018_35_XRND   // EMP_HOURS_2018.35
  rename E0023836 EMP_HOURS_2018_36_XRND   // EMP_HOURS_2018.36
  rename E0023837 EMP_HOURS_2018_37_XRND   // EMP_HOURS_2018.37
  rename E0023838 EMP_HOURS_2018_38_XRND   // EMP_HOURS_2018.38
  rename E0023839 EMP_HOURS_2018_39_XRND   // EMP_HOURS_2018.39
  rename E0023840 EMP_HOURS_2018_40_XRND   // EMP_HOURS_2018.40
  rename E0023841 EMP_HOURS_2018_41_XRND   // EMP_HOURS_2018.41
  rename E0023842 EMP_HOURS_2018_42_XRND   // EMP_HOURS_2018.42
  rename E0023843 EMP_HOURS_2018_43_XRND   // EMP_HOURS_2018.43
  rename E0023844 EMP_HOURS_2018_44_XRND   // EMP_HOURS_2018.44
  rename E0023845 EMP_HOURS_2018_45_XRND   // EMP_HOURS_2018.45
  rename E0023846 EMP_HOURS_2018_46_XRND   // EMP_HOURS_2018.46
  rename E0023847 EMP_HOURS_2018_47_XRND   // EMP_HOURS_2018.47
  rename E0023848 EMP_HOURS_2018_48_XRND   // EMP_HOURS_2018.48
  rename E0023849 EMP_HOURS_2018_49_XRND   // EMP_HOURS_2018.49
  rename E0023850 EMP_HOURS_2018_50_XRND   // EMP_HOURS_2018.50
  rename E0023851 EMP_HOURS_2018_51_XRND   // EMP_HOURS_2018.51
  rename E0023852 EMP_HOURS_2018_52_XRND   // EMP_HOURS_2018.52
  rename E0023901 EMP_HOURS_2019_01_XRND   // EMP_HOURS_2019.01
  rename E0023902 EMP_HOURS_2019_02_XRND   // EMP_HOURS_2019.02
  rename E0023903 EMP_HOURS_2019_03_XRND   // EMP_HOURS_2019.03
  rename E0023904 EMP_HOURS_2019_04_XRND   // EMP_HOURS_2019.04
  rename E0023905 EMP_HOURS_2019_05_XRND   // EMP_HOURS_2019.05
  rename E0023906 EMP_HOURS_2019_06_XRND   // EMP_HOURS_2019.06
  rename E0023907 EMP_HOURS_2019_07_XRND   // EMP_HOURS_2019.07
  rename E0023908 EMP_HOURS_2019_08_XRND   // EMP_HOURS_2019.08
  rename E0023909 EMP_HOURS_2019_09_XRND   // EMP_HOURS_2019.09
  rename E0023910 EMP_HOURS_2019_10_XRND   // EMP_HOURS_2019.10
  rename E0023911 EMP_HOURS_2019_11_XRND   // EMP_HOURS_2019.11
  rename E0023912 EMP_HOURS_2019_12_XRND   // EMP_HOURS_2019.12
  rename E0023913 EMP_HOURS_2019_13_XRND   // EMP_HOURS_2019.13
  rename E0023914 EMP_HOURS_2019_14_XRND   // EMP_HOURS_2019.14
  rename E0023915 EMP_HOURS_2019_15_XRND   // EMP_HOURS_2019.15
  rename E0023916 EMP_HOURS_2019_16_XRND   // EMP_HOURS_2019.16
  rename E0023917 EMP_HOURS_2019_17_XRND   // EMP_HOURS_2019.17
  rename E0023918 EMP_HOURS_2019_18_XRND   // EMP_HOURS_2019.18
  rename E0023919 EMP_HOURS_2019_19_XRND   // EMP_HOURS_2019.19
  rename E0023920 EMP_HOURS_2019_20_XRND   // EMP_HOURS_2019.20
  rename E0023921 EMP_HOURS_2019_21_XRND   // EMP_HOURS_2019.21
  rename E0023922 EMP_HOURS_2019_22_XRND   // EMP_HOURS_2019.22
  rename E0023923 EMP_HOURS_2019_23_XRND   // EMP_HOURS_2019.23
  rename E0023924 EMP_HOURS_2019_24_XRND   // EMP_HOURS_2019.24
  rename E0023925 EMP_HOURS_2019_25_XRND   // EMP_HOURS_2019.25
  rename E0023926 EMP_HOURS_2019_26_XRND   // EMP_HOURS_2019.26
  rename E0023927 EMP_HOURS_2019_27_XRND   // EMP_HOURS_2019.27
  rename E0023928 EMP_HOURS_2019_28_XRND   // EMP_HOURS_2019.28
  rename E0023929 EMP_HOURS_2019_29_XRND   // EMP_HOURS_2019.29
  rename E0023930 EMP_HOURS_2019_30_XRND   // EMP_HOURS_2019.30
  rename E0023931 EMP_HOURS_2019_31_XRND   // EMP_HOURS_2019.31
  rename E0023932 EMP_HOURS_2019_32_XRND   // EMP_HOURS_2019.32
  rename E0023933 EMP_HOURS_2019_33_XRND   // EMP_HOURS_2019.33
  rename E0023934 EMP_HOURS_2019_34_XRND   // EMP_HOURS_2019.34
  rename E0023935 EMP_HOURS_2019_35_XRND   // EMP_HOURS_2019.35
  rename E0023936 EMP_HOURS_2019_36_XRND   // EMP_HOURS_2019.36
  rename E0023937 EMP_HOURS_2019_37_XRND   // EMP_HOURS_2019.37
  rename E0023938 EMP_HOURS_2019_38_XRND   // EMP_HOURS_2019.38
  rename E0023939 EMP_HOURS_2019_39_XRND   // EMP_HOURS_2019.39
  rename E0023940 EMP_HOURS_2019_40_XRND   // EMP_HOURS_2019.40
  rename E0023941 EMP_HOURS_2019_41_XRND   // EMP_HOURS_2019.41
  rename E0023942 EMP_HOURS_2019_42_XRND   // EMP_HOURS_2019.42
  rename E0023943 EMP_HOURS_2019_43_XRND   // EMP_HOURS_2019.43
  rename E0023944 EMP_HOURS_2019_44_XRND   // EMP_HOURS_2019.44
  rename E0023945 EMP_HOURS_2019_45_XRND   // EMP_HOURS_2019.45
  rename E0023946 EMP_HOURS_2019_46_XRND   // EMP_HOURS_2019.46
  rename E0023947 EMP_HOURS_2019_47_XRND   // EMP_HOURS_2019.47
  rename E0023948 EMP_HOURS_2019_48_XRND   // EMP_HOURS_2019.48
  rename E0023949 EMP_HOURS_2019_49_XRND   // EMP_HOURS_2019.49
  rename E0023950 EMP_HOURS_2019_50_XRND   // EMP_HOURS_2019.50
  rename E0023951 EMP_HOURS_2019_51_XRND   // EMP_HOURS_2019.51
  rename E0023952 EMP_HOURS_2019_52_XRND   // EMP_HOURS_2019.52
  rename E0123801 EMP_DUAL_2_2018_01_XRND   // EMP_DUAL_2_2018.01
  rename E0123802 EMP_DUAL_2_2018_02_XRND   // EMP_DUAL_2_2018.02
  rename E0123803 EMP_DUAL_2_2018_03_XRND   // EMP_DUAL_2_2018.03
  rename E0123804 EMP_DUAL_2_2018_04_XRND   // EMP_DUAL_2_2018.04
  rename E0123805 EMP_DUAL_2_2018_05_XRND   // EMP_DUAL_2_2018.05
  rename E0123806 EMP_DUAL_2_2018_06_XRND   // EMP_DUAL_2_2018.06
  rename E0123807 EMP_DUAL_2_2018_07_XRND   // EMP_DUAL_2_2018.07
  rename E0123808 EMP_DUAL_2_2018_08_XRND   // EMP_DUAL_2_2018.08
  rename E0123809 EMP_DUAL_2_2018_09_XRND   // EMP_DUAL_2_2018.09
  rename E0123810 EMP_DUAL_2_2018_10_XRND   // EMP_DUAL_2_2018.10
  rename E0123811 EMP_DUAL_2_2018_11_XRND   // EMP_DUAL_2_2018.11
  rename E0123812 EMP_DUAL_2_2018_12_XRND   // EMP_DUAL_2_2018.12
  rename E0123813 EMP_DUAL_2_2018_13_XRND   // EMP_DUAL_2_2018.13
  rename E0123814 EMP_DUAL_2_2018_14_XRND   // EMP_DUAL_2_2018.14
  rename E0123815 EMP_DUAL_2_2018_15_XRND   // EMP_DUAL_2_2018.15
  rename E0123816 EMP_DUAL_2_2018_16_XRND   // EMP_DUAL_2_2018.16
  rename E0123817 EMP_DUAL_2_2018_17_XRND   // EMP_DUAL_2_2018.17
  rename E0123818 EMP_DUAL_2_2018_18_XRND   // EMP_DUAL_2_2018.18
  rename E0123819 EMP_DUAL_2_2018_19_XRND   // EMP_DUAL_2_2018.19
  rename E0123820 EMP_DUAL_2_2018_20_XRND   // EMP_DUAL_2_2018.20
  rename E0123821 EMP_DUAL_2_2018_21_XRND   // EMP_DUAL_2_2018.21
  rename E0123822 EMP_DUAL_2_2018_22_XRND   // EMP_DUAL_2_2018.22
  rename E0123823 EMP_DUAL_2_2018_23_XRND   // EMP_DUAL_2_2018.23
  rename E0123824 EMP_DUAL_2_2018_24_XRND   // EMP_DUAL_2_2018.24
  rename E0123825 EMP_DUAL_2_2018_25_XRND   // EMP_DUAL_2_2018.25
  rename E0123826 EMP_DUAL_2_2018_26_XRND   // EMP_DUAL_2_2018.26
  rename E0123827 EMP_DUAL_2_2018_27_XRND   // EMP_DUAL_2_2018.27
  rename E0123828 EMP_DUAL_2_2018_28_XRND   // EMP_DUAL_2_2018.28
  rename E0123829 EMP_DUAL_2_2018_29_XRND   // EMP_DUAL_2_2018.29
  rename E0123830 EMP_DUAL_2_2018_30_XRND   // EMP_DUAL_2_2018.30
  rename E0123831 EMP_DUAL_2_2018_31_XRND   // EMP_DUAL_2_2018.31
  rename E0123832 EMP_DUAL_2_2018_32_XRND   // EMP_DUAL_2_2018.32
  rename E0123833 EMP_DUAL_2_2018_33_XRND   // EMP_DUAL_2_2018.33
  rename E0123834 EMP_DUAL_2_2018_34_XRND   // EMP_DUAL_2_2018.34
  rename E0123835 EMP_DUAL_2_2018_35_XRND   // EMP_DUAL_2_2018.35
  rename E0123836 EMP_DUAL_2_2018_36_XRND   // EMP_DUAL_2_2018.36
  rename E0123837 EMP_DUAL_2_2018_37_XRND   // EMP_DUAL_2_2018.37
  rename E0123838 EMP_DUAL_2_2018_38_XRND   // EMP_DUAL_2_2018.38
  rename E0123839 EMP_DUAL_2_2018_39_XRND   // EMP_DUAL_2_2018.39
  rename E0123840 EMP_DUAL_2_2018_40_XRND   // EMP_DUAL_2_2018.40
  rename E0123841 EMP_DUAL_2_2018_41_XRND   // EMP_DUAL_2_2018.41
  rename E0123842 EMP_DUAL_2_2018_42_XRND   // EMP_DUAL_2_2018.42
  rename E0123843 EMP_DUAL_2_2018_43_XRND   // EMP_DUAL_2_2018.43
  rename E0123844 EMP_DUAL_2_2018_44_XRND   // EMP_DUAL_2_2018.44
  rename E0123845 EMP_DUAL_2_2018_45_XRND   // EMP_DUAL_2_2018.45
  rename E0123846 EMP_DUAL_2_2018_46_XRND   // EMP_DUAL_2_2018.46
  rename E0123847 EMP_DUAL_2_2018_47_XRND   // EMP_DUAL_2_2018.47
  rename E0123848 EMP_DUAL_2_2018_48_XRND   // EMP_DUAL_2_2018.48
  rename E0123849 EMP_DUAL_2_2018_49_XRND   // EMP_DUAL_2_2018.49
  rename E0123850 EMP_DUAL_2_2018_50_XRND   // EMP_DUAL_2_2018.50
  rename E0123851 EMP_DUAL_2_2018_51_XRND   // EMP_DUAL_2_2018.51
  rename E0123852 EMP_DUAL_2_2018_52_XRND   // EMP_DUAL_2_2018.52
  rename E0123901 EMP_DUAL_2_2019_01_XRND   // EMP_DUAL_2_2019.01
  rename E0123902 EMP_DUAL_2_2019_02_XRND   // EMP_DUAL_2_2019.02
  rename E0123903 EMP_DUAL_2_2019_03_XRND   // EMP_DUAL_2_2019.03
  rename E0123904 EMP_DUAL_2_2019_04_XRND   // EMP_DUAL_2_2019.04
  rename E0123905 EMP_DUAL_2_2019_05_XRND   // EMP_DUAL_2_2019.05
  rename E0123906 EMP_DUAL_2_2019_06_XRND   // EMP_DUAL_2_2019.06
  rename E0123907 EMP_DUAL_2_2019_07_XRND   // EMP_DUAL_2_2019.07
  rename E0123908 EMP_DUAL_2_2019_08_XRND   // EMP_DUAL_2_2019.08
  rename E0123909 EMP_DUAL_2_2019_09_XRND   // EMP_DUAL_2_2019.09
  rename E0123910 EMP_DUAL_2_2019_10_XRND   // EMP_DUAL_2_2019.10
  rename E0123911 EMP_DUAL_2_2019_11_XRND   // EMP_DUAL_2_2019.11
  rename E0123912 EMP_DUAL_2_2019_12_XRND   // EMP_DUAL_2_2019.12
  rename E0123913 EMP_DUAL_2_2019_13_XRND   // EMP_DUAL_2_2019.13
  rename E0123914 EMP_DUAL_2_2019_14_XRND   // EMP_DUAL_2_2019.14
  rename E0123915 EMP_DUAL_2_2019_15_XRND   // EMP_DUAL_2_2019.15
  rename E0123916 EMP_DUAL_2_2019_16_XRND   // EMP_DUAL_2_2019.16
  rename E0123917 EMP_DUAL_2_2019_17_XRND   // EMP_DUAL_2_2019.17
  rename E0123918 EMP_DUAL_2_2019_18_XRND   // EMP_DUAL_2_2019.18
  rename E0123919 EMP_DUAL_2_2019_19_XRND   // EMP_DUAL_2_2019.19
  rename E0123920 EMP_DUAL_2_2019_20_XRND   // EMP_DUAL_2_2019.20
  rename E0123921 EMP_DUAL_2_2019_21_XRND   // EMP_DUAL_2_2019.21
  rename E0123922 EMP_DUAL_2_2019_22_XRND   // EMP_DUAL_2_2019.22
  rename E0123923 EMP_DUAL_2_2019_23_XRND   // EMP_DUAL_2_2019.23
  rename E0123924 EMP_DUAL_2_2019_24_XRND   // EMP_DUAL_2_2019.24
  rename E0123925 EMP_DUAL_2_2019_25_XRND   // EMP_DUAL_2_2019.25
  rename E0123926 EMP_DUAL_2_2019_26_XRND   // EMP_DUAL_2_2019.26
  rename E0123927 EMP_DUAL_2_2019_27_XRND   // EMP_DUAL_2_2019.27
  rename E0123928 EMP_DUAL_2_2019_28_XRND   // EMP_DUAL_2_2019.28
  rename E0123929 EMP_DUAL_2_2019_29_XRND   // EMP_DUAL_2_2019.29
  rename E0123930 EMP_DUAL_2_2019_30_XRND   // EMP_DUAL_2_2019.30
  rename E0123931 EMP_DUAL_2_2019_31_XRND   // EMP_DUAL_2_2019.31
  rename E0123932 EMP_DUAL_2_2019_32_XRND   // EMP_DUAL_2_2019.32
  rename E0123933 EMP_DUAL_2_2019_33_XRND   // EMP_DUAL_2_2019.33
  rename E0123934 EMP_DUAL_2_2019_34_XRND   // EMP_DUAL_2_2019.34
  rename E0123935 EMP_DUAL_2_2019_35_XRND   // EMP_DUAL_2_2019.35
  rename E0123936 EMP_DUAL_2_2019_36_XRND   // EMP_DUAL_2_2019.36
  rename E0123937 EMP_DUAL_2_2019_37_XRND   // EMP_DUAL_2_2019.37
  rename E0123938 EMP_DUAL_2_2019_38_XRND   // EMP_DUAL_2_2019.38
  rename E0123939 EMP_DUAL_2_2019_39_XRND   // EMP_DUAL_2_2019.39
  rename E0123940 EMP_DUAL_2_2019_40_XRND   // EMP_DUAL_2_2019.40
  rename E0123941 EMP_DUAL_2_2019_41_XRND   // EMP_DUAL_2_2019.41
  rename E0123942 EMP_DUAL_2_2019_42_XRND   // EMP_DUAL_2_2019.42
  rename E0123943 EMP_DUAL_2_2019_43_XRND   // EMP_DUAL_2_2019.43
  rename E0123944 EMP_DUAL_2_2019_44_XRND   // EMP_DUAL_2_2019.44
  rename E0123945 EMP_DUAL_2_2019_45_XRND   // EMP_DUAL_2_2019.45
  rename E0123946 EMP_DUAL_2_2019_46_XRND   // EMP_DUAL_2_2019.46
  rename E0123947 EMP_DUAL_2_2019_47_XRND   // EMP_DUAL_2_2019.47
  rename E0123948 EMP_DUAL_2_2019_48_XRND   // EMP_DUAL_2_2019.48
  rename E0123949 EMP_DUAL_2_2019_49_XRND   // EMP_DUAL_2_2019.49
  rename E0123950 EMP_DUAL_2_2019_50_XRND   // EMP_DUAL_2_2019.50
  rename E0123951 EMP_DUAL_2_2019_51_XRND   // EMP_DUAL_2_2019.51
  rename E0123952 EMP_DUAL_2_2019_52_XRND   // EMP_DUAL_2_2019.52
  rename E0133901 EMP_DUAL_3_2019_01_XRND   // EMP_DUAL_3_2019.01
  rename E0133902 EMP_DUAL_3_2019_02_XRND   // EMP_DUAL_3_2019.02
  rename E0133903 EMP_DUAL_3_2019_03_XRND   // EMP_DUAL_3_2019.03
  rename E0133904 EMP_DUAL_3_2019_04_XRND   // EMP_DUAL_3_2019.04
  rename E0133905 EMP_DUAL_3_2019_05_XRND   // EMP_DUAL_3_2019.05
  rename E0133906 EMP_DUAL_3_2019_06_XRND   // EMP_DUAL_3_2019.06
  rename E0133907 EMP_DUAL_3_2019_07_XRND   // EMP_DUAL_3_2019.07
  rename E0133908 EMP_DUAL_3_2019_08_XRND   // EMP_DUAL_3_2019.08
  rename E0133909 EMP_DUAL_3_2019_09_XRND   // EMP_DUAL_3_2019.09
  rename E0133910 EMP_DUAL_3_2019_10_XRND   // EMP_DUAL_3_2019.10
  rename E0133911 EMP_DUAL_3_2019_11_XRND   // EMP_DUAL_3_2019.11
  rename E0133912 EMP_DUAL_3_2019_12_XRND   // EMP_DUAL_3_2019.12
  rename E0133913 EMP_DUAL_3_2019_13_XRND   // EMP_DUAL_3_2019.13
  rename E0133914 EMP_DUAL_3_2019_14_XRND   // EMP_DUAL_3_2019.14
  rename E0133915 EMP_DUAL_3_2019_15_XRND   // EMP_DUAL_3_2019.15
  rename E0133916 EMP_DUAL_3_2019_16_XRND   // EMP_DUAL_3_2019.16
  rename E0133917 EMP_DUAL_3_2019_17_XRND   // EMP_DUAL_3_2019.17
  rename E0133918 EMP_DUAL_3_2019_18_XRND   // EMP_DUAL_3_2019.18
  rename E0133919 EMP_DUAL_3_2019_19_XRND   // EMP_DUAL_3_2019.19
  rename E0133920 EMP_DUAL_3_2019_20_XRND   // EMP_DUAL_3_2019.20
  rename E0133921 EMP_DUAL_3_2019_21_XRND   // EMP_DUAL_3_2019.21
  rename E0133922 EMP_DUAL_3_2019_22_XRND   // EMP_DUAL_3_2019.22
  rename E0133923 EMP_DUAL_3_2019_23_XRND   // EMP_DUAL_3_2019.23
  rename E0133924 EMP_DUAL_3_2019_24_XRND   // EMP_DUAL_3_2019.24
  rename E0133925 EMP_DUAL_3_2019_25_XRND   // EMP_DUAL_3_2019.25
  rename E0133926 EMP_DUAL_3_2019_26_XRND   // EMP_DUAL_3_2019.26
  rename E0133927 EMP_DUAL_3_2019_27_XRND   // EMP_DUAL_3_2019.27
  rename E0133928 EMP_DUAL_3_2019_28_XRND   // EMP_DUAL_3_2019.28
  rename E0133929 EMP_DUAL_3_2019_29_XRND   // EMP_DUAL_3_2019.29
  rename E0133930 EMP_DUAL_3_2019_30_XRND   // EMP_DUAL_3_2019.30
  rename E0133931 EMP_DUAL_3_2019_31_XRND   // EMP_DUAL_3_2019.31
  rename E0133932 EMP_DUAL_3_2019_32_XRND   // EMP_DUAL_3_2019.32
  rename E0133933 EMP_DUAL_3_2019_33_XRND   // EMP_DUAL_3_2019.33
  rename E0133934 EMP_DUAL_3_2019_34_XRND   // EMP_DUAL_3_2019.34
  rename E0133935 EMP_DUAL_3_2019_35_XRND   // EMP_DUAL_3_2019.35
  rename E0133936 EMP_DUAL_3_2019_36_XRND   // EMP_DUAL_3_2019.36
  rename E0133937 EMP_DUAL_3_2019_37_XRND   // EMP_DUAL_3_2019.37
  rename E0133938 EMP_DUAL_3_2019_38_XRND   // EMP_DUAL_3_2019.38
  rename E0133939 EMP_DUAL_3_2019_39_XRND   // EMP_DUAL_3_2019.39
  rename E0133940 EMP_DUAL_3_2019_40_XRND   // EMP_DUAL_3_2019.40
  rename E0133941 EMP_DUAL_3_2019_41_XRND   // EMP_DUAL_3_2019.41
  rename E0133942 EMP_DUAL_3_2019_42_XRND   // EMP_DUAL_3_2019.42
  rename E0133943 EMP_DUAL_3_2019_43_XRND   // EMP_DUAL_3_2019.43
  rename E0133944 EMP_DUAL_3_2019_44_XRND   // EMP_DUAL_3_2019.44
  rename E0133945 EMP_DUAL_3_2019_45_XRND   // EMP_DUAL_3_2019.45
  rename E0133946 EMP_DUAL_3_2019_46_XRND   // EMP_DUAL_3_2019.46
  rename E0133947 EMP_DUAL_3_2019_47_XRND   // EMP_DUAL_3_2019.47
  rename E0133948 EMP_DUAL_3_2019_48_XRND   // EMP_DUAL_3_2019.48
  rename E0133949 EMP_DUAL_3_2019_49_XRND   // EMP_DUAL_3_2019.49
  rename E0133950 EMP_DUAL_3_2019_50_XRND   // EMP_DUAL_3_2019.50
  rename E0133951 EMP_DUAL_3_2019_51_XRND   // EMP_DUAL_3_2019.51
  rename E0133952 EMP_DUAL_3_2019_52_XRND   // EMP_DUAL_3_2019.52
  rename E0143901 EMP_DUAL_4_2019_01_XRND   // EMP_DUAL_4_2019.01
  rename E0143902 EMP_DUAL_4_2019_02_XRND   // EMP_DUAL_4_2019.02
  rename E0143903 EMP_DUAL_4_2019_03_XRND   // EMP_DUAL_4_2019.03
  rename E0143904 EMP_DUAL_4_2019_04_XRND   // EMP_DUAL_4_2019.04
  rename E0143905 EMP_DUAL_4_2019_05_XRND   // EMP_DUAL_4_2019.05
  rename E0143906 EMP_DUAL_4_2019_06_XRND   // EMP_DUAL_4_2019.06
  rename E0143907 EMP_DUAL_4_2019_07_XRND   // EMP_DUAL_4_2019.07
  rename E0143908 EMP_DUAL_4_2019_08_XRND   // EMP_DUAL_4_2019.08
  rename E0143909 EMP_DUAL_4_2019_09_XRND   // EMP_DUAL_4_2019.09
  rename E0143910 EMP_DUAL_4_2019_10_XRND   // EMP_DUAL_4_2019.10
  rename E0143911 EMP_DUAL_4_2019_11_XRND   // EMP_DUAL_4_2019.11
  rename E0143912 EMP_DUAL_4_2019_12_XRND   // EMP_DUAL_4_2019.12
  rename E0143913 EMP_DUAL_4_2019_13_XRND   // EMP_DUAL_4_2019.13
  rename E0143914 EMP_DUAL_4_2019_14_XRND   // EMP_DUAL_4_2019.14
  rename E0143915 EMP_DUAL_4_2019_15_XRND   // EMP_DUAL_4_2019.15
  rename E0143916 EMP_DUAL_4_2019_16_XRND   // EMP_DUAL_4_2019.16
  rename E0143917 EMP_DUAL_4_2019_17_XRND   // EMP_DUAL_4_2019.17
  rename E0143918 EMP_DUAL_4_2019_18_XRND   // EMP_DUAL_4_2019.18
  rename E0143919 EMP_DUAL_4_2019_19_XRND   // EMP_DUAL_4_2019.19
  rename E0143920 EMP_DUAL_4_2019_20_XRND   // EMP_DUAL_4_2019.20
  rename E0143921 EMP_DUAL_4_2019_21_XRND   // EMP_DUAL_4_2019.21
  rename E0143922 EMP_DUAL_4_2019_22_XRND   // EMP_DUAL_4_2019.22
  rename E0143923 EMP_DUAL_4_2019_23_XRND   // EMP_DUAL_4_2019.23
  rename E0143924 EMP_DUAL_4_2019_24_XRND   // EMP_DUAL_4_2019.24
  rename E0143925 EMP_DUAL_4_2019_25_XRND   // EMP_DUAL_4_2019.25
  rename E0143926 EMP_DUAL_4_2019_26_XRND   // EMP_DUAL_4_2019.26
  rename E0143927 EMP_DUAL_4_2019_27_XRND   // EMP_DUAL_4_2019.27
  rename E0143928 EMP_DUAL_4_2019_28_XRND   // EMP_DUAL_4_2019.28
  rename E0143929 EMP_DUAL_4_2019_29_XRND   // EMP_DUAL_4_2019.29
  rename E0143930 EMP_DUAL_4_2019_30_XRND   // EMP_DUAL_4_2019.30
  rename E0143931 EMP_DUAL_4_2019_31_XRND   // EMP_DUAL_4_2019.31
  rename E0143932 EMP_DUAL_4_2019_32_XRND   // EMP_DUAL_4_2019.32
  rename E0143933 EMP_DUAL_4_2019_33_XRND   // EMP_DUAL_4_2019.33
  rename E0143934 EMP_DUAL_4_2019_34_XRND   // EMP_DUAL_4_2019.34
  rename E0143935 EMP_DUAL_4_2019_35_XRND   // EMP_DUAL_4_2019.35
  rename E0143936 EMP_DUAL_4_2019_36_XRND   // EMP_DUAL_4_2019.36
  rename E0143937 EMP_DUAL_4_2019_37_XRND   // EMP_DUAL_4_2019.37
  rename E0143938 EMP_DUAL_4_2019_38_XRND   // EMP_DUAL_4_2019.38
  rename E0143939 EMP_DUAL_4_2019_39_XRND   // EMP_DUAL_4_2019.39
  rename E0143940 EMP_DUAL_4_2019_40_XRND   // EMP_DUAL_4_2019.40
  rename E0143941 EMP_DUAL_4_2019_41_XRND   // EMP_DUAL_4_2019.41
  rename E0143942 EMP_DUAL_4_2019_42_XRND   // EMP_DUAL_4_2019.42
  rename E0143943 EMP_DUAL_4_2019_43_XRND   // EMP_DUAL_4_2019.43
  rename E0143944 EMP_DUAL_4_2019_44_XRND   // EMP_DUAL_4_2019.44
  rename E0143945 EMP_DUAL_4_2019_45_XRND   // EMP_DUAL_4_2019.45
  rename E0143946 EMP_DUAL_4_2019_46_XRND   // EMP_DUAL_4_2019.46
  rename E0143947 EMP_DUAL_4_2019_47_XRND   // EMP_DUAL_4_2019.47
  rename E0143948 EMP_DUAL_4_2019_48_XRND   // EMP_DUAL_4_2019.48
  rename E0143949 EMP_DUAL_4_2019_49_XRND   // EMP_DUAL_4_2019.49
  rename E0143950 EMP_DUAL_4_2019_50_XRND   // EMP_DUAL_4_2019.50
  rename E0143951 EMP_DUAL_4_2019_51_XRND   // EMP_DUAL_4_2019.51
  rename E0143952 EMP_DUAL_4_2019_52_XRND   // EMP_DUAL_4_2019.52
  rename E0153901 EMP_DUAL_5_2019_01_XRND   // EMP_DUAL_5_2019.01
  rename E0153902 EMP_DUAL_5_2019_02_XRND   // EMP_DUAL_5_2019.02
  rename E0153903 EMP_DUAL_5_2019_03_XRND   // EMP_DUAL_5_2019.03
  rename E0153904 EMP_DUAL_5_2019_04_XRND   // EMP_DUAL_5_2019.04
  rename E0153905 EMP_DUAL_5_2019_05_XRND   // EMP_DUAL_5_2019.05
  rename E0153906 EMP_DUAL_5_2019_06_XRND   // EMP_DUAL_5_2019.06
  rename E0153907 EMP_DUAL_5_2019_07_XRND   // EMP_DUAL_5_2019.07
  rename E0153908 EMP_DUAL_5_2019_08_XRND   // EMP_DUAL_5_2019.08
  rename E0153909 EMP_DUAL_5_2019_09_XRND   // EMP_DUAL_5_2019.09
  rename E0153910 EMP_DUAL_5_2019_10_XRND   // EMP_DUAL_5_2019.10
  rename E0153911 EMP_DUAL_5_2019_11_XRND   // EMP_DUAL_5_2019.11
  rename E0153912 EMP_DUAL_5_2019_12_XRND   // EMP_DUAL_5_2019.12
  rename E0153913 EMP_DUAL_5_2019_13_XRND   // EMP_DUAL_5_2019.13
  rename E0153914 EMP_DUAL_5_2019_14_XRND   // EMP_DUAL_5_2019.14
  rename E0153915 EMP_DUAL_5_2019_15_XRND   // EMP_DUAL_5_2019.15
  rename E0153916 EMP_DUAL_5_2019_16_XRND   // EMP_DUAL_5_2019.16
  rename E0153917 EMP_DUAL_5_2019_17_XRND   // EMP_DUAL_5_2019.17
  rename E0153918 EMP_DUAL_5_2019_18_XRND   // EMP_DUAL_5_2019.18
  rename E0153919 EMP_DUAL_5_2019_19_XRND   // EMP_DUAL_5_2019.19
  rename E0153920 EMP_DUAL_5_2019_20_XRND   // EMP_DUAL_5_2019.20
  rename E0153921 EMP_DUAL_5_2019_21_XRND   // EMP_DUAL_5_2019.21
  rename E0153922 EMP_DUAL_5_2019_22_XRND   // EMP_DUAL_5_2019.22
  rename E0153923 EMP_DUAL_5_2019_23_XRND   // EMP_DUAL_5_2019.23
  rename E0153924 EMP_DUAL_5_2019_24_XRND   // EMP_DUAL_5_2019.24
  rename E0153925 EMP_DUAL_5_2019_25_XRND   // EMP_DUAL_5_2019.25
  rename E0153926 EMP_DUAL_5_2019_26_XRND   // EMP_DUAL_5_2019.26
  rename E0153927 EMP_DUAL_5_2019_27_XRND   // EMP_DUAL_5_2019.27
  rename E0153928 EMP_DUAL_5_2019_28_XRND   // EMP_DUAL_5_2019.28
  rename E0153929 EMP_DUAL_5_2019_29_XRND   // EMP_DUAL_5_2019.29
  rename E0153930 EMP_DUAL_5_2019_30_XRND   // EMP_DUAL_5_2019.30
  rename E0153931 EMP_DUAL_5_2019_31_XRND   // EMP_DUAL_5_2019.31
  rename E0153932 EMP_DUAL_5_2019_32_XRND   // EMP_DUAL_5_2019.32
  rename E0153933 EMP_DUAL_5_2019_33_XRND   // EMP_DUAL_5_2019.33
  rename E0153934 EMP_DUAL_5_2019_34_XRND   // EMP_DUAL_5_2019.34
  rename E0153935 EMP_DUAL_5_2019_35_XRND   // EMP_DUAL_5_2019.35
  rename E0153936 EMP_DUAL_5_2019_36_XRND   // EMP_DUAL_5_2019.36
  rename E0153937 EMP_DUAL_5_2019_37_XRND   // EMP_DUAL_5_2019.37
  rename E0153938 EMP_DUAL_5_2019_38_XRND   // EMP_DUAL_5_2019.38
  rename E0153939 EMP_DUAL_5_2019_39_XRND   // EMP_DUAL_5_2019.39
  rename E0153940 EMP_DUAL_5_2019_40_XRND   // EMP_DUAL_5_2019.40
  rename E0153941 EMP_DUAL_5_2019_41_XRND   // EMP_DUAL_5_2019.41
  rename E0153942 EMP_DUAL_5_2019_42_XRND   // EMP_DUAL_5_2019.42
  rename E0153943 EMP_DUAL_5_2019_43_XRND   // EMP_DUAL_5_2019.43
  rename E0153944 EMP_DUAL_5_2019_44_XRND   // EMP_DUAL_5_2019.44
  rename E0153945 EMP_DUAL_5_2019_45_XRND   // EMP_DUAL_5_2019.45
  rename E0153946 EMP_DUAL_5_2019_46_XRND   // EMP_DUAL_5_2019.46
  rename E0153947 EMP_DUAL_5_2019_47_XRND   // EMP_DUAL_5_2019.47
  rename E0153948 EMP_DUAL_5_2019_48_XRND   // EMP_DUAL_5_2019.48
  rename E0153949 EMP_DUAL_5_2019_49_XRND   // EMP_DUAL_5_2019.49
  rename E0153950 EMP_DUAL_5_2019_50_XRND   // EMP_DUAL_5_2019.50
  rename E0153951 EMP_DUAL_5_2019_51_XRND   // EMP_DUAL_5_2019.51
  rename E0153952 EMP_DUAL_5_2019_52_XRND   // EMP_DUAL_5_2019.52
  rename E0213501 EMP_START_WEEK_2019_01_XRND   // EMP_START_WEEK_2019.01
  rename E0213502 EMP_START_WEEK_2019_02_XRND   // EMP_START_WEEK_2019.02
  rename E0213503 EMP_START_WEEK_2019_03_XRND   // EMP_START_WEEK_2019.03
  rename E0213504 EMP_START_WEEK_2019_04_XRND   // EMP_START_WEEK_2019.04
  rename E0213505 EMP_START_WEEK_2019_05_XRND   // EMP_START_WEEK_2019.05
  rename E0213506 EMP_START_WEEK_2019_06_XRND   // EMP_START_WEEK_2019.06
  rename E0213507 EMP_START_WEEK_2019_07_XRND   // EMP_START_WEEK_2019.07
  rename E0213508 EMP_START_WEEK_2019_08_XRND   // EMP_START_WEEK_2019.08
  rename E0213509 EMP_START_WEEK_2019_09_XRND   // EMP_START_WEEK_2019.09
  rename E0213510 EMP_START_WEEK_2019_10_XRND   // EMP_START_WEEK_2019.10
  rename E0213511 EMP_START_WEEK_2019_11_XRND   // EMP_START_WEEK_2019.11
  rename E0223501 EMP_START_YEAR_2019_01_XRND   // EMP_START_YEAR_2019.01
  rename E0223502 EMP_START_YEAR_2019_02_XRND   // EMP_START_YEAR_2019.02
  rename E0223503 EMP_START_YEAR_2019_03_XRND   // EMP_START_YEAR_2019.03
  rename E0223504 EMP_START_YEAR_2019_04_XRND   // EMP_START_YEAR_2019.04
  rename E0223505 EMP_START_YEAR_2019_05_XRND   // EMP_START_YEAR_2019.05
  rename E0223506 EMP_START_YEAR_2019_06_XRND   // EMP_START_YEAR_2019.06
  rename E0223507 EMP_START_YEAR_2019_07_XRND   // EMP_START_YEAR_2019.07
  rename E0223508 EMP_START_YEAR_2019_08_XRND   // EMP_START_YEAR_2019.08
  rename E0223509 EMP_START_YEAR_2019_09_XRND   // EMP_START_YEAR_2019.09
  rename E0223510 EMP_START_YEAR_2019_10_XRND   // EMP_START_YEAR_2019.10
  rename E0223511 EMP_START_YEAR_2019_11_XRND   // EMP_START_YEAR_2019.11
  rename E0233501 EMP_END_WEEK_2019_01_XRND   // EMP_END_WEEK_2019.01
  rename E0233502 EMP_END_WEEK_2019_02_XRND   // EMP_END_WEEK_2019.02
  rename E0233503 EMP_END_WEEK_2019_03_XRND   // EMP_END_WEEK_2019.03
  rename E0233504 EMP_END_WEEK_2019_04_XRND   // EMP_END_WEEK_2019.04
  rename E0233505 EMP_END_WEEK_2019_05_XRND   // EMP_END_WEEK_2019.05
  rename E0233506 EMP_END_WEEK_2019_06_XRND   // EMP_END_WEEK_2019.06
  rename E0233507 EMP_END_WEEK_2019_07_XRND   // EMP_END_WEEK_2019.07
  rename E0233508 EMP_END_WEEK_2019_08_XRND   // EMP_END_WEEK_2019.08
  rename E0233509 EMP_END_WEEK_2019_09_XRND   // EMP_END_WEEK_2019.09
  rename E0233510 EMP_END_WEEK_2019_10_XRND   // EMP_END_WEEK_2019.10
  rename E0233511 EMP_END_WEEK_2019_11_XRND   // EMP_END_WEEK_2019.11
  rename E0243501 EMP_END_YEAR_2019_01_XRND   // EMP_END_YEAR_2019.01
  rename E0243502 EMP_END_YEAR_2019_02_XRND   // EMP_END_YEAR_2019.02
  rename E0243503 EMP_END_YEAR_2019_03_XRND   // EMP_END_YEAR_2019.03
  rename E0243504 EMP_END_YEAR_2019_04_XRND   // EMP_END_YEAR_2019.04
  rename E0243505 EMP_END_YEAR_2019_05_XRND   // EMP_END_YEAR_2019.05
  rename E0243506 EMP_END_YEAR_2019_06_XRND   // EMP_END_YEAR_2019.06
  rename E0243507 EMP_END_YEAR_2019_07_XRND   // EMP_END_YEAR_2019.07
  rename E0243508 EMP_END_YEAR_2019_08_XRND   // EMP_END_YEAR_2019.08
  rename E0243509 EMP_END_YEAR_2019_09_XRND   // EMP_END_YEAR_2019.09
  rename E0243510 EMP_END_YEAR_2019_10_XRND   // EMP_END_YEAR_2019.10
  rename E0243511 EMP_END_YEAR_2019_11_XRND   // EMP_END_YEAR_2019.11
  rename E1013501 EMP_GAP_START_WEEK_2019_01_01_XRND   // EMP_GAP_START_WEEK_2019.01.01
  rename E1013502 EMP_GAP_START_WEEK_2019_01_02_XRND   // EMP_GAP_START_WEEK_2019.01.02
  rename E1013503 EMP_GAP_START_WEEK_2019_01_03_XRND   // EMP_GAP_START_WEEK_2019.01.03
  rename E1013504 EMP_GAP_START_WEEK_2019_01_04_XRND   // EMP_GAP_START_WEEK_2019.01.04
  rename E1013505 EMP_GAP_START_WEEK_2019_01_05_XRND   // EMP_GAP_START_WEEK_2019.01.05
  rename E1013506 EMP_GAP_START_WEEK_2019_01_06_XRND   // EMP_GAP_START_WEEK_2019.01.06
  rename E1013507 EMP_GAP_START_WEEK_2019_01_07_XRND   // EMP_GAP_START_WEEK_2019.01.07
  rename E1013508 EMP_GAP_START_WEEK_2019_01_08_XRND   // EMP_GAP_START_WEEK_2019.01.08
  rename E1013509 EMP_GAP_START_WEEK_2019_01_09_XRND   // EMP_GAP_START_WEEK_2019.01.09
  rename E1013510 EMP_GAP_START_WEEK_2019_01_10_XRND   // EMP_GAP_START_WEEK_2019.01.10
  rename E1023501 EMP_GAP_START_WEEK_2019_02_01_XRND   // EMP_GAP_START_WEEK_2019.02.01
  rename E1023502 EMP_GAP_START_WEEK_2019_02_02_XRND   // EMP_GAP_START_WEEK_2019.02.02
  rename E1023503 EMP_GAP_START_WEEK_2019_02_03_XRND   // EMP_GAP_START_WEEK_2019.02.03
  rename E1023504 EMP_GAP_START_WEEK_2019_02_04_XRND   // EMP_GAP_START_WEEK_2019.02.04
  rename E1023505 EMP_GAP_START_WEEK_2019_02_05_XRND   // EMP_GAP_START_WEEK_2019.02.05
  rename E1033501 EMP_GAP_START_WEEK_2019_03_01_XRND   // EMP_GAP_START_WEEK_2019.03.01
  rename E1033502 EMP_GAP_START_WEEK_2019_03_02_XRND   // EMP_GAP_START_WEEK_2019.03.02
  rename E1033503 EMP_GAP_START_WEEK_2019_03_03_XRND   // EMP_GAP_START_WEEK_2019.03.03
  rename E1043501 EMP_GAP_START_WEEK_2019_04_01_XRND   // EMP_GAP_START_WEEK_2019.04.01
  rename E1043502 EMP_GAP_START_WEEK_2019_04_02_XRND   // EMP_GAP_START_WEEK_2019.04.02
  rename E1043503 EMP_GAP_START_WEEK_2019_04_03_XRND   // EMP_GAP_START_WEEK_2019.04.03
  rename E2013501 EMP_GAP_START_YEAR_2019_01_01_XRND   // EMP_GAP_START_YEAR_2019.01.01
  rename E2013502 EMP_GAP_START_YEAR_2019_01_02_XRND   // EMP_GAP_START_YEAR_2019.01.02
  rename E2013503 EMP_GAP_START_YEAR_2019_01_03_XRND   // EMP_GAP_START_YEAR_2019.01.03
  rename E2013504 EMP_GAP_START_YEAR_2019_01_04_XRND   // EMP_GAP_START_YEAR_2019.01.04
  rename E2013505 EMP_GAP_START_YEAR_2019_01_05_XRND   // EMP_GAP_START_YEAR_2019.01.05
  rename E2013506 EMP_GAP_START_YEAR_2019_01_06_XRND   // EMP_GAP_START_YEAR_2019.01.06
  rename E2013507 EMP_GAP_START_YEAR_2019_01_07_XRND   // EMP_GAP_START_YEAR_2019.01.07
  rename E2013508 EMP_GAP_START_YEAR_2019_01_08_XRND   // EMP_GAP_START_YEAR_2019.01.08
  rename E2013509 EMP_GAP_START_YEAR_2019_01_09_XRND   // EMP_GAP_START_YEAR_2019.01.09
  rename E2013510 EMP_GAP_START_YEAR_2019_01_10_XRND   // EMP_GAP_START_YEAR_2019.01.10
  rename E2023501 EMP_GAP_START_YEAR_2019_02_01_XRND   // EMP_GAP_START_YEAR_2019.02.01
  rename E2023502 EMP_GAP_START_YEAR_2019_02_02_XRND   // EMP_GAP_START_YEAR_2019.02.02
  rename E2023503 EMP_GAP_START_YEAR_2019_02_03_XRND   // EMP_GAP_START_YEAR_2019.02.03
  rename E2023504 EMP_GAP_START_YEAR_2019_02_04_XRND   // EMP_GAP_START_YEAR_2019.02.04
  rename E2023505 EMP_GAP_START_YEAR_2019_02_05_XRND   // EMP_GAP_START_YEAR_2019.02.05
  rename E2033501 EMP_GAP_START_YEAR_2019_03_01_XRND   // EMP_GAP_START_YEAR_2019.03.01
  rename E2033502 EMP_GAP_START_YEAR_2019_03_02_XRND   // EMP_GAP_START_YEAR_2019.03.02
  rename E2033503 EMP_GAP_START_YEAR_2019_03_03_XRND   // EMP_GAP_START_YEAR_2019.03.03
  rename E2043501 EMP_GAP_START_YEAR_2019_04_01_XRND   // EMP_GAP_START_YEAR_2019.04.01
  rename E2043502 EMP_GAP_START_YEAR_2019_04_02_XRND   // EMP_GAP_START_YEAR_2019.04.02
  rename E2043503 EMP_GAP_START_YEAR_2019_04_03_XRND   // EMP_GAP_START_YEAR_2019.04.03
  rename E3013501 EMP_GAP_END_WEEK_2019_01_01_XRND   // EMP_GAP_END_WEEK_2019.01.01
  rename E3013502 EMP_GAP_END_WEEK_2019_01_02_XRND   // EMP_GAP_END_WEEK_2019.01.02
  rename E3013503 EMP_GAP_END_WEEK_2019_01_03_XRND   // EMP_GAP_END_WEEK_2019.01.03
  rename E3013504 EMP_GAP_END_WEEK_2019_01_04_XRND   // EMP_GAP_END_WEEK_2019.01.04
  rename E3013505 EMP_GAP_END_WEEK_2019_01_05_XRND   // EMP_GAP_END_WEEK_2019.01.05
  rename E3013506 EMP_GAP_END_WEEK_2019_01_06_XRND   // EMP_GAP_END_WEEK_2019.01.06
  rename E3013507 EMP_GAP_END_WEEK_2019_01_07_XRND   // EMP_GAP_END_WEEK_2019.01.07
  rename E3013508 EMP_GAP_END_WEEK_2019_01_08_XRND   // EMP_GAP_END_WEEK_2019.01.08
  rename E3013509 EMP_GAP_END_WEEK_2019_01_09_XRND   // EMP_GAP_END_WEEK_2019.01.09
  rename E3013510 EMP_GAP_END_WEEK_2019_01_10_XRND   // EMP_GAP_END_WEEK_2019.01.10
  rename E3023501 EMP_GAP_END_WEEK_2019_02_01_XRND   // EMP_GAP_END_WEEK_2019.02.01
  rename E3023502 EMP_GAP_END_WEEK_2019_02_02_XRND   // EMP_GAP_END_WEEK_2019.02.02
  rename E3023503 EMP_GAP_END_WEEK_2019_02_03_XRND   // EMP_GAP_END_WEEK_2019.02.03
  rename E3023504 EMP_GAP_END_WEEK_2019_02_04_XRND   // EMP_GAP_END_WEEK_2019.02.04
  rename E3023505 EMP_GAP_END_WEEK_2019_02_05_XRND   // EMP_GAP_END_WEEK_2019.02.05
  rename E3033501 EMP_GAP_END_WEEK_2019_03_01_XRND   // EMP_GAP_END_WEEK_2019.03.01
  rename E3033502 EMP_GAP_END_WEEK_2019_03_02_XRND   // EMP_GAP_END_WEEK_2019.03.02
  rename E3033503 EMP_GAP_END_WEEK_2019_03_03_XRND   // EMP_GAP_END_WEEK_2019.03.03
  rename E3043501 EMP_GAP_END_WEEK_2019_04_01_XRND   // EMP_GAP_END_WEEK_2019.04.01
  rename E3043502 EMP_GAP_END_WEEK_2019_04_02_XRND   // EMP_GAP_END_WEEK_2019.04.02
  rename E3043503 EMP_GAP_END_WEEK_2019_04_03_XRND   // EMP_GAP_END_WEEK_2019.04.03
  rename E4013501 EMP_GAP_END_YEAR_2019_01_01_XRND   // EMP_GAP_END_YEAR_2019.01.01
  rename E4013502 EMP_GAP_END_YEAR_2019_01_02_XRND   // EMP_GAP_END_YEAR_2019.01.02
  rename E4013503 EMP_GAP_END_YEAR_2019_01_03_XRND   // EMP_GAP_END_YEAR_2019.01.03
  rename E4013504 EMP_GAP_END_YEAR_2019_01_04_XRND   // EMP_GAP_END_YEAR_2019.01.04
  rename E4013505 EMP_GAP_END_YEAR_2019_01_05_XRND   // EMP_GAP_END_YEAR_2019.01.05
  rename E4013506 EMP_GAP_END_YEAR_2019_01_06_XRND   // EMP_GAP_END_YEAR_2019.01.06
  rename E4013507 EMP_GAP_END_YEAR_2019_01_07_XRND   // EMP_GAP_END_YEAR_2019.01.07
  rename E4013508 EMP_GAP_END_YEAR_2019_01_08_XRND   // EMP_GAP_END_YEAR_2019.01.08
  rename E4013509 EMP_GAP_END_YEAR_2019_01_09_XRND   // EMP_GAP_END_YEAR_2019.01.09
  rename E4013510 EMP_GAP_END_YEAR_2019_01_10_XRND   // EMP_GAP_END_YEAR_2019.01.10
  rename E4023501 EMP_GAP_END_YEAR_2019_02_01_XRND   // EMP_GAP_END_YEAR_2019.02.01
  rename E4023502 EMP_GAP_END_YEAR_2019_02_02_XRND   // EMP_GAP_END_YEAR_2019.02.02
  rename E4023503 EMP_GAP_END_YEAR_2019_02_03_XRND   // EMP_GAP_END_YEAR_2019.02.03
  rename E4023504 EMP_GAP_END_YEAR_2019_02_04_XRND   // EMP_GAP_END_YEAR_2019.02.04
  rename E4023505 EMP_GAP_END_YEAR_2019_02_05_XRND   // EMP_GAP_END_YEAR_2019.02.05
  rename E4033501 EMP_GAP_END_YEAR_2019_03_01_XRND   // EMP_GAP_END_YEAR_2019.03.01
  rename E4033502 EMP_GAP_END_YEAR_2019_03_02_XRND   // EMP_GAP_END_YEAR_2019.03.02
  rename E4033503 EMP_GAP_END_YEAR_2019_03_03_XRND   // EMP_GAP_END_YEAR_2019.03.03
  rename E4043501 EMP_GAP_END_YEAR_2019_04_01_XRND   // EMP_GAP_END_YEAR_2019.04.01
  rename E4043502 EMP_GAP_END_YEAR_2019_04_02_XRND   // EMP_GAP_END_YEAR_2019.04.02
  rename E4043503 EMP_GAP_END_YEAR_2019_04_03_XRND   // EMP_GAP_END_YEAR_2019.04.03
  rename E6413901 UNEMP_STATUS_2019_01_XRND   // UNEMP_STATUS_2019.01
  rename E6413902 UNEMP_STATUS_2019_02_XRND   // UNEMP_STATUS_2019.02
  rename E6413903 UNEMP_STATUS_2019_03_XRND   // UNEMP_STATUS_2019.03
  rename E6413904 UNEMP_STATUS_2019_04_XRND   // UNEMP_STATUS_2019.04
  rename E6413905 UNEMP_STATUS_2019_05_XRND   // UNEMP_STATUS_2019.05
  rename E6413906 UNEMP_STATUS_2019_06_XRND   // UNEMP_STATUS_2019.06
  rename E6413907 UNEMP_STATUS_2019_07_XRND   // UNEMP_STATUS_2019.07
  rename E6413908 UNEMP_STATUS_2019_08_XRND   // UNEMP_STATUS_2019.08
  rename E6413909 UNEMP_STATUS_2019_09_XRND   // UNEMP_STATUS_2019.09
  rename E6413910 UNEMP_STATUS_2019_10_XRND   // UNEMP_STATUS_2019.10
  rename E6413911 UNEMP_STATUS_2019_11_XRND   // UNEMP_STATUS_2019.11
  rename E6413912 UNEMP_STATUS_2019_12_XRND   // UNEMP_STATUS_2019.12
  rename E6423901 UNEMP_AMT_2019_01_XRND   // UNEMP_AMT_2019.01
  rename E6423902 UNEMP_AMT_2019_02_XRND   // UNEMP_AMT_2019.02
  rename E6423903 UNEMP_AMT_2019_03_XRND   // UNEMP_AMT_2019.03
  rename E6423904 UNEMP_AMT_2019_04_XRND   // UNEMP_AMT_2019.04
  rename E6423905 UNEMP_AMT_2019_05_XRND   // UNEMP_AMT_2019.05
  rename E6423906 UNEMP_AMT_2019_06_XRND   // UNEMP_AMT_2019.06
  rename E6423907 UNEMP_AMT_2019_07_XRND   // UNEMP_AMT_2019.07
  rename E6423908 UNEMP_AMT_2019_08_XRND   // UNEMP_AMT_2019.08
  rename E6423909 UNEMP_AMT_2019_09_XRND   // UNEMP_AMT_2019.09
  rename E6423910 UNEMP_AMT_2019_10_XRND   // UNEMP_AMT_2019.10
  rename E6423911 UNEMP_AMT_2019_11_XRND   // UNEMP_AMT_2019.11
  rename E6423912 UNEMP_AMT_2019_12_XRND   // UNEMP_AMT_2019.12
  rename E6443501 UNEMP_START_MONTH_2019_01_XRND   // UNEMP_START_MONTH_2019.01
  rename E6443502 UNEMP_START_MONTH_2019_02_XRND   // UNEMP_START_MONTH_2019.02
  rename E6443503 UNEMP_START_MONTH_2019_03_XRND   // UNEMP_START_MONTH_2019.03
  rename E6443504 UNEMP_START_MONTH_2019_04_XRND   // UNEMP_START_MONTH_2019.04
  rename E6453501 UNEMP_STOP_MONTH_2019_01_XRND   // UNEMP_STOP_MONTH_2019.01
  rename E6453502 UNEMP_STOP_MONTH_2019_02_XRND   // UNEMP_STOP_MONTH_2019.02
  rename E6453503 UNEMP_STOP_MONTH_2019_03_XRND   // UNEMP_STOP_MONTH_2019.03
  rename E6453504 UNEMP_STOP_MONTH_2019_04_XRND   // UNEMP_STOP_MONTH_2019.04
  rename E6473501 UNEMP_EDIT_DATE_2019_01_XRND   // UNEMP_EDIT_DATE_2019.01
  rename E6473502 UNEMP_EDIT_DATE_2019_02_XRND   // UNEMP_EDIT_DATE_2019.02
  rename E6473503 UNEMP_EDIT_DATE_2019_03_XRND   // UNEMP_EDIT_DATE_2019.03
  rename E6473504 UNEMP_EDIT_DATE_2019_04_XRND   // UNEMP_EDIT_DATE_2019.04
  rename E7013801 MAR_STATUS_2018_01_XRND   // MAR_STATUS_2018.01
  rename E7013802 MAR_STATUS_2018_02_XRND   // MAR_STATUS_2018.02
  rename E7013803 MAR_STATUS_2018_03_XRND   // MAR_STATUS_2018.03
  rename E7013804 MAR_STATUS_2018_04_XRND   // MAR_STATUS_2018.04
  rename E7013805 MAR_STATUS_2018_05_XRND   // MAR_STATUS_2018.05
  rename E7013806 MAR_STATUS_2018_06_XRND   // MAR_STATUS_2018.06
  rename E7013807 MAR_STATUS_2018_07_XRND   // MAR_STATUS_2018.07
  rename E7013808 MAR_STATUS_2018_08_XRND   // MAR_STATUS_2018.08
  rename E7013809 MAR_STATUS_2018_09_XRND   // MAR_STATUS_2018.09
  rename E7013810 MAR_STATUS_2018_10_XRND   // MAR_STATUS_2018.10
  rename E7013811 MAR_STATUS_2018_11_XRND   // MAR_STATUS_2018.11
  rename E7013812 MAR_STATUS_2018_12_XRND   // MAR_STATUS_2018.12
  rename E7013901 MAR_STATUS_2019_01_XRND   // MAR_STATUS_2019.01
  rename E7013902 MAR_STATUS_2019_02_XRND   // MAR_STATUS_2019.02
  rename E7013903 MAR_STATUS_2019_03_XRND   // MAR_STATUS_2019.03
  rename E7013904 MAR_STATUS_2019_04_XRND   // MAR_STATUS_2019.04
  rename E7013905 MAR_STATUS_2019_05_XRND   // MAR_STATUS_2019.05
  rename E7013906 MAR_STATUS_2019_06_XRND   // MAR_STATUS_2019.06
  rename E7013907 MAR_STATUS_2019_07_XRND   // MAR_STATUS_2019.07
  rename E7013908 MAR_STATUS_2019_08_XRND   // MAR_STATUS_2019.08
  rename E7013909 MAR_STATUS_2019_09_XRND   // MAR_STATUS_2019.09
  rename E7013910 MAR_STATUS_2019_10_XRND   // MAR_STATUS_2019.10
  rename E7013911 MAR_STATUS_2019_11_XRND   // MAR_STATUS_2019.11
  rename E7013912 MAR_STATUS_2019_12_XRND   // MAR_STATUS_2019.12
  rename E7023801 MAR_COHABITATION_2018_01_XRND   // MAR_COHABITATION_2018.01
  rename E7023802 MAR_COHABITATION_2018_02_XRND   // MAR_COHABITATION_2018.02
  rename E7023803 MAR_COHABITATION_2018_03_XRND   // MAR_COHABITATION_2018.03
  rename E7023804 MAR_COHABITATION_2018_04_XRND   // MAR_COHABITATION_2018.04
  rename E7023805 MAR_COHABITATION_2018_05_XRND   // MAR_COHABITATION_2018.05
  rename E7023806 MAR_COHABITATION_2018_06_XRND   // MAR_COHABITATION_2018.06
  rename E7023807 MAR_COHABITATION_2018_07_XRND   // MAR_COHABITATION_2018.07
  rename E7023808 MAR_COHABITATION_2018_08_XRND   // MAR_COHABITATION_2018.08
  rename E7023809 MAR_COHABITATION_2018_09_XRND   // MAR_COHABITATION_2018.09
  rename E7023810 MAR_COHABITATION_2018_10_XRND   // MAR_COHABITATION_2018.10
  rename E7023811 MAR_COHABITATION_2018_11_XRND   // MAR_COHABITATION_2018.11
  rename E7023812 MAR_COHABITATION_2018_12_XRND   // MAR_COHABITATION_2018.12
  rename E7023901 MAR_COHABITATION_2019_01_XRND   // MAR_COHABITATION_2019.01
  rename E7023902 MAR_COHABITATION_2019_02_XRND   // MAR_COHABITATION_2019.02
  rename E7023903 MAR_COHABITATION_2019_03_XRND   // MAR_COHABITATION_2019.03
  rename E7023904 MAR_COHABITATION_2019_04_XRND   // MAR_COHABITATION_2019.04
  rename E7023905 MAR_COHABITATION_2019_05_XRND   // MAR_COHABITATION_2019.05
  rename E7023906 MAR_COHABITATION_2019_06_XRND   // MAR_COHABITATION_2019.06
  rename E7023907 MAR_COHABITATION_2019_07_XRND   // MAR_COHABITATION_2019.07
  rename E7023908 MAR_COHABITATION_2019_08_XRND   // MAR_COHABITATION_2019.08
  rename E7023909 MAR_COHABITATION_2019_09_XRND   // MAR_COHABITATION_2019.09
  rename E7023910 MAR_COHABITATION_2019_10_XRND   // MAR_COHABITATION_2019.10
  rename E7023911 MAR_COHABITATION_2019_11_XRND   // MAR_COHABITATION_2019.11
  rename E7023912 MAR_COHABITATION_2019_12_XRND   // MAR_COHABITATION_2019.12
  rename E7033801 MAR_PARTNER_LINK_2018_01_XRND   // MAR_PARTNER_LINK_2018.01
  rename E7033802 MAR_PARTNER_LINK_2018_02_XRND   // MAR_PARTNER_LINK_2018.02
  rename E7033803 MAR_PARTNER_LINK_2018_03_XRND   // MAR_PARTNER_LINK_2018.03
  rename E7033804 MAR_PARTNER_LINK_2018_04_XRND   // MAR_PARTNER_LINK_2018.04
  rename E7033805 MAR_PARTNER_LINK_2018_05_XRND   // MAR_PARTNER_LINK_2018.05
  rename E7033806 MAR_PARTNER_LINK_2018_06_XRND   // MAR_PARTNER_LINK_2018.06
  rename E7033807 MAR_PARTNER_LINK_2018_07_XRND   // MAR_PARTNER_LINK_2018.07
  rename E7033808 MAR_PARTNER_LINK_2018_08_XRND   // MAR_PARTNER_LINK_2018.08
  rename E7033809 MAR_PARTNER_LINK_2018_09_XRND   // MAR_PARTNER_LINK_2018.09
  rename E7033810 MAR_PARTNER_LINK_2018_10_XRND   // MAR_PARTNER_LINK_2018.10
  rename E7033811 MAR_PARTNER_LINK_2018_11_XRND   // MAR_PARTNER_LINK_2018.11
  rename E7033812 MAR_PARTNER_LINK_2018_12_XRND   // MAR_PARTNER_LINK_2018.12
  rename E7033901 MAR_PARTNER_LINK_2019_01_XRND   // MAR_PARTNER_LINK_2019.01
  rename E7033902 MAR_PARTNER_LINK_2019_02_XRND   // MAR_PARTNER_LINK_2019.02
  rename E7033903 MAR_PARTNER_LINK_2019_03_XRND   // MAR_PARTNER_LINK_2019.03
  rename E7033904 MAR_PARTNER_LINK_2019_04_XRND   // MAR_PARTNER_LINK_2019.04
  rename E7033905 MAR_PARTNER_LINK_2019_05_XRND   // MAR_PARTNER_LINK_2019.05
  rename E7033906 MAR_PARTNER_LINK_2019_06_XRND   // MAR_PARTNER_LINK_2019.06
  rename E7033907 MAR_PARTNER_LINK_2019_07_XRND   // MAR_PARTNER_LINK_2019.07
  rename E7033908 MAR_PARTNER_LINK_2019_08_XRND   // MAR_PARTNER_LINK_2019.08
  rename E7033909 MAR_PARTNER_LINK_2019_09_XRND   // MAR_PARTNER_LINK_2019.09
  rename E7033910 MAR_PARTNER_LINK_2019_10_XRND   // MAR_PARTNER_LINK_2019.10
  rename E7033911 MAR_PARTNER_LINK_2019_11_XRND   // MAR_PARTNER_LINK_2019.11
  rename E7033912 MAR_PARTNER_LINK_2019_12_XRND   // MAR_PARTNER_LINK_2019.12
  rename E7043500 MAR_DUAL_DLI_2019_XRND 
  rename E8023901 INCARC_STATUS_2019_01_XRND   // INCARC_STATUS_2019.01
  rename E8023902 INCARC_STATUS_2019_02_XRND   // INCARC_STATUS_2019.02
  rename E8023903 INCARC_STATUS_2019_03_XRND   // INCARC_STATUS_2019.03
  rename E8023904 INCARC_STATUS_2019_04_XRND   // INCARC_STATUS_2019.04
  rename E8023905 INCARC_STATUS_2019_05_XRND   // INCARC_STATUS_2019.05
  rename E8023906 INCARC_STATUS_2019_06_XRND   // INCARC_STATUS_2019.06
  rename E8023907 INCARC_STATUS_2019_07_XRND   // INCARC_STATUS_2019.07
  rename E8023908 INCARC_STATUS_2019_08_XRND   // INCARC_STATUS_2019.08
  rename E8023909 INCARC_STATUS_2019_09_XRND   // INCARC_STATUS_2019.09
  rename E8023910 INCARC_STATUS_2019_10_XRND   // INCARC_STATUS_2019.10
  rename E8023911 INCARC_STATUS_2019_11_XRND   // INCARC_STATUS_2019.11
  rename E8023912 INCARC_STATUS_2019_12_XRND   // INCARC_STATUS_2019.12
  rename E8043100 INCARC_TOTNUM_XRND 
  rename E8043500 INCARC_TOTMONTHS_XRND 
  rename E8043600 INCARC_CURRENT_XRND 
  rename R0000100 PUBID_1997 
  rename R0536300 KEY!SEX_1997 
  rename R0536401 KEY!BDATE_M_1997 
  rename R0536402 KEY!BDATE_Y_1997 
  rename R0536600 KEY!AGE_1997 
  rename R0536700 KEY!AGEDOL_1997 
  rename R1097800 HHI2_HHI1ID_01_1997   // HHI2_HHI1ID.01
  rename R1097900 HHI2_HHI1ID_02_1997   // HHI2_HHI1ID.02
  rename R1098000 HHI2_HHI1ID_03_1997   // HHI2_HHI1ID.03
  rename R1098100 HHI2_HHI1ID_04_1997   // HHI2_HHI1ID.04
  rename R1098200 HHI2_HHI1ID_05_1997   // HHI2_HHI1ID.05
  rename R1098300 HHI2_HHI1ID_06_1997   // HHI2_HHI1ID.06
  rename R1098400 HHI2_HHI1ID_07_1997   // HHI2_HHI1ID.07
  rename R1098500 HHI2_HHI1ID_08_1997   // HHI2_HHI1ID.08
  rename R1098600 HHI2_HHI1ID_09_1997   // HHI2_HHI1ID.09
  rename R1098700 HHI2_HHI1ID_10_1997   // HHI2_HHI1ID.10
  rename R1098800 HHI2_HHI1ID_11_1997   // HHI2_HHI1ID.11
  rename R1098900 HHI2_HHI1ID_12_1997   // HHI2_HHI1ID.12
  rename R1099000 HHI2_HHI1ID_13_1997   // HHI2_HHI1ID.13
  rename R1099100 HHI2_HHI1ID_14_1997   // HHI2_HHI1ID.14
  rename R1099200 HHI2_HHI1ID_15_1997   // HHI2_HHI1ID.15
  rename R1099300 HHI2_HHI1ID_16_1997   // HHI2_HHI1ID.16
  rename R1101000 HHI2_ID_01_1997   // HHI2_ID.01
  rename R1101100 HHI2_ID_02_1997   // HHI2_ID.02
  rename R1101200 HHI2_ID_03_1997   // HHI2_ID.03
  rename R1101300 HHI2_ID_04_1997   // HHI2_ID.04
  rename R1101400 HHI2_ID_05_1997   // HHI2_ID.05
  rename R1101500 HHI2_ID_06_1997   // HHI2_ID.06
  rename R1101600 HHI2_ID_07_1997   // HHI2_ID.07
  rename R1101700 HHI2_ID_08_1997   // HHI2_ID.08
  rename R1101800 HHI2_ID_09_1997   // HHI2_ID.09
  rename R1101900 HHI2_ID_10_1997   // HHI2_ID.10
  rename R1102000 HHI2_ID_11_1997   // HHI2_ID.11
  rename R1102100 HHI2_ID_12_1997   // HHI2_ID.12
  rename R1102200 HHI2_ID_13_1997   // HHI2_ID.13
  rename R1102300 HHI2_ID_14_1997   // HHI2_ID.14
  rename R1102400 HHI2_ID_15_1997   // HHI2_ID.15
  rename R1102500 HHI2_ID_16_1997   // HHI2_ID.16
  rename R1102501 HHI2_ID_17_1997   // HHI2_ID.17
  rename R1193000 SIDCODE_1997 
  rename R1235800 CV_SAMPLE_TYPE_1997 
  rename R1482600 KEY!RACE_ETHNICITY_1997 
  rename T6656400 CV_ENROLLSTAT_2011 
  rename T6657200 CV_HIGHEST_DEGREE_EVER_EDT_2011 
  rename T6657300 CV_HIGHEST_DEGREE_1112_2011 
  rename U0008700 CV_ENROLLSTAT_2015 
  rename U0009400 CV_HIGHEST_DEGREE_EVER_EDT_2015 
  rename U3300300 RNI_2019 
  rename U3316800 HHI_RACE_01_000001_2019   // HHI_RACE.01~000001
  rename U3316801 HHI_RACE_01_000002_2019   // HHI_RACE.01~000002
  rename U3316802 HHI_RACE_01_000003_2019   // HHI_RACE.01~000003
  rename U3316803 HHI_RACE_01_000004_2019   // HHI_RACE.01~000004
  rename U3316804 HHI_RACE_01_000005_2019   // HHI_RACE.01~000005
  rename U3316805 HHI_RACE_01_000006_2019   // HHI_RACE.01~000006
  rename U3316806 HHI_RACE_01_000007_2019   // HHI_RACE.01~000007
  rename U3316807 HHI_RACE_01_000008_2019   // HHI_RACE.01~000008
  rename U3316808 HHI_RACE_01_000009_2019   // HHI_RACE.01~000009
  rename U3316809 HHI_RACE_01_000999_2019   // HHI_RACE.01~000999
  rename U3316900 HHI_RACE_02_000001_2019   // HHI_RACE.02~000001
  rename U3316901 HHI_RACE_02_000002_2019   // HHI_RACE.02~000002
  rename U3316902 HHI_RACE_02_000003_2019   // HHI_RACE.02~000003
  rename U3316903 HHI_RACE_02_000004_2019   // HHI_RACE.02~000004
  rename U3316904 HHI_RACE_02_000005_2019   // HHI_RACE.02~000005
  rename U3316905 HHI_RACE_02_000006_2019   // HHI_RACE.02~000006
  rename U3316906 HHI_RACE_02_000007_2019   // HHI_RACE.02~000007
  rename U3316907 HHI_RACE_02_000008_2019   // HHI_RACE.02~000008
  rename U3316908 HHI_RACE_02_000009_2019   // HHI_RACE.02~000009
  rename U3316909 HHI_RACE_02_000999_2019   // HHI_RACE.02~000999
  rename U3317000 HHI_RACE_03_000001_2019   // HHI_RACE.03~000001
  rename U3317001 HHI_RACE_03_000002_2019   // HHI_RACE.03~000002
  rename U3317002 HHI_RACE_03_000003_2019   // HHI_RACE.03~000003
  rename U3317003 HHI_RACE_03_000004_2019   // HHI_RACE.03~000004
  rename U3317004 HHI_RACE_03_000005_2019   // HHI_RACE.03~000005
  rename U3317005 HHI_RACE_03_000006_2019   // HHI_RACE.03~000006
  rename U3317006 HHI_RACE_03_000007_2019   // HHI_RACE.03~000007
  rename U3317007 HHI_RACE_03_000008_2019   // HHI_RACE.03~000008
  rename U3317008 HHI_RACE_03_000009_2019   // HHI_RACE.03~000009
  rename U3317009 HHI_RACE_03_000999_2019   // HHI_RACE.03~000999
  rename U3317100 HHI_RACE_04_000001_2019   // HHI_RACE.04~000001
  rename U3317101 HHI_RACE_04_000002_2019   // HHI_RACE.04~000002
  rename U3317102 HHI_RACE_04_000003_2019   // HHI_RACE.04~000003
  rename U3317103 HHI_RACE_04_000004_2019   // HHI_RACE.04~000004
  rename U3317104 HHI_RACE_04_000005_2019   // HHI_RACE.04~000005
  rename U3317105 HHI_RACE_04_000006_2019   // HHI_RACE.04~000006
  rename U3317106 HHI_RACE_04_000007_2019   // HHI_RACE.04~000007
  rename U3317107 HHI_RACE_04_000008_2019   // HHI_RACE.04~000008
  rename U3317109 HHI_RACE_04_000999_2019   // HHI_RACE.04~000999
  rename U3317200 HHI_RACE_05_000001_2019   // HHI_RACE.05~000001
  rename U3317201 HHI_RACE_05_000002_2019   // HHI_RACE.05~000002
  rename U3317202 HHI_RACE_05_000003_2019   // HHI_RACE.05~000003
  rename U3317203 HHI_RACE_05_000004_2019   // HHI_RACE.05~000004
  rename U3317204 HHI_RACE_05_000005_2019   // HHI_RACE.05~000005
  rename U3317205 HHI_RACE_05_000006_2019   // HHI_RACE.05~000006
  rename U3317206 HHI_RACE_05_000007_2019   // HHI_RACE.05~000007
  rename U3317209 HHI_RACE_05_000999_2019   // HHI_RACE.05~000999
  rename U3317300 HHI_RACE_06_000001_2019   // HHI_RACE.06~000001
  rename U3317301 HHI_RACE_06_000002_2019   // HHI_RACE.06~000002
  rename U3317302 HHI_RACE_06_000003_2019   // HHI_RACE.06~000003
  rename U3317303 HHI_RACE_06_000004_2019   // HHI_RACE.06~000004
  rename U3317304 HHI_RACE_06_000005_2019   // HHI_RACE.06~000005
  rename U3317305 HHI_RACE_06_000006_2019   // HHI_RACE.06~000006
  rename U3317306 HHI_RACE_06_000007_2019   // HHI_RACE.06~000007
  rename U3317308 HHI_RACE_06_000009_2019   // HHI_RACE.06~000009
  rename U3317309 HHI_RACE_06_000999_2019   // HHI_RACE.06~000999
  rename U3317400 HHI_RACE_07_000001_2019   // HHI_RACE.07~000001
  rename U3317401 HHI_RACE_07_000002_2019   // HHI_RACE.07~000002
  rename U3317402 HHI_RACE_07_000003_2019   // HHI_RACE.07~000003
  rename U3317403 HHI_RACE_07_000004_2019   // HHI_RACE.07~000004
  rename U3317404 HHI_RACE_07_000005_2019   // HHI_RACE.07~000005
  rename U3317405 HHI_RACE_07_000006_2019   // HHI_RACE.07~000006
  rename U3317406 HHI_RACE_07_000007_2019   // HHI_RACE.07~000007
  rename U3317409 HHI_RACE_07_000999_2019   // HHI_RACE.07~000999
  rename U3317500 HHI_RACE_08_000001_2019   // HHI_RACE.08~000001
  rename U3317501 HHI_RACE_08_000002_2019   // HHI_RACE.08~000002
  rename U3317502 HHI_RACE_08_000003_2019   // HHI_RACE.08~000003
  rename U3317503 HHI_RACE_08_000004_2019   // HHI_RACE.08~000004
  rename U3317504 HHI_RACE_08_000005_2019   // HHI_RACE.08~000005
  rename U3317505 HHI_RACE_08_000006_2019   // HHI_RACE.08~000006
  rename U3317506 HHI_RACE_08_000007_2019   // HHI_RACE.08~000007
  rename U3317509 HHI_RACE_08_000999_2019   // HHI_RACE.08~000999
  rename U3317600 HHI_RACE_09_000001_2019   // HHI_RACE.09~000001
  rename U3317601 HHI_RACE_09_000002_2019   // HHI_RACE.09~000002
  rename U3317602 HHI_RACE_09_000003_2019   // HHI_RACE.09~000003
  rename U3317603 HHI_RACE_09_000004_2019   // HHI_RACE.09~000004
  rename U3317604 HHI_RACE_09_000005_2019   // HHI_RACE.09~000005
  rename U3317605 HHI_RACE_09_000006_2019   // HHI_RACE.09~000006
  rename U3317606 HHI_RACE_09_000007_2019   // HHI_RACE.09~000007
  rename U3317609 HHI_RACE_09_000999_2019   // HHI_RACE.09~000999
  rename U3317700 HHI_RACE_10_000001_2019   // HHI_RACE.10~000001
  rename U3317701 HHI_RACE_10_000002_2019   // HHI_RACE.10~000002
  rename U3317702 HHI_RACE_10_000003_2019   // HHI_RACE.10~000003
  rename U3317703 HHI_RACE_10_000004_2019   // HHI_RACE.10~000004
  rename U3317704 HHI_RACE_10_000005_2019   // HHI_RACE.10~000005
  rename U3317705 HHI_RACE_10_000006_2019   // HHI_RACE.10~000006
  rename U3317706 HHI_RACE_10_000007_2019   // HHI_RACE.10~000007
  rename U3317800 HHI_RACE_11_000001_2019   // HHI_RACE.11~000001
  rename U3317801 HHI_RACE_11_000002_2019   // HHI_RACE.11~000002
  rename U3317802 HHI_RACE_11_000003_2019   // HHI_RACE.11~000003
  rename U3317803 HHI_RACE_11_000004_2019   // HHI_RACE.11~000004
  rename U3317804 HHI_RACE_11_000005_2019   // HHI_RACE.11~000005
  rename U3317805 HHI_RACE_11_000006_2019   // HHI_RACE.11~000006
  rename U3317806 HHI_RACE_11_000007_2019   // HHI_RACE.11~000007
  rename U3317809 HHI_RACE_11_000999_2019   // HHI_RACE.11~000999
  rename U3317900 HHI_RACE_12_000001_2019   // HHI_RACE.12~000001
  rename U3317901 HHI_RACE_12_000002_2019   // HHI_RACE.12~000002
  rename U3317902 HHI_RACE_12_000003_2019   // HHI_RACE.12~000003
  rename U3317903 HHI_RACE_12_000004_2019   // HHI_RACE.12~000004
  rename U3317904 HHI_RACE_12_000005_2019   // HHI_RACE.12~000005
  rename U3317905 HHI_RACE_12_000006_2019   // HHI_RACE.12~000006
  rename U3317906 HHI_RACE_12_000007_2019   // HHI_RACE.12~000007
  rename U3318000 HHI_RACE_13_000001_2019   // HHI_RACE.13~000001
  rename U3318001 HHI_RACE_13_000002_2019   // HHI_RACE.13~000002
  rename U3318002 HHI_RACE_13_000003_2019   // HHI_RACE.13~000003
  rename U3318003 HHI_RACE_13_000004_2019   // HHI_RACE.13~000004
  rename U3318004 HHI_RACE_13_000005_2019   // HHI_RACE.13~000005
  rename U3318005 HHI_RACE_13_000006_2019   // HHI_RACE.13~000006
  rename U3318006 HHI_RACE_13_000007_2019   // HHI_RACE.13~000007
  rename U3318009 HHI_RACE_13_000999_2019   // HHI_RACE.13~000999
  rename U3318100 HHI_RACE_14_000001_2019   // HHI_RACE.14~000001
  rename U3318101 HHI_RACE_14_000002_2019   // HHI_RACE.14~000002
  rename U3318102 HHI_RACE_14_000003_2019   // HHI_RACE.14~000003
  rename U3318103 HHI_RACE_14_000004_2019   // HHI_RACE.14~000004
  rename U3318104 HHI_RACE_14_000005_2019   // HHI_RACE.14~000005
  rename U3318105 HHI_RACE_14_000006_2019   // HHI_RACE.14~000006
  rename U3318106 HHI_RACE_14_000007_2019   // HHI_RACE.14~000007
  rename U3318200 HHI_RACE_15_000001_2019   // HHI_RACE.15~000001
  rename U3318201 HHI_RACE_15_000002_2019   // HHI_RACE.15~000002
  rename U3318202 HHI_RACE_15_000003_2019   // HHI_RACE.15~000003
  rename U3318203 HHI_RACE_15_000004_2019   // HHI_RACE.15~000004
  rename U3318204 HHI_RACE_15_000005_2019   // HHI_RACE.15~000005
  rename U3318205 HHI_RACE_15_000006_2019   // HHI_RACE.15~000006
  rename U3318206 HHI_RACE_15_000007_2019   // HHI_RACE.15~000007
  rename U3318300 HHI_RACE_16_000001_2019   // HHI_RACE.16~000001
  rename U3318301 HHI_RACE_16_000002_2019   // HHI_RACE.16~000002
  rename U3318302 HHI_RACE_16_000003_2019   // HHI_RACE.16~000003
  rename U3318303 HHI_RACE_16_000004_2019   // HHI_RACE.16~000004
  rename U3318304 HHI_RACE_16_000005_2019   // HHI_RACE.16~000005
  rename U3318305 HHI_RACE_16_000006_2019   // HHI_RACE.16~000006
  rename U3318306 HHI_RACE_16_000007_2019   // HHI_RACE.16~000007
  rename U3318400 HHI_RACE_17_000001_2019   // HHI_RACE.17~000001
  rename U3318401 HHI_RACE_17_000002_2019   // HHI_RACE.17~000002
  rename U3318402 HHI_RACE_17_000003_2019   // HHI_RACE.17~000003
  rename U3318403 HHI_RACE_17_000004_2019   // HHI_RACE.17~000004
  rename U3318404 HHI_RACE_17_000005_2019   // HHI_RACE.17~000005
  rename U3318405 HHI_RACE_17_000006_2019   // HHI_RACE.17~000006
  rename U3318406 HHI_RACE_17_000007_2019   // HHI_RACE.17~000007
  rename U3319400 HHI_INCOME_01_2019   // HHI_INCOME.01
  rename U3319500 HHI_INCOME_02_2019   // HHI_INCOME.02
  rename U3319600 HHI_INCOME_03_2019   // HHI_INCOME.03
  rename U3319700 HHI_INCOME_04_2019   // HHI_INCOME.04
  rename U3319800 HHI_INCOME_05_2019   // HHI_INCOME.05
  rename U3319900 HHI_INCOME_06_2019   // HHI_INCOME.06
  rename U3320000 HHI_INCOME_07_2019   // HHI_INCOME.07
  rename U3320100 HHI_INCOME_08_2019   // HHI_INCOME.08
  rename U3418800 PARTNERS_CHILDWITH_01_2019   // PARTNERS_CHILDWITH.01
  rename U3418900 PARTNERS_CHILDWITH_02_2019   // PARTNERS_CHILDWITH.02
  rename U3419000 PARTNERS_CHILDWITH_03_2019   // PARTNERS_CHILDWITH.03
  rename U3419100 PARTNERS_CURRENT_01_2019   // PARTNERS_CURRENT.01
  rename U3419200 PARTNERS_CURRENT_02_2019   // PARTNERS_CURRENT.02
  rename U3419300 PARTNERS_CURRENT_03_2019   // PARTNERS_CURRENT.03
  rename U3419400 PARTNERS_STARTDATE_01_M_2019   // PARTNERS_STARTDATE.01~M
  rename U3419401 PARTNERS_STARTDATE_01_Y_2019   // PARTNERS_STARTDATE.01~Y
  rename U3419500 PARTNERS_STARTDATE_02_M_2019   // PARTNERS_STARTDATE.02~M
  rename U3419501 PARTNERS_STARTDATE_02_Y_2019   // PARTNERS_STARTDATE.02~Y
  rename U3419600 PARTNERS_STARTDATE_03_M_2019   // PARTNERS_STARTDATE.03~M
  rename U3419601 PARTNERS_STARTDATE_03_Y_2019   // PARTNERS_STARTDATE.03~Y
  rename U3419700 PARTNERS_STATUS_01_2019   // PARTNERS_STATUS.01
  rename U3419800 PARTNERS_STATUS_02_2019   // PARTNERS_STATUS.02
  rename U3419900 PARTNERS_STATUS_03_2019   // PARTNERS_STATUS.03
  rename U3420000 PARTNERS_STOPDATE_01_M_2019   // PARTNERS_STOPDATE.01~M
  rename U3420001 PARTNERS_STOPDATE_01_Y_2019   // PARTNERS_STOPDATE.01~Y
  rename U3420100 PARTNERS_STOPDATE_02_M_2019   // PARTNERS_STOPDATE.02~M
  rename U3420101 PARTNERS_STOPDATE_02_Y_2019   // PARTNERS_STOPDATE.02~Y
  rename U3420200 PARTNERS_STOPDATE_03_M_2019   // PARTNERS_STOPDATE.03~M
  rename U3420201 PARTNERS_STOPDATE_03_Y_2019   // PARTNERS_STOPDATE.03~Y
  rename U3437800 CV_AGE_MONTHS_INT_DATE_2019 
  rename U3437900 CV_AGE_INT_DATE_2019 
  rename U3438000 CV_CENSUS_REGION_2019 
  rename U3438100 CV_CHILD_BIRTH_DATE_01_M_2019   // CV_CHILD_BIRTH_DATE.01~M
  rename U3438101 CV_CHILD_BIRTH_DATE_01_Y_2019   // CV_CHILD_BIRTH_DATE.01~Y
  rename U3438200 CV_CHILD_BIRTH_DATE_02_M_2019   // CV_CHILD_BIRTH_DATE.02~M
  rename U3438201 CV_CHILD_BIRTH_DATE_02_Y_2019   // CV_CHILD_BIRTH_DATE.02~Y
  rename U3438300 CV_CHILD_BIRTH_DATE_03_M_2019   // CV_CHILD_BIRTH_DATE.03~M
  rename U3438301 CV_CHILD_BIRTH_DATE_03_Y_2019   // CV_CHILD_BIRTH_DATE.03~Y
  rename U3438400 CV_CHILD_BIRTH_DATE_04_M_2019   // CV_CHILD_BIRTH_DATE.04~M
  rename U3438401 CV_CHILD_BIRTH_DATE_04_Y_2019   // CV_CHILD_BIRTH_DATE.04~Y
  rename U3438500 CV_CHILD_BIRTH_DATE_05_M_2019   // CV_CHILD_BIRTH_DATE.05~M
  rename U3438501 CV_CHILD_BIRTH_DATE_05_Y_2019   // CV_CHILD_BIRTH_DATE.05~Y
  rename U3438600 CV_CHILD_BIRTH_DATE_06_M_2019   // CV_CHILD_BIRTH_DATE.06~M
  rename U3438601 CV_CHILD_BIRTH_DATE_06_Y_2019   // CV_CHILD_BIRTH_DATE.06~Y
  rename U3438700 CV_CHILD_BIRTH_DATE_07_M_2019   // CV_CHILD_BIRTH_DATE.07~M
  rename U3438701 CV_CHILD_BIRTH_DATE_07_Y_2019   // CV_CHILD_BIRTH_DATE.07~Y
  rename U3438800 CV_CHILD_BIRTH_DATE_08_M_2019   // CV_CHILD_BIRTH_DATE.08~M
  rename U3438801 CV_CHILD_BIRTH_DATE_08_Y_2019   // CV_CHILD_BIRTH_DATE.08~Y
  rename U3438900 CV_CHILD_BIRTH_DATE_09_M_2019   // CV_CHILD_BIRTH_DATE.09~M
  rename U3438901 CV_CHILD_BIRTH_DATE_09_Y_2019   // CV_CHILD_BIRTH_DATE.09~Y
  rename U3439000 CV_CHILD_BIRTH_DATE_10_M_2019   // CV_CHILD_BIRTH_DATE.10~M
  rename U3439001 CV_CHILD_BIRTH_DATE_10_Y_2019   // CV_CHILD_BIRTH_DATE.10~Y
  rename U3439100 CV_CHILD_BIRTH_DATE_11_M_2019   // CV_CHILD_BIRTH_DATE.11~M
  rename U3439101 CV_CHILD_BIRTH_DATE_11_Y_2019   // CV_CHILD_BIRTH_DATE.11~Y
  rename U3439200 CV_CHILD_BIRTH_DATE_12_M_2019   // CV_CHILD_BIRTH_DATE.12~M
  rename U3439201 CV_CHILD_BIRTH_DATE_12_Y_2019   // CV_CHILD_BIRTH_DATE.12~Y
  rename U3439300 CV_CHILD_BIRTH_DATE_13_M_2019   // CV_CHILD_BIRTH_DATE.13~M
  rename U3439301 CV_CHILD_BIRTH_DATE_13_Y_2019   // CV_CHILD_BIRTH_DATE.13~Y
  rename U3439400 CV_CHILD_BIRTH_MONTH_01_2019   // CV_CHILD_BIRTH_MONTH.01
  rename U3439500 CV_CHILD_BIRTH_MONTH_02_2019   // CV_CHILD_BIRTH_MONTH.02
  rename U3439600 CV_CHILD_BIRTH_MONTH_03_2019   // CV_CHILD_BIRTH_MONTH.03
  rename U3439700 CV_CHILD_BIRTH_MONTH_04_2019   // CV_CHILD_BIRTH_MONTH.04
  rename U3439800 CV_CHILD_BIRTH_MONTH_05_2019   // CV_CHILD_BIRTH_MONTH.05
  rename U3439900 CV_CHILD_BIRTH_MONTH_06_2019   // CV_CHILD_BIRTH_MONTH.06
  rename U3440000 CV_CHILD_BIRTH_MONTH_07_2019   // CV_CHILD_BIRTH_MONTH.07
  rename U3440100 CV_CHILD_BIRTH_MONTH_08_2019   // CV_CHILD_BIRTH_MONTH.08
  rename U3440200 CV_CHILD_BIRTH_MONTH_09_2019   // CV_CHILD_BIRTH_MONTH.09
  rename U3440300 CV_CHILD_BIRTH_MONTH_10_2019   // CV_CHILD_BIRTH_MONTH.10
  rename U3440400 CV_CHILD_BIRTH_MONTH_11_2019   // CV_CHILD_BIRTH_MONTH.11
  rename U3440500 CV_CHILD_BIRTH_MONTH_12_2019   // CV_CHILD_BIRTH_MONTH.12
  rename U3440600 CV_CHILD_BIRTH_MONTH_13_2019   // CV_CHILD_BIRTH_MONTH.13
  rename U3442500 CV_CHILD_STATUS_01_2019   // CV_CHILD_STATUS.01
  rename U3442600 CV_CHILD_STATUS_02_2019   // CV_CHILD_STATUS.02
  rename U3442700 CV_CHILD_STATUS_03_2019   // CV_CHILD_STATUS.03
  rename U3442800 CV_CHILD_STATUS_04_2019   // CV_CHILD_STATUS.04
  rename U3442900 CV_CHILD_STATUS_05_2019   // CV_CHILD_STATUS.05
  rename U3443000 CV_CHILD_STATUS_06_2019   // CV_CHILD_STATUS.06
  rename U3443100 CV_CHILD_STATUS_07_2019   // CV_CHILD_STATUS.07
  rename U3443200 CV_CHILD_STATUS_08_2019   // CV_CHILD_STATUS.08
  rename U3443300 CV_CHILD_STATUS_09_2019   // CV_CHILD_STATUS.09
  rename U3443400 CV_CHILD_STATUS_10_2019   // CV_CHILD_STATUS.10
  rename U3443500 CV_CHILD_STATUS_11_2019   // CV_CHILD_STATUS.11
  rename U3443600 CV_CHILD_STATUS_12_2019   // CV_CHILD_STATUS.12
  rename U3443700 CV_CHILD_STATUS_13_2019   // CV_CHILD_STATUS.13
  rename U3443800 CV_ENROLLSTAT_2019 
  rename U3443900 CV_HGC_EVER_EDT_2019 
  rename U3444000 CV_INCOME_FAMILY_2019 
  rename U3444100 CV_HH_POV_RATIO_2019 
  rename U3444200 CV_HH_SIZE_2019 
  rename U3444300 CV_HH_UNDER_18_2019 
  rename U3444400 CV_HH_UNDER_6_2019 
  rename U3444500 CV_HIGHEST_DEGREE_EVER_EDT_2019 
  rename U3444600 CV_HRLY_COMPENSATION_01_2019   // CV_HRLY_COMPENSATION.01
  rename U3444700 CV_HRLY_COMPENSATION_02_2019   // CV_HRLY_COMPENSATION.02
  rename U3444800 CV_HRLY_COMPENSATION_03_2019   // CV_HRLY_COMPENSATION.03
  rename U3444900 CV_HRLY_COMPENSATION_04_2019   // CV_HRLY_COMPENSATION.04
  rename U3445000 CV_HRLY_COMPENSATION_05_2019   // CV_HRLY_COMPENSATION.05
  rename U3445100 CV_HRLY_COMPENSATION_06_2019   // CV_HRLY_COMPENSATION.06
  rename U3445200 CV_HRLY_COMPENSATION_07_2019   // CV_HRLY_COMPENSATION.07
  rename U3445300 CV_HRLY_COMPENSATION_08_2019   // CV_HRLY_COMPENSATION.08
  rename U3445400 CV_HRLY_COMPENSATION_09_2019   // CV_HRLY_COMPENSATION.09
  rename U3445500 CV_HRLY_COMPENSATION_10_2019   // CV_HRLY_COMPENSATION.10
  rename U3445600 CV_HRLY_COMPENSATION_11_2019   // CV_HRLY_COMPENSATION.11
  rename U3445700 CV_HRLY_PAY_01_2019   // CV_HRLY_PAY.01
  rename U3445800 CV_HRLY_PAY_02_2019   // CV_HRLY_PAY.02
  rename U3445900 CV_HRLY_PAY_03_2019   // CV_HRLY_PAY.03
  rename U3446000 CV_HRLY_PAY_04_2019   // CV_HRLY_PAY.04
  rename U3446100 CV_HRLY_PAY_05_2019   // CV_HRLY_PAY.05
  rename U3446200 CV_HRLY_PAY_06_2019   // CV_HRLY_PAY.06
  rename U3446300 CV_HRLY_PAY_07_2019   // CV_HRLY_PAY.07
  rename U3446400 CV_HRLY_PAY_08_2019   // CV_HRLY_PAY.08
  rename U3446500 CV_HRLY_PAY_09_2019   // CV_HRLY_PAY.09
  rename U3446600 CV_HRLY_PAY_10_2019   // CV_HRLY_PAY.10
  rename U3446700 CV_HRLY_PAY_11_2019   // CV_HRLY_PAY.11
  rename U3449000 CV_HRS_PER_WEEK_01_2019   // CV_HRS_PER_WEEK.01
  rename U3449100 CV_HRS_PER_WEEK_02_2019   // CV_HRS_PER_WEEK.02
  rename U3449200 CV_HRS_PER_WEEK_03_2019   // CV_HRS_PER_WEEK.03
  rename U3449300 CV_HRS_PER_WEEK_04_2019   // CV_HRS_PER_WEEK.04
  rename U3449400 CV_HRS_PER_WEEK_05_2019   // CV_HRS_PER_WEEK.05
  rename U3449500 CV_HRS_PER_WEEK_06_2019   // CV_HRS_PER_WEEK.06
  rename U3449600 CV_HRS_PER_WEEK_07_2019   // CV_HRS_PER_WEEK.07
  rename U3449700 CV_HRS_PER_WEEK_08_2019   // CV_HRS_PER_WEEK.08
  rename U3449800 CV_HRS_PER_WEEK_09_2019   // CV_HRS_PER_WEEK.09
  rename U3449900 CV_HRS_PER_WEEK_10_2019   // CV_HRS_PER_WEEK.10
  rename U3450000 CV_HRS_PER_WEEK_11_2019   // CV_HRS_PER_WEEK.11
  rename U3450100 CV_INTERVIEW_CMONTH_2019 
  rename U3450201 CV_INTERVIEW_DATE_M_2019   // CV_INTERVIEW_DATE~M
  rename U3450202 CV_INTERVIEW_DATE_Y_2019   // CV_INTERVIEW_DATE~Y
  rename U3450300 CV_JOB_26_WKS_01_2019   // CV_JOB_26_WKS.01
  rename U3450400 CV_JOB_26_WKS_02_2019   // CV_JOB_26_WKS.02
  rename U3450500 CV_JOB_26_WKS_03_2019   // CV_JOB_26_WKS.03
  rename U3450600 CV_JOB_26_WKS_04_2019   // CV_JOB_26_WKS.04
  rename U3450700 CV_JOB_26_WKS_05_2019   // CV_JOB_26_WKS.05
  rename U3450800 CV_JOB_26_WKS_06_2019   // CV_JOB_26_WKS.06
  rename U3450900 CV_JOB_26_WKS_07_2019   // CV_JOB_26_WKS.07
  rename U3451000 CV_JOB_26_WKS_08_2019   // CV_JOB_26_WKS.08
  rename U3451100 CV_JOB_26_WKS_09_2019   // CV_JOB_26_WKS.09
  rename U3451200 CV_JOB_26_WKS_10_2019   // CV_JOB_26_WKS.10
  rename U3451300 CV_JOB_26_WKS_11_2019   // CV_JOB_26_WKS.11
  rename U3451400 CV_MARSTAT_2019 
  rename U3451500 CV_MARSTAT_COLLAPSED_2019 
  rename U3451600 CV_MSA_2019 
  rename U3451900 CV_BIO_CHILD_HH_U18_2019 
  rename U3452000 CV_BIO_CHILD_NR_U18_2019 
  rename U3453600 CV_URBAN_RURAL_2019   // CV_URBAN-RURAL
  rename U3453700 CV_WKSWK_DLI_ET_2019 
  rename U3453800 CV_WKSWK_DLI_ALL_2019 
  rename U3453900 CV_WKSWK_DLI_SE_2019 
  rename U3454000 CV_WKSWK_JOB_DLI_01_2019   // CV_WKSWK_JOB_DLI.01
  rename U3454100 CV_WKSWK_JOB_DLI_02_2019   // CV_WKSWK_JOB_DLI.02
  rename U3454200 CV_WKSWK_JOB_DLI_03_2019   // CV_WKSWK_JOB_DLI.03
  rename U3454300 CV_WKSWK_JOB_DLI_04_2019   // CV_WKSWK_JOB_DLI.04
  rename U3454400 CV_WKSWK_JOB_DLI_05_2019   // CV_WKSWK_JOB_DLI.05
  rename U3454500 CV_WKSWK_JOB_DLI_06_2019   // CV_WKSWK_JOB_DLI.06
  rename U3454600 CV_WKSWK_JOB_DLI_07_2019   // CV_WKSWK_JOB_DLI.07
  rename U3454700 CV_WKSWK_JOB_DLI_08_2019   // CV_WKSWK_JOB_DLI.08
  rename U3454800 CV_WKSWK_JOB_DLI_09_2019   // CV_WKSWK_JOB_DLI.09
  rename U3454900 CV_WKSWK_JOB_DLI_10_2019   // CV_WKSWK_JOB_DLI.10
  rename U3455000 CV_WKSWK_JOB_DLI_11_2019   // CV_WKSWK_JOB_DLI.11
  rename U3455100 CV_DOI_EMPLOYED_2019 
  rename U3455200 CV_DOI_HOURS_WORKED_2019 
  rename U3455400 CV_CESD_SCORE_R19_2019 
  rename U3455500 SAMPLING_WEIGHT_CC_2019 
  rename U3455600 SAMPLING_PANEL_WEIGHT_2019 
  rename U3459400 R19_PCT_DK_2019 
  rename U3459500 R19_PCT_REF_2019 
  rename U3461400 R19_TIM_INTVW_2019 
  rename U3571600 YSCH_3878A_2019   // YSCH-3878A
  rename U3572700 YSCH_3113_2019   // YSCH-3113
  rename U3673600 YEMP_9890C_01_2019   // YEMP-9890C.01
  rename U3673700 YEMP_9890C_02_2019   // YEMP-9890C.02
  rename U3673800 YEMP_9890C_03_2019   // YEMP-9890C.03
  rename U3694400 YEMP_9899WDV_01_2019   // YEMP-9899WDV.01
  rename U3694500 YEMP_9899WDV_02_2019   // YEMP-9899WDV.02
  rename U3694600 YEMP_9899WDV_03_2019   // YEMP-9899WDV.03
  rename U3694700 YEMP_9899WDV_04_2019   // YEMP-9899WDV.04
  rename U3694800 YEMP_9899WDV_05_2019   // YEMP-9899WDV.05
  rename U3694900 YEMP_9899WDV_06_2019   // YEMP-9899WDV.06
  rename U3695000 YEMP_9899WDV_07_2019   // YEMP-9899WDV.07
  rename U3695100 YEMP_9899WDV_08_2019   // YEMP-9899WDV.08
  rename U3695200 YEMP_9899WDV_09_2019   // YEMP-9899WDV.09
  rename U3695300 YEMP_9899WDV_10_2019   // YEMP-9899WDV.10
  rename U3840200 YEMP_37904_01_2019   // YEMP-37904.01
  rename U3840300 YEMP_37904_02_2019   // YEMP-37904.02
  rename U3840400 YEMP_37904_03_2019   // YEMP-37904.03
  rename U3840500 YEMP_37904_04_2019   // YEMP-37904.04
  rename U3840600 YEMP_37904_05_2019   // YEMP-37904.05
  rename U3840700 YEMP_37904_06_2019   // YEMP-37904.06
  rename U3840800 YEMP_37904_08_2019   // YEMP-37904.08
  rename U3912100 YEMP_59901_01_2019   // YEMP-59901.01
  rename U3912200 YEMP_59901_02_2019   // YEMP-59901.02
  rename U3912300 YEMP_59901_03_2019   // YEMP-59901.03
  rename U3912400 YEMP_59901_04_2019   // YEMP-59901.04
  rename U3912500 YEMP_59901_05_2019   // YEMP-59901.05
  rename U3912600 YEMP_59901_07_2019   // YEMP-59901.07
  rename U3912700 YEMP_59901_09_2019   // YEMP-59901.09
  rename U4009600 YEMP_58400A_REV_01_2019   // YEMP-58400A-REV.01
  rename U4009700 YEMP_58400A_REV_02_2019   // YEMP-58400A-REV.02
  rename U4009800 YEMP_58400A_REV_03_2019   // YEMP-58400A-REV.03
  rename U4009900 YEMP_58400A_REV_04_2019   // YEMP-58400A-REV.04
  rename U4010000 YEMP_58400A_REV_05_2019   // YEMP-58400A-REV.05
  rename U4010100 YEMP_58400A_REV_06_2019   // YEMP-58400A-REV.06
  rename U4010200 YEMP_58400A_REV_07_2019   // YEMP-58400A-REV.07
  rename U4010300 YEMP_58400A_REV_08_2019   // YEMP-58400A-REV.08
  rename U4010400 YEMP_58400A_REV_10_2019   // YEMP-58400A-REV.10
  rename U4021000 YEMP_81300_01_2019   // YEMP-81300.01
  rename U4021100 YEMP_81300_02_2019   // YEMP-81300.02
  rename U4021200 YEMP_81300_03_2019   // YEMP-81300.03
  rename U4021300 YEMP_81300_04_2019   // YEMP-81300.04
  rename U4021400 YEMP_81300_05_2019   // YEMP-81300.05
  rename U4021500 YEMP_81300_06_2019   // YEMP-81300.06
  rename U4021600 YEMP_81300_07_2019   // YEMP-81300.07
  rename U4021700 YEMP_81300_08_2019   // YEMP-81300.08
  rename U4021800 YEMP_81300_09_2019   // YEMP-81300.09
  rename U4021900 YEMP_81300_10_2019   // YEMP-81300.10
  rename U4022000 YEMP_81300_11_2019   // YEMP-81300.11
  rename U4032400 YEMP_101102_01_2019   // YEMP-101102.01
  rename U4032500 YEMP_101102_02_2019   // YEMP-101102.02
  rename U4032600 YEMP_101102_03_2019   // YEMP-101102.03
  rename U4032700 YEMP_101102_04_2019   // YEMP-101102.04
  rename U4032800 YEMP_101102_05_2019   // YEMP-101102.05
  rename U4032900 YEMP_101102_06_2019   // YEMP-101102.06
  rename U4033000 YEMP_101102_07_2019   // YEMP-101102.07
  rename U4033100 YEMP_101102_08_2019   // YEMP-101102.08
  rename U4033200 YEMP_101102_10_2019   // YEMP-101102.10
  rename U4041900 YEMP_101109_01_2019   // YEMP-101109.01
  rename U4042000 YEMP_101109_02_2019   // YEMP-101109.02
  rename U4042100 YEMP_101109_03_2019   // YEMP-101109.03
  rename U4042200 YEMP_101109_04_2019   // YEMP-101109.04
  rename U4042300 YEMP_101109_05_2019   // YEMP-101109.05
  rename U4042400 YEMP_101109_06_2019   // YEMP-101109.06
  rename U4042500 YEMP_101109_07_2019   // YEMP-101109.07
  rename U4042600 YEMP_101109_08_2019   // YEMP-101109.08
  rename U4042700 YEMP_101109_10_2019   // YEMP-101109.10
  rename U4044700 YEMP_101113_01_2019   // YEMP-101113.01
  rename U4044800 YEMP_101113_02_2019   // YEMP-101113.02
  rename U4044900 YEMP_101113_03_2019   // YEMP-101113.03
  rename U4045000 YEMP_101113_04_2019   // YEMP-101113.04
  rename U4045100 YEMP_101113_05_2019   // YEMP-101113.05
  rename U4045200 YEMP_101113_06_2019   // YEMP-101113.06
  rename U4045300 YEMP_101113_07_2019   // YEMP-101113.07
  rename U4045400 YEMP_101113_08_2019   // YEMP-101113.08
  rename U4045500 YEMP_101113_10_2019   // YEMP-101113.10
  rename U4051400 YEMP_101500_01_2019   // YEMP-101500.01
  rename U4051500 YEMP_101500_02_2019   // YEMP-101500.02
  rename U4051600 YEMP_101500_03_2019   // YEMP-101500.03
  rename U4051700 YEMP_101500_04_2019   // YEMP-101500.04
  rename U4051800 YEMP_101500_05_2019   // YEMP-101500.05
  rename U4051900 YEMP_101500_06_2019   // YEMP-101500.06
  rename U4052000 YEMP_101500_07_2019   // YEMP-101500.07
  rename U4052100 YEMP_101500_08_2019   // YEMP-101500.08
  rename U4052200 YEMP_101500_09_2019   // YEMP-101500.09
  rename U4052300 YEMP_101500_10_2019   // YEMP-101500.10
  rename U4052400 YEMP_101500_11_2019   // YEMP-101500.11
  rename U4057301 YEMP_101595_01_M_2019   // YEMP-101595.01~M
  rename U4057302 YEMP_101595_01_Y_2019   // YEMP-101595.01~Y
  rename U4057401 YEMP_101595_02_M_2019   // YEMP-101595.02~M
  rename U4057402 YEMP_101595_02_Y_2019   // YEMP-101595.02~Y
  rename U4057501 YEMP_101595_03_M_2019   // YEMP-101595.03~M
  rename U4057502 YEMP_101595_03_Y_2019   // YEMP-101595.03~Y
  rename U4057601 YEMP_101597_01_M_2019   // YEMP-101597.01~M
  rename U4057602 YEMP_101597_01_Y_2019   // YEMP-101597.01~Y
  rename U4057701 YEMP_101597_02_M_2019   // YEMP-101597.02~M
  rename U4057702 YEMP_101597_02_Y_2019   // YEMP-101597.02~Y
  rename U4057801 YEMP_101597_03_M_2019   // YEMP-101597.03~M
  rename U4057802 YEMP_101597_03_Y_2019   // YEMP-101597.03~Y
  rename U4057901 YEMP_101598_01_M_2019   // YEMP-101598.01~M
  rename U4057902 YEMP_101598_01_Y_2019   // YEMP-101598.01~Y
  rename U4058001 YEMP_101598_02_M_2019   // YEMP-101598.02~M
  rename U4058002 YEMP_101598_02_Y_2019   // YEMP-101598.02~Y
  rename U4058101 YEMP_101598_03_M_2019   // YEMP-101598.03~M
  rename U4058102 YEMP_101598_03_Y_2019   // YEMP-101598.03~Y
  rename U4058201 YEMP_101599_01_M_2019   // YEMP-101599.01~M
  rename U4058202 YEMP_101599_01_Y_2019   // YEMP-101599.01~Y
  rename U4058301 YEMP_101599_02_M_2019   // YEMP-101599.02~M
  rename U4058302 YEMP_101599_02_Y_2019   // YEMP-101599.02~Y
  rename U4058401 YEMP_101599_03_M_2019   // YEMP-101599.03~M
  rename U4058402 YEMP_101599_03_Y_2019   // YEMP-101599.03~Y
  rename U4060900 YEMP_102100_01_02_2019   // YEMP-102100.01.02
  rename U4061000 YEMP_102100_01_03_2019   // YEMP-102100.01.03
  rename U4061100 YEMP_102100_01_04_2019   // YEMP-102100.01.04
  rename U4061200 YEMP_102100_01_05_2019   // YEMP-102100.01.05
  rename U4061300 YEMP_102100_01_06_2019   // YEMP-102100.01.06
  rename U4061400 YEMP_102100_01_07_2019   // YEMP-102100.01.07
  rename U4061500 YEMP_102100_01_08_2019   // YEMP-102100.01.08
  rename U4061600 YEMP_102100_02_02_2019   // YEMP-102100.02.02
  rename U4061700 YEMP_102100_02_03_2019   // YEMP-102100.02.03
  rename U4061800 YEMP_102100_02_04_2019   // YEMP-102100.02.04
  rename U4061900 YEMP_102100_03_02_2019   // YEMP-102100.03.02
  rename U4062000 YEMP_102100_03_03_2019   // YEMP-102100.03.03
  rename U4062100 YEMP_102100_03_04_2019   // YEMP-102100.03.04
  rename U4062200 YEMP_102100_04_02_2019   // YEMP-102100.04.02
  rename U4062300 YEMP_102100_04_03_2019   // YEMP-102100.04.03
  rename U4062400 YEMP_102100_04_04_2019   // YEMP-102100.04.04
  rename U4062500 YEMP_102100_05_02_2019   // YEMP-102100.05.02
  rename U4062600 YEMP_102100_10_02_2019   // YEMP-102100.10.02
  rename U4062701 YEMP_102200_01_01_M_2019   // YEMP-102200.01.01~M
  rename U4062702 YEMP_102200_01_01_Y_2019   // YEMP-102200.01.01~Y
  rename U4062801 YEMP_102200_02_01_M_2019   // YEMP-102200.02.01~M
  rename U4062802 YEMP_102200_02_01_Y_2019   // YEMP-102200.02.01~Y
  rename U4062901 YEMP_102200_03_01_M_2019   // YEMP-102200.03.01~M
  rename U4062902 YEMP_102200_03_01_Y_2019   // YEMP-102200.03.01~Y
  rename U4063001 YEMP_102200_04_01_M_2019   // YEMP-102200.04.01~M
  rename U4063002 YEMP_102200_04_01_Y_2019   // YEMP-102200.04.01~Y
  rename U4063101 YEMP_102200_05_01_M_2019   // YEMP-102200.05.01~M
  rename U4063102 YEMP_102200_05_01_Y_2019   // YEMP-102200.05.01~Y
  rename U4087000 YEMP_105932_01_01_2019   // YEMP-105932.01.01
  rename U4087100 YEMP_105932_01_02_2019   // YEMP-105932.01.02
  rename U4087200 YEMP_105932_01_03_2019   // YEMP-105932.01.03
  rename U4087300 YEMP_105932_01_04_2019   // YEMP-105932.01.04
  rename U4087400 YEMP_105932_01_05_2019   // YEMP-105932.01.05
  rename U4087500 YEMP_105932_01_06_2019   // YEMP-105932.01.06
  rename U4087600 YEMP_105932_01_07_2019   // YEMP-105932.01.07
  rename U4087700 YEMP_105932_01_08_2019   // YEMP-105932.01.08
  rename U4087800 YEMP_105932_01_09_2019   // YEMP-105932.01.09
  rename U4087900 YEMP_105932_01_10_2019   // YEMP-105932.01.10
  rename U4088000 YEMP_105932_02_01_2019   // YEMP-105932.02.01
  rename U4088100 YEMP_105932_02_02_2019   // YEMP-105932.02.02
  rename U4088200 YEMP_105932_02_03_2019   // YEMP-105932.02.03
  rename U4088300 YEMP_105932_02_04_2019   // YEMP-105932.02.04
  rename U4088400 YEMP_105932_02_05_2019   // YEMP-105932.02.05
  rename U4088500 YEMP_105932_03_01_2019   // YEMP-105932.03.01
  rename U4088600 YEMP_105932_04_01_2019   // YEMP-105932.04.01
  rename U4088700 YEMP_105932_04_02_2019   // YEMP-105932.04.02
  rename U4088800 YEMP_105932_04_03_2019   // YEMP-105932.04.03
  rename U4091900 YEMP_105950_01_01_2019   // YEMP-105950.01.01
  rename U4092000 YEMP_105950_02_01_2019   // YEMP-105950.02.01
  rename U4092100 YEMP_105950_03_01_2019   // YEMP-105950.03.01
  rename U4178100 YMAR_3700_01_2019   // YMAR-3700.01
  rename U4178200 YMAR_3700_02_2019   // YMAR-3700.02
  rename U4178300 YMAR_3700_03_2019   // YMAR-3700.03
  rename U4178400 YMAR_3700_04_2019   // YMAR-3700.04
  rename U4178500 YMAR_3700A_01_2019   // YMAR-3700A.01
  rename U4178600 YMAR_3700A_02_2019   // YMAR-3700A.02
  rename U4282100 YINC_1400_2019   // YINC-1400
  rename U4282300 YINC_1700_2019   // YINC-1700
  rename U4282400 YINC_1800_2019   // YINC-1800
  rename U4283200 YINC_2400_2019   // YINC-2400
  rename U4283400 YINC_2510_2019   // YINC-2510
  rename U4283500 YINC_2520_2019   // YINC-2520
  rename U4283600 YINC_2600_2019   // YINC-2600
  rename U4283700 YINC_2700_2019   // YINC-2700
  rename U4285700 YINC_7601_2019   // YINC-7601
  rename U4285800 YINC_7602_2019   // YINC-7602
  rename U4286100 YINC_8001_2019   // YINC-8001
  rename U4286200 YINC_8002_2019   // YINC-8002
  rename U4286300 YINC_8003_2019   // YINC-8003
  rename U4393300 HHI_ETHNICITY_01_2019   // HHI_ETHNICITY.01
  rename U4393400 HHI_ETHNICITY_02_2019   // HHI_ETHNICITY.02
  rename U4393500 HHI_ETHNICITY_03_2019   // HHI_ETHNICITY.03
  rename U4393600 HHI_ETHNICITY_04_2019   // HHI_ETHNICITY.04
  rename U4393700 HHI_ETHNICITY_05_2019   // HHI_ETHNICITY.05
  rename U4393800 HHI_ETHNICITY_06_2019   // HHI_ETHNICITY.06
  rename U4393900 HHI_ETHNICITY_07_2019   // HHI_ETHNICITY.07
  rename U4394000 HHI_ETHNICITY_08_2019   // HHI_ETHNICITY.08
  rename U4394100 HHI_ETHNICITY_09_2019   // HHI_ETHNICITY.09
  rename U4394200 HHI_ETHNICITY_10_2019   // HHI_ETHNICITY.10
  rename U4394300 HHI_ETHNICITY_11_2019   // HHI_ETHNICITY.11
  rename U4394400 HHI_ETHNICITY_12_2019   // HHI_ETHNICITY.12
  rename U4394500 HHI_ETHNICITY_13_2019   // HHI_ETHNICITY.13
  rename U4394600 HHI_ETHNICITY_14_2019   // HHI_ETHNICITY.14
  rename U4394700 HHI_ETHNICITY_15_2019   // HHI_ETHNICITY.15
  rename U4394800 HHI_ETHNICITY_16_2019   // HHI_ETHNICITY.16
  rename U4394900 HHI_ETHNICITY_17_2019   // HHI_ETHNICITY.17
  rename U4396700 HHI_AGE_01_2019   // HHI_AGE.01
  rename U4396800 HHI_AGE_02_2019   // HHI_AGE.02
  rename U4396900 HHI_AGE_03_2019   // HHI_AGE.03
  rename U4397000 HHI_AGE_04_2019   // HHI_AGE.04
  rename U4397100 HHI_AGE_05_2019   // HHI_AGE.05
  rename U4397200 HHI_AGE_06_2019   // HHI_AGE.06
  rename U4397300 HHI_AGE_07_2019   // HHI_AGE.07
  rename U4397400 HHI_AGE_08_2019   // HHI_AGE.08
  rename U4397500 HHI_AGE_09_2019   // HHI_AGE.09
  rename U4397600 HHI_AGE_10_2019   // HHI_AGE.10
  rename U4397700 HHI_AGE_11_2019   // HHI_AGE.11
  rename U4397800 HHI_AGE_12_2019   // HHI_AGE.12
  rename U4397900 HHI_AGE_13_2019   // HHI_AGE.13
  rename U4398000 HHI_AGE_14_2019   // HHI_AGE.14
  rename U4398100 HHI_AGE_15_2019   // HHI_AGE.15
  rename U4398200 HHI_AGE_16_2019   // HHI_AGE.16
  rename U4398300 HHI_AGE_17_2019   // HHI_AGE.17
  rename U4398400 HHI_SEX_01_2019   // HHI_SEX.01
  rename U4398500 HHI_SEX_02_2019   // HHI_SEX.02
  rename U4398600 HHI_SEX_03_2019   // HHI_SEX.03
  rename U4398700 HHI_SEX_04_2019   // HHI_SEX.04
  rename U4398800 HHI_SEX_05_2019   // HHI_SEX.05
  rename U4398900 HHI_SEX_06_2019   // HHI_SEX.06
  rename U4399000 HHI_SEX_07_2019   // HHI_SEX.07
  rename U4399100 HHI_SEX_08_2019   // HHI_SEX.08
  rename U4399200 HHI_SEX_09_2019   // HHI_SEX.09
  rename U4399300 HHI_SEX_10_2019   // HHI_SEX.10
  rename U4399400 HHI_SEX_11_2019   // HHI_SEX.11
  rename U4399500 HHI_SEX_12_2019   // HHI_SEX.12
  rename U4399600 HHI_SEX_13_2019   // HHI_SEX.13
  rename U4399700 HHI_SEX_14_2019   // HHI_SEX.14
  rename U4399800 HHI_SEX_15_2019   // HHI_SEX.15
  rename U4399900 HHI_SEX_16_2019   // HHI_SEX.16
  rename U4400000 HHI_SEX_17_2019   // HHI_SEX.17
  rename U4400100 HHI_MARSTAT_01_2019   // HHI_MARSTAT.01
  rename U4400200 HHI_MARSTAT_02_2019   // HHI_MARSTAT.02
  rename U4400300 HHI_MARSTAT_03_2019   // HHI_MARSTAT.03
  rename U4400400 HHI_MARSTAT_04_2019   // HHI_MARSTAT.04
  rename U4400500 HHI_MARSTAT_05_2019   // HHI_MARSTAT.05
  rename U4400600 HHI_MARSTAT_06_2019   // HHI_MARSTAT.06
  rename U4400700 HHI_MARSTAT_07_2019   // HHI_MARSTAT.07
  rename U4400800 HHI_MARSTAT_08_2019   // HHI_MARSTAT.08
  rename U4400900 HHI_MARSTAT_12_2019   // HHI_MARSTAT.12
  rename U4401000 HHI_MARSTAT_13_2019   // HHI_MARSTAT.13
  rename U4402000 HHI_EMPLOYED_01_2019   // HHI_EMPLOYED.01
  rename U4402100 HHI_EMPLOYED_02_2019   // HHI_EMPLOYED.02
  rename U4402200 HHI_EMPLOYED_03_2019   // HHI_EMPLOYED.03
  rename U4402300 HHI_EMPLOYED_04_2019   // HHI_EMPLOYED.04
  rename U4402400 HHI_EMPLOYED_05_2019   // HHI_EMPLOYED.05
  rename U4402500 HHI_EMPLOYED_06_2019   // HHI_EMPLOYED.06
  rename U4402600 HHI_EMPLOYED_07_2019   // HHI_EMPLOYED.07
  rename U4402700 HHI_EMPLOYED_08_2019   // HHI_EMPLOYED.08
  rename U4402800 HHI_EMPLOYED_09_2019   // HHI_EMPLOYED.09
  rename U4402900 HHI_EMPLOYED_10_2019   // HHI_EMPLOYED.10
  rename U4403000 HHI_EMPLOYED_11_2019   // HHI_EMPLOYED.11
  rename U4403100 HHI_EMPLOYED_12_2019   // HHI_EMPLOYED.12
  rename U4403200 HHI_EMPLOYED_13_2019   // HHI_EMPLOYED.13
  rename U4405000 HHI_HIGHGRADE_01_2019   // HHI_HIGHGRADE.01
  rename U4405100 HHI_HIGHGRADE_02_2019   // HHI_HIGHGRADE.02
  rename U4405200 HHI_HIGHGRADE_03_2019   // HHI_HIGHGRADE.03
  rename U4405300 HHI_HIGHGRADE_04_2019   // HHI_HIGHGRADE.04
  rename U4405400 HHI_HIGHGRADE_05_2019   // HHI_HIGHGRADE.05
  rename U4405500 HHI_HIGHGRADE_06_2019   // HHI_HIGHGRADE.06
  rename U4405600 HHI_HIGHGRADE_07_2019   // HHI_HIGHGRADE.07
  rename U4405700 HHI_HIGHGRADE_08_2019   // HHI_HIGHGRADE.08
  rename U4405800 HHI_HIGHGRADE_09_2019   // HHI_HIGHGRADE.09
  rename U4405900 HHI_HIGHGRADE_11_2019   // HHI_HIGHGRADE.11
  rename U4406000 HHI_HIGHGRADE_13_2019   // HHI_HIGHGRADE.13
  rename U4406100 HHI_RELY_01_2019   // HHI_RELY.01
  rename U4406200 HHI_RELY_02_2019   // HHI_RELY.02
  rename U4406300 HHI_RELY_03_2019   // HHI_RELY.03
  rename U4406400 HHI_RELY_04_2019   // HHI_RELY.04
  rename U4406500 HHI_RELY_05_2019   // HHI_RELY.05
  rename U4406600 HHI_RELY_06_2019   // HHI_RELY.06
  rename U4406700 HHI_RELY_07_2019   // HHI_RELY.07
  rename U4406800 HHI_RELY_08_2019   // HHI_RELY.08
  rename U4406900 HHI_RELY_09_2019   // HHI_RELY.09
  rename U4407000 HHI_RELY_10_2019   // HHI_RELY.10
  rename U4407100 HHI_RELY_11_2019   // HHI_RELY.11
  rename U4407200 HHI_RELY_12_2019   // HHI_RELY.12
  rename U4407300 HHI_RELY_13_2019   // HHI_RELY.13
  rename U4407400 HHI_RELY_14_2019   // HHI_RELY.14
  rename U4407500 HHI_RELY_15_2019   // HHI_RELY.15
  rename U4407600 HHI_RELY_16_2019   // HHI_RELY.16
  rename U4407700 HHI_RELY_17_2019   // HHI_RELY.17
  rename U4410300 HHI_UID_01_2019   // HHI_UID.01
  rename U4410400 HHI_UID_02_2019   // HHI_UID.02
  rename U4410500 HHI_UID_03_2019   // HHI_UID.03
  rename U4410600 HHI_UID_04_2019   // HHI_UID.04
  rename U4410700 HHI_UID_05_2019   // HHI_UID.05
  rename U4410800 HHI_UID_06_2019   // HHI_UID.06
  rename U4410900 HHI_UID_07_2019   // HHI_UID.07
  rename U4411000 HHI_UID_08_2019   // HHI_UID.08
  rename U4411100 HHI_UID_09_2019   // HHI_UID.09
  rename U4411200 HHI_UID_10_2019   // HHI_UID.10
  rename U4411300 HHI_UID_11_2019   // HHI_UID.11
  rename U4411400 HHI_UID_12_2019   // HHI_UID.12
  rename U4411500 HHI_UID_13_2019   // HHI_UID.13
  rename U4411600 HHI_UID_14_2019   // HHI_UID.14
  rename U4411700 HHI_UID_15_2019   // HHI_UID.15
  rename U4411800 HHI_UID_16_2019   // HHI_UID.16
  rename U4411900 HHI_UID_17_2019   // HHI_UID.17
  rename U4412001 HHI_BDATE_01_M_2019   // HHI_BDATE.01~M
  rename U4412002 HHI_BDATE_01_Y_2019   // HHI_BDATE.01~Y
  rename U4412101 HHI_BDATE_02_M_2019   // HHI_BDATE.02~M
  rename U4412102 HHI_BDATE_02_Y_2019   // HHI_BDATE.02~Y
  rename U4412201 HHI_BDATE_03_M_2019   // HHI_BDATE.03~M
  rename U4412202 HHI_BDATE_03_Y_2019   // HHI_BDATE.03~Y
  rename U4412301 HHI_BDATE_04_M_2019   // HHI_BDATE.04~M
  rename U4412302 HHI_BDATE_04_Y_2019   // HHI_BDATE.04~Y
  rename U4412401 HHI_BDATE_05_M_2019   // HHI_BDATE.05~M
  rename U4412402 HHI_BDATE_05_Y_2019   // HHI_BDATE.05~Y
  rename U4412501 HHI_BDATE_06_M_2019   // HHI_BDATE.06~M
  rename U4412502 HHI_BDATE_06_Y_2019   // HHI_BDATE.06~Y
  rename U4412601 HHI_BDATE_07_M_2019   // HHI_BDATE.07~M
  rename U4412602 HHI_BDATE_07_Y_2019   // HHI_BDATE.07~Y
  rename U4412701 HHI_BDATE_08_M_2019   // HHI_BDATE.08~M
  rename U4412702 HHI_BDATE_08_Y_2019   // HHI_BDATE.08~Y
  rename U4412801 HHI_BDATE_09_M_2019   // HHI_BDATE.09~M
  rename U4412802 HHI_BDATE_09_Y_2019   // HHI_BDATE.09~Y
  rename U4412901 HHI_BDATE_10_M_2019   // HHI_BDATE.10~M
  rename U4412902 HHI_BDATE_10_Y_2019   // HHI_BDATE.10~Y
  rename U4413001 HHI_BDATE_11_M_2019   // HHI_BDATE.11~M
  rename U4413002 HHI_BDATE_11_Y_2019   // HHI_BDATE.11~Y
  rename U4413101 HHI_BDATE_12_M_2019   // HHI_BDATE.12~M
  rename U4413102 HHI_BDATE_12_Y_2019   // HHI_BDATE.12~Y
  rename U4413200 HHI_CHILDID_01_2019   // HHI_CHILDID.01
  rename U4413300 HHI_CHILDID_02_2019   // HHI_CHILDID.02
  rename U4413400 HHI_CHILDID_03_2019   // HHI_CHILDID.03
  rename U4413500 HHI_CHILDID_04_2019   // HHI_CHILDID.04
  rename U4413600 HHI_CHILDID_05_2019   // HHI_CHILDID.05
  rename U4413700 HHI_CHILDID_06_2019   // HHI_CHILDID.06
  rename U4413800 HHI_CHILDID_07_2019   // HHI_CHILDID.07
  rename U4413900 HHI_CHILDID_08_2019   // HHI_CHILDID.08
  rename U4414000 HHI_CHILDID_09_2019   // HHI_CHILDID.09
  rename U4414100 HHI_CHILDID_10_2019   // HHI_CHILDID.10
  rename U4414200 HHI_CHILDID_11_2019   // HHI_CHILDID.11
  rename U4414300 HHI_CHILDID_12_2019   // HHI_CHILDID.12
  rename U4414400 HHI_PARENTUID_01_2019   // HHI_PARENTUID.01
  rename U4414500 HHI_PARENTUID_02_2019   // HHI_PARENTUID.02
  rename U4414600 HHI_PARENTUID_03_2019   // HHI_PARENTUID.03
  rename U4414700 HHI_PARENTUID_04_2019   // HHI_PARENTUID.04
  rename U4414800 HHI_PARENTUID_05_2019   // HHI_PARENTUID.05
  rename U4414900 HHI_PARENTUID_06_2019   // HHI_PARENTUID.06
  rename U4415000 HHI_PARENTUID_07_2019   // HHI_PARENTUID.07
  rename U4415100 HHI_PARENTUID_08_2019   // HHI_PARENTUID.08
  rename U4415200 HHI_PARENTUID_09_2019   // HHI_PARENTUID.09
  rename U4415300 HHI_PARENTUID_10_2019   // HHI_PARENTUID.10
  rename U4415400 HHI_PARENTUID_11_2019   // HHI_PARENTUID.11
  rename U4415500 HHI_PARENTUID_12_2019   // HHI_PARENTUID.12
  rename U4492100 YEMP_UID_01_2019   // YEMP_UID.01
  rename U4492200 YEMP_UID_02_2019   // YEMP_UID.02
  rename U4492300 YEMP_UID_03_2019   // YEMP_UID.03
  rename U4492400 YEMP_UID_04_2019   // YEMP_UID.04
  rename U4492500 YEMP_UID_05_2019   // YEMP_UID.05
  rename U4492600 YEMP_UID_06_2019   // YEMP_UID.06
  rename U4492700 YEMP_UID_07_2019   // YEMP_UID.07
  rename U4492800 YEMP_UID_08_2019   // YEMP_UID.08
  rename U4492900 YEMP_UID_09_2019   // YEMP_UID.09
  rename U4493000 YEMP_UID_10_2019   // YEMP_UID.10
  rename U4493100 YEMP_UID_11_2019   // YEMP_UID.11
  rename U4501300 YEMP_SELFEMP_01_2019   // YEMP_SELFEMP.01
  rename U4501400 YEMP_SELFEMP_02_2019   // YEMP_SELFEMP.02
  rename U4501500 YEMP_SELFEMP_03_2019   // YEMP_SELFEMP.03
  rename U4501600 YEMP_SELFEMP_04_2019   // YEMP_SELFEMP.04
  rename U4501700 YEMP_SELFEMP_05_2019   // YEMP_SELFEMP.05
  rename U4501800 YEMP_SELFEMP_06_2019   // YEMP_SELFEMP.06
  rename U4501900 YEMP_SELFEMP_07_2019   // YEMP_SELFEMP.07
  rename U4502000 YEMP_SELFEMP_08_2019   // YEMP_SELFEMP.08
  rename U4502100 YEMP_SELFEMP_09_2019   // YEMP_SELFEMP.09
  rename U4502200 YEMP_SELFEMP_10_2019   // YEMP_SELFEMP.10
  rename U4502300 YEMP_SELFEMP_11_2019   // YEMP_SELFEMP.11
  rename U4548800 PARTNERS_ID_01_2019   // PARTNERS_ID.01
  rename U4548900 PARTNERS_ID_02_2019   // PARTNERS_ID.02
  rename U4549000 PARTNERS_ID_03_2019   // PARTNERS_ID.03
  rename U4549100 PARTNERS_SEX_01_2019   // PARTNERS_SEX.01
  rename U4549200 PARTNERS_SEX_02_2019   // PARTNERS_SEX.02
  rename U4549300 PARTNERS_SEX_03_2019   // PARTNERS_SEX.03
  rename U4549400 PARTNERS_UID_01_2019   // PARTNERS_UID.01
  rename U4549500 PARTNERS_UID_02_2019   // PARTNERS_UID.02
  rename U4549600 PARTNERS_UID_03_2019   // PARTNERS_UID.03
  rename Z9032100 CVC_RND_2007_XRND 
  rename Z9032200 CVC_GRADES_REPEAT_EVER_2007_XRND 
  rename Z9032300 CVC_GRADE_SKIPPED_EVER_2007_XRND 
  rename Z9033700 CVC_SAT_MATH_SCORE_2007_XRND 
  rename Z9033800 CVC_SAT_MATH_RND_2007_XRND 
  rename Z9033900 CVC_SAT_VERBAL_SCORE_2007_XRND 
  rename Z9034000 CVC_SAT_VERBAL_RND_2007_XRND 
  rename Z9034100 CVC_ACT_SCORE_2007_XRND 
  rename Z9034200 CVC_ACT_RND_2007_XRND 
  rename Z9050501 CVC_TTL_JOB_TEEN2_XRND 
  rename Z9050601 CVC_TTL_JOB_ADULT2_ET_XRND 
  rename Z9050701 CVC_TTL_JOB_ADULT2_ALL_XRND 
  rename Z9050800 CVC_TTL_JOB_YR_ET_00_XRND   // CVC_TTL_JOB_YR_ET.00
  rename Z9050900 CVC_TTL_JOB_YR_ET_01_XRND   // CVC_TTL_JOB_YR_ET.01
  rename Z9051000 CVC_TTL_JOB_YR_ET_02_XRND   // CVC_TTL_JOB_YR_ET.02
  rename Z9051100 CVC_TTL_JOB_YR_ET_03_XRND   // CVC_TTL_JOB_YR_ET.03
  rename Z9051200 CVC_TTL_JOB_YR_ET_04_XRND   // CVC_TTL_JOB_YR_ET.04
  rename Z9051300 CVC_TTL_JOB_YR_ET_05_XRND   // CVC_TTL_JOB_YR_ET.05
  rename Z9051400 CVC_TTL_JOB_YR_ET_06_XRND   // CVC_TTL_JOB_YR_ET.06
  rename Z9051500 CVC_TTL_JOB_YR_ET_07_XRND   // CVC_TTL_JOB_YR_ET.07
  rename Z9051600 CVC_TTL_JOB_YR_ET_08_XRND   // CVC_TTL_JOB_YR_ET.08
  rename Z9051700 CVC_TTL_JOB_YR_ET_09_XRND   // CVC_TTL_JOB_YR_ET.09
  rename Z9051701 CVC_TTL_JOB_YR_ET_10_XRND   // CVC_TTL_JOB_YR_ET.10
  rename Z9051702 CVC_TTL_JOB_YR_ET_11_XRND   // CVC_TTL_JOB_YR_ET.11
  rename Z9051703 CVC_TTL_JOB_YR_ET_12_XRND   // CVC_TTL_JOB_YR_ET.12
  rename Z9051704 CVC_TTL_JOB_YR_ET_13_XRND   // CVC_TTL_JOB_YR_ET.13
  rename Z9051705 CVC_TTL_JOB_YR_ET_14_XRND   // CVC_TTL_JOB_YR_ET.14
  rename Z9051706 CVC_TTL_JOB_YR_ET_15_XRND   // CVC_TTL_JOB_YR_ET.15
  rename Z9051707 CVC_TTL_JOB_YR_ET_16_XRND   // CVC_TTL_JOB_YR_ET.16
  rename Z9051708 CVC_TTL_JOB_YR_ET_17_XRND   // CVC_TTL_JOB_YR_ET.17
  rename Z9051709 CVC_TTL_JOB_YR_ET_18_XRND   // CVC_TTL_JOB_YR_ET.18
  rename Z9051710 CVC_TTL_JOB_YR_ET_19_XRND   // CVC_TTL_JOB_YR_ET.19
  rename Z9051711 CVC_TTL_JOB_YR_ET_20_XRND   // CVC_TTL_JOB_YR_ET.20
  rename Z9051712 CVC_TTL_JOB_YR_ET_21_XRND   // CVC_TTL_JOB_YR_ET.21
  rename Z9051713 CVC_TTL_JOB_YR_ET_22_XRND   // CVC_TTL_JOB_YR_ET.22
  rename Z9051800 CVC_TTL_JOB_YR_ET_80_XRND   // CVC_TTL_JOB_YR_ET.80
  rename Z9051900 CVC_TTL_JOB_YR_ET_81_XRND   // CVC_TTL_JOB_YR_ET.81
  rename Z9052000 CVC_TTL_JOB_YR_ET_82_XRND   // CVC_TTL_JOB_YR_ET.82
  rename Z9052100 CVC_TTL_JOB_YR_ET_83_XRND   // CVC_TTL_JOB_YR_ET.83
  rename Z9052200 CVC_TTL_JOB_YR_ET_84_XRND   // CVC_TTL_JOB_YR_ET.84
  rename Z9052300 CVC_TTL_JOB_YR_ET_85_XRND   // CVC_TTL_JOB_YR_ET.85
  rename Z9052400 CVC_TTL_JOB_YR_ET_86_XRND   // CVC_TTL_JOB_YR_ET.86
  rename Z9052500 CVC_TTL_JOB_YR_ET_87_XRND   // CVC_TTL_JOB_YR_ET.87
  rename Z9052600 CVC_TTL_JOB_YR_ET_88_XRND   // CVC_TTL_JOB_YR_ET.88
  rename Z9052700 CVC_TTL_JOB_YR_ET_89_XRND   // CVC_TTL_JOB_YR_ET.89
  rename Z9052800 CVC_TTL_JOB_YR_ET_90_XRND   // CVC_TTL_JOB_YR_ET.90
  rename Z9052900 CVC_TTL_JOB_YR_ET_91_XRND   // CVC_TTL_JOB_YR_ET.91
  rename Z9053000 CVC_TTL_JOB_YR_ET_92_XRND   // CVC_TTL_JOB_YR_ET.92
  rename Z9053100 CVC_TTL_JOB_YR_ET_93_XRND   // CVC_TTL_JOB_YR_ET.93
  rename Z9053200 CVC_TTL_JOB_YR_ET_94_XRND   // CVC_TTL_JOB_YR_ET.94
  rename Z9053300 CVC_TTL_JOB_YR_ET_95_XRND   // CVC_TTL_JOB_YR_ET.95
  rename Z9053400 CVC_TTL_JOB_YR_ET_96_XRND   // CVC_TTL_JOB_YR_ET.96
  rename Z9053500 CVC_TTL_JOB_YR_ET_97_XRND   // CVC_TTL_JOB_YR_ET.97
  rename Z9053600 CVC_TTL_JOB_YR_ET_98_XRND   // CVC_TTL_JOB_YR_ET.98
  rename Z9053700 CVC_TTL_JOB_YR_ET_99_XRND   // CVC_TTL_JOB_YR_ET.99
  rename Z9053800 CVC_TTL_JOB_YR_ALL_00_XRND   // CVC_TTL_JOB_YR_ALL.00
  rename Z9053900 CVC_TTL_JOB_YR_ALL_01_XRND   // CVC_TTL_JOB_YR_ALL.01
  rename Z9054000 CVC_TTL_JOB_YR_ALL_02_XRND   // CVC_TTL_JOB_YR_ALL.02
  rename Z9054100 CVC_TTL_JOB_YR_ALL_03_XRND   // CVC_TTL_JOB_YR_ALL.03
  rename Z9054200 CVC_TTL_JOB_YR_ALL_04_XRND   // CVC_TTL_JOB_YR_ALL.04
  rename Z9054300 CVC_TTL_JOB_YR_ALL_05_XRND   // CVC_TTL_JOB_YR_ALL.05
  rename Z9054400 CVC_TTL_JOB_YR_ALL_06_XRND   // CVC_TTL_JOB_YR_ALL.06
  rename Z9054500 CVC_TTL_JOB_YR_ALL_07_XRND   // CVC_TTL_JOB_YR_ALL.07
  rename Z9054600 CVC_TTL_JOB_YR_ALL_08_XRND   // CVC_TTL_JOB_YR_ALL.08
  rename Z9054700 CVC_TTL_JOB_YR_ALL_09_XRND   // CVC_TTL_JOB_YR_ALL.09
  rename Z9054701 CVC_TTL_JOB_YR_ALL_10_XRND   // CVC_TTL_JOB_YR_ALL.10
  rename Z9054702 CVC_TTL_JOB_YR_ALL_11_XRND   // CVC_TTL_JOB_YR_ALL.11
  rename Z9054703 CVC_TTL_JOB_YR_ALL_12_XRND   // CVC_TTL_JOB_YR_ALL.12
  rename Z9054704 CVC_TTL_JOB_YR_ALL_13_XRND   // CVC_TTL_JOB_YR_ALL.13
  rename Z9054705 CVC_TTL_JOB_YR_ALL_14_XRND   // CVC_TTL_JOB_YR_ALL.14
  rename Z9054706 CVC_TTL_JOB_YR_ALL_15_XRND   // CVC_TTL_JOB_YR_ALL.15
  rename Z9054707 CVC_TTL_JOB_YR_ALL_16_XRND   // CVC_TTL_JOB_YR_ALL.16
  rename Z9054708 CVC_TTL_JOB_YR_ALL_17_XRND   // CVC_TTL_JOB_YR_ALL.17
  rename Z9054709 CVC_TTL_JOB_YR_ALL_18_XRND   // CVC_TTL_JOB_YR_ALL.18
  rename Z9054710 CVC_TTL_JOB_YR_ALL_19_XRND   // CVC_TTL_JOB_YR_ALL.19
  rename Z9054711 CVC_TTL_JOB_YR_ALL_20_XRND   // CVC_TTL_JOB_YR_ALL.20
  rename Z9054712 CVC_TTL_JOB_YR_ALL_21_XRND   // CVC_TTL_JOB_YR_ALL.21
  rename Z9054713 CVC_TTL_JOB_YR_ALL_22_XRND   // CVC_TTL_JOB_YR_ALL.22
  rename Z9054800 CVC_TTL_JOB_YR_ALL_80_XRND   // CVC_TTL_JOB_YR_ALL.80
  rename Z9054900 CVC_TTL_JOB_YR_ALL_81_XRND   // CVC_TTL_JOB_YR_ALL.81
  rename Z9055000 CVC_TTL_JOB_YR_ALL_82_XRND   // CVC_TTL_JOB_YR_ALL.82
  rename Z9055100 CVC_TTL_JOB_YR_ALL_83_XRND   // CVC_TTL_JOB_YR_ALL.83
  rename Z9055200 CVC_TTL_JOB_YR_ALL_84_XRND   // CVC_TTL_JOB_YR_ALL.84
  rename Z9055300 CVC_TTL_JOB_YR_ALL_85_XRND   // CVC_TTL_JOB_YR_ALL.85
  rename Z9055400 CVC_TTL_JOB_YR_ALL_86_XRND   // CVC_TTL_JOB_YR_ALL.86
  rename Z9055500 CVC_TTL_JOB_YR_ALL_87_XRND   // CVC_TTL_JOB_YR_ALL.87
  rename Z9055600 CVC_TTL_JOB_YR_ALL_88_XRND   // CVC_TTL_JOB_YR_ALL.88
  rename Z9055700 CVC_TTL_JOB_YR_ALL_89_XRND   // CVC_TTL_JOB_YR_ALL.89
  rename Z9055800 CVC_TTL_JOB_YR_ALL_90_XRND   // CVC_TTL_JOB_YR_ALL.90
  rename Z9055900 CVC_TTL_JOB_YR_ALL_91_XRND   // CVC_TTL_JOB_YR_ALL.91
  rename Z9056000 CVC_TTL_JOB_YR_ALL_92_XRND   // CVC_TTL_JOB_YR_ALL.92
  rename Z9056100 CVC_TTL_JOB_YR_ALL_93_XRND   // CVC_TTL_JOB_YR_ALL.93
  rename Z9056200 CVC_TTL_JOB_YR_ALL_94_XRND   // CVC_TTL_JOB_YR_ALL.94
  rename Z9056300 CVC_TTL_JOB_YR_ALL_95_XRND   // CVC_TTL_JOB_YR_ALL.95
  rename Z9056400 CVC_TTL_JOB_YR_ALL_96_XRND   // CVC_TTL_JOB_YR_ALL.96
  rename Z9056500 CVC_TTL_JOB_YR_ALL_97_XRND   // CVC_TTL_JOB_YR_ALL.97
  rename Z9056600 CVC_TTL_JOB_YR_ALL_98_XRND   // CVC_TTL_JOB_YR_ALL.98
  rename Z9056700 CVC_TTL_JOB_YR_ALL_99_XRND   // CVC_TTL_JOB_YR_ALL.99
  rename Z9056800 CVC_TTL_JOB_YR_SE_00_XRND   // CVC_TTL_JOB_YR_SE.00
  rename Z9056900 CVC_TTL_JOB_YR_SE_01_XRND   // CVC_TTL_JOB_YR_SE.01
  rename Z9057000 CVC_TTL_JOB_YR_SE_02_XRND   // CVC_TTL_JOB_YR_SE.02
  rename Z9057100 CVC_TTL_JOB_YR_SE_03_XRND   // CVC_TTL_JOB_YR_SE.03
  rename Z9057200 CVC_TTL_JOB_YR_SE_04_XRND   // CVC_TTL_JOB_YR_SE.04
  rename Z9057300 CVC_TTL_JOB_YR_SE_05_XRND   // CVC_TTL_JOB_YR_SE.05
  rename Z9057400 CVC_TTL_JOB_YR_SE_06_XRND   // CVC_TTL_JOB_YR_SE.06
  rename Z9057500 CVC_TTL_JOB_YR_SE_07_XRND   // CVC_TTL_JOB_YR_SE.07
  rename Z9057600 CVC_TTL_JOB_YR_SE_08_XRND   // CVC_TTL_JOB_YR_SE.08
  rename Z9057700 CVC_TTL_JOB_YR_SE_09_XRND   // CVC_TTL_JOB_YR_SE.09
  rename Z9057701 CVC_TTL_JOB_YR_SE_10_XRND   // CVC_TTL_JOB_YR_SE.10
  rename Z9057702 CVC_TTL_JOB_YR_SE_11_XRND   // CVC_TTL_JOB_YR_SE.11
  rename Z9057703 CVC_TTL_JOB_YR_SE_12_XRND   // CVC_TTL_JOB_YR_SE.12
  rename Z9057704 CVC_TTL_JOB_YR_SE_13_XRND   // CVC_TTL_JOB_YR_SE.13
  rename Z9057705 CVC_TTL_JOB_YR_SE_14_XRND   // CVC_TTL_JOB_YR_SE.14
  rename Z9057706 CVC_TTL_JOB_YR_SE_15_XRND   // CVC_TTL_JOB_YR_SE.15
  rename Z9057707 CVC_TTL_JOB_YR_SE_16_XRND   // CVC_TTL_JOB_YR_SE.16
  rename Z9057708 CVC_TTL_JOB_YR_SE_17_XRND   // CVC_TTL_JOB_YR_SE.17
  rename Z9057709 CVC_TTL_JOB_YR_SE_18_XRND   // CVC_TTL_JOB_YR_SE.18
  rename Z9057710 CVC_TTL_JOB_YR_SE_19_XRND   // CVC_TTL_JOB_YR_SE.19
  rename Z9057711 CVC_TTL_JOB_YR_SE_20_XRND   // CVC_TTL_JOB_YR_SE.20
  rename Z9057712 CVC_TTL_JOB_YR_SE_21_XRND   // CVC_TTL_JOB_YR_SE.21
  rename Z9057713 CVC_TTL_JOB_YR_SE_22_XRND   // CVC_TTL_JOB_YR_SE.22
  rename Z9057800 CVC_TTL_JOB_YR_SE_98_XRND   // CVC_TTL_JOB_YR_SE.98
  rename Z9057900 CVC_TTL_JOB_YR_SE_99_XRND   // CVC_TTL_JOB_YR_SE.99
  rename Z9058000 CVC_WKSWK_YR_ET_00_XRND   // CVC_WKSWK_YR_ET.00
  rename Z9058100 CVC_WKSWK_YR_ET_01_XRND   // CVC_WKSWK_YR_ET.01
  rename Z9058200 CVC_WKSWK_YR_ET_02_XRND   // CVC_WKSWK_YR_ET.02
  rename Z9058300 CVC_WKSWK_YR_ET_03_XRND   // CVC_WKSWK_YR_ET.03
  rename Z9058400 CVC_WKSWK_YR_ET_04_XRND   // CVC_WKSWK_YR_ET.04
  rename Z9058500 CVC_WKSWK_YR_ET_05_XRND   // CVC_WKSWK_YR_ET.05
  rename Z9058600 CVC_WKSWK_YR_ET_06_XRND   // CVC_WKSWK_YR_ET.06
  rename Z9058700 CVC_WKSWK_YR_ET_07_XRND   // CVC_WKSWK_YR_ET.07
  rename Z9058800 CVC_WKSWK_YR_ET_08_XRND   // CVC_WKSWK_YR_ET.08
  rename Z9058900 CVC_WKSWK_YR_ET_09_XRND   // CVC_WKSWK_YR_ET.09
  rename Z9058901 CVC_WKSWK_YR_ET_10_XRND   // CVC_WKSWK_YR_ET.10
  rename Z9058902 CVC_WKSWK_YR_ET_11_XRND   // CVC_WKSWK_YR_ET.11
  rename Z9058903 CVC_WKSWK_YR_ET_12_XRND   // CVC_WKSWK_YR_ET.12
  rename Z9058904 CVC_WKSWK_YR_ET_13_XRND   // CVC_WKSWK_YR_ET.13
  rename Z9058905 CVC_WKSWK_YR_ET_14_XRND   // CVC_WKSWK_YR_ET.14
  rename Z9058906 CVC_WKSWK_YR_ET_15_XRND   // CVC_WKSWK_YR_ET.15
  rename Z9058907 CVC_WKSWK_YR_ET_16_XRND   // CVC_WKSWK_YR_ET.16
  rename Z9058908 CVC_WKSWK_YR_ET_17_XRND   // CVC_WKSWK_YR_ET.17
  rename Z9058909 CVC_WKSWK_YR_ET_18_XRND   // CVC_WKSWK_YR_ET.18
  rename Z9058910 CVC_WKSWK_YR_ET_19_XRND   // CVC_WKSWK_YR_ET.19
  rename Z9058911 CVC_WKSWK_YR_ET_20_XRND   // CVC_WKSWK_YR_ET.20
  rename Z9058912 CVC_WKSWK_YR_ET_21_XRND   // CVC_WKSWK_YR_ET.21
  rename Z9058913 CVC_WKSWK_YR_ET_22_XRND   // CVC_WKSWK_YR_ET.22
  rename Z9059000 CVC_WKSWK_YR_ET_80_XRND   // CVC_WKSWK_YR_ET.80
  rename Z9059100 CVC_WKSWK_YR_ET_81_XRND   // CVC_WKSWK_YR_ET.81
  rename Z9059200 CVC_WKSWK_YR_ET_82_XRND   // CVC_WKSWK_YR_ET.82
  rename Z9059300 CVC_WKSWK_YR_ET_83_XRND   // CVC_WKSWK_YR_ET.83
  rename Z9059400 CVC_WKSWK_YR_ET_84_XRND   // CVC_WKSWK_YR_ET.84
  rename Z9059500 CVC_WKSWK_YR_ET_85_XRND   // CVC_WKSWK_YR_ET.85
  rename Z9059600 CVC_WKSWK_YR_ET_86_XRND   // CVC_WKSWK_YR_ET.86
  rename Z9059700 CVC_WKSWK_YR_ET_87_XRND   // CVC_WKSWK_YR_ET.87
  rename Z9059800 CVC_WKSWK_YR_ET_88_XRND   // CVC_WKSWK_YR_ET.88
  rename Z9059900 CVC_WKSWK_YR_ET_89_XRND   // CVC_WKSWK_YR_ET.89
  rename Z9060000 CVC_WKSWK_YR_ET_90_XRND   // CVC_WKSWK_YR_ET.90
  rename Z9060100 CVC_WKSWK_YR_ET_91_XRND   // CVC_WKSWK_YR_ET.91
  rename Z9060200 CVC_WKSWK_YR_ET_92_XRND   // CVC_WKSWK_YR_ET.92
  rename Z9060300 CVC_WKSWK_YR_ET_93_XRND   // CVC_WKSWK_YR_ET.93
  rename Z9060400 CVC_WKSWK_YR_ET_94_XRND   // CVC_WKSWK_YR_ET.94
  rename Z9060500 CVC_WKSWK_YR_ET_95_XRND   // CVC_WKSWK_YR_ET.95
  rename Z9060600 CVC_WKSWK_YR_ET_96_XRND   // CVC_WKSWK_YR_ET.96
  rename Z9060700 CVC_WKSWK_YR_ET_97_XRND   // CVC_WKSWK_YR_ET.97
  rename Z9060800 CVC_WKSWK_YR_ET_98_XRND   // CVC_WKSWK_YR_ET.98
  rename Z9060900 CVC_WKSWK_YR_ET_99_XRND   // CVC_WKSWK_YR_ET.99
  rename Z9061000 CVC_WKSWK_YR_ALL_00_XRND   // CVC_WKSWK_YR_ALL.00
  rename Z9061100 CVC_WKSWK_YR_ALL_01_XRND   // CVC_WKSWK_YR_ALL.01
  rename Z9061200 CVC_WKSWK_YR_ALL_02_XRND   // CVC_WKSWK_YR_ALL.02
  rename Z9061300 CVC_WKSWK_YR_ALL_03_XRND   // CVC_WKSWK_YR_ALL.03
  rename Z9061400 CVC_WKSWK_YR_ALL_04_XRND   // CVC_WKSWK_YR_ALL.04
  rename Z9061500 CVC_WKSWK_YR_ALL_05_XRND   // CVC_WKSWK_YR_ALL.05
  rename Z9061600 CVC_WKSWK_YR_ALL_06_XRND   // CVC_WKSWK_YR_ALL.06
  rename Z9061700 CVC_WKSWK_YR_ALL_07_XRND   // CVC_WKSWK_YR_ALL.07
  rename Z9061800 CVC_WKSWK_YR_ALL_08_XRND   // CVC_WKSWK_YR_ALL.08
  rename Z9061900 CVC_WKSWK_YR_ALL_09_XRND   // CVC_WKSWK_YR_ALL.09
  rename Z9061901 CVC_WKSWK_YR_ALL_10_XRND   // CVC_WKSWK_YR_ALL.10
  rename Z9061902 CVC_WKSWK_YR_ALL_11_XRND   // CVC_WKSWK_YR_ALL.11
  rename Z9061903 CVC_WKSWK_YR_ALL_12_XRND   // CVC_WKSWK_YR_ALL.12
  rename Z9061904 CVC_WKSWK_YR_ALL_13_XRND   // CVC_WKSWK_YR_ALL.13
  rename Z9061905 CVC_WKSWK_YR_ALL_14_XRND   // CVC_WKSWK_YR_ALL.14
  rename Z9061906 CVC_WKSWK_YR_ALL_15_XRND   // CVC_WKSWK_YR_ALL.15
  rename Z9061907 CVC_WKSWK_YR_ALL_16_XRND   // CVC_WKSWK_YR_ALL.16
  rename Z9061908 CVC_WKSWK_YR_ALL_17_XRND   // CVC_WKSWK_YR_ALL.17
  rename Z9061909 CVC_WKSWK_YR_ALL_18_XRND   // CVC_WKSWK_YR_ALL.18
  rename Z9061910 CVC_WKSWK_YR_ALL_19_XRND   // CVC_WKSWK_YR_ALL.19
  rename Z9061911 CVC_WKSWK_YR_ALL_20_XRND   // CVC_WKSWK_YR_ALL.20
  rename Z9061912 CVC_WKSWK_YR_ALL_21_XRND   // CVC_WKSWK_YR_ALL.21
  rename Z9061913 CVC_WKSWK_YR_ALL_22_XRND   // CVC_WKSWK_YR_ALL.22
  rename Z9062000 CVC_WKSWK_YR_ALL_80_XRND   // CVC_WKSWK_YR_ALL.80
  rename Z9062100 CVC_WKSWK_YR_ALL_81_XRND   // CVC_WKSWK_YR_ALL.81
  rename Z9062200 CVC_WKSWK_YR_ALL_82_XRND   // CVC_WKSWK_YR_ALL.82
  rename Z9062300 CVC_WKSWK_YR_ALL_83_XRND   // CVC_WKSWK_YR_ALL.83
  rename Z9062400 CVC_WKSWK_YR_ALL_84_XRND   // CVC_WKSWK_YR_ALL.84
  rename Z9062500 CVC_WKSWK_YR_ALL_85_XRND   // CVC_WKSWK_YR_ALL.85
  rename Z9062600 CVC_WKSWK_YR_ALL_86_XRND   // CVC_WKSWK_YR_ALL.86
  rename Z9062700 CVC_WKSWK_YR_ALL_87_XRND   // CVC_WKSWK_YR_ALL.87
  rename Z9062800 CVC_WKSWK_YR_ALL_88_XRND   // CVC_WKSWK_YR_ALL.88
  rename Z9062900 CVC_WKSWK_YR_ALL_89_XRND   // CVC_WKSWK_YR_ALL.89
  rename Z9063000 CVC_WKSWK_YR_ALL_90_XRND   // CVC_WKSWK_YR_ALL.90
  rename Z9063100 CVC_WKSWK_YR_ALL_91_XRND   // CVC_WKSWK_YR_ALL.91
  rename Z9063200 CVC_WKSWK_YR_ALL_92_XRND   // CVC_WKSWK_YR_ALL.92
  rename Z9063300 CVC_WKSWK_YR_ALL_93_XRND   // CVC_WKSWK_YR_ALL.93
  rename Z9063400 CVC_WKSWK_YR_ALL_94_XRND   // CVC_WKSWK_YR_ALL.94
  rename Z9063500 CVC_WKSWK_YR_ALL_95_XRND   // CVC_WKSWK_YR_ALL.95
  rename Z9063600 CVC_WKSWK_YR_ALL_96_XRND   // CVC_WKSWK_YR_ALL.96
  rename Z9063700 CVC_WKSWK_YR_ALL_97_XRND   // CVC_WKSWK_YR_ALL.97
  rename Z9063800 CVC_WKSWK_YR_ALL_98_XRND   // CVC_WKSWK_YR_ALL.98
  rename Z9063900 CVC_WKSWK_YR_ALL_99_XRND   // CVC_WKSWK_YR_ALL.99
  rename Z9064000 CVC_WKSWK_YR_SE_00_XRND   // CVC_WKSWK_YR_SE.00
  rename Z9064100 CVC_WKSWK_YR_SE_01_XRND   // CVC_WKSWK_YR_SE.01
  rename Z9064200 CVC_WKSWK_YR_SE_02_XRND   // CVC_WKSWK_YR_SE.02
  rename Z9064300 CVC_WKSWK_YR_SE_03_XRND   // CVC_WKSWK_YR_SE.03
  rename Z9064400 CVC_WKSWK_YR_SE_04_XRND   // CVC_WKSWK_YR_SE.04
  rename Z9064500 CVC_WKSWK_YR_SE_05_XRND   // CVC_WKSWK_YR_SE.05
  rename Z9064600 CVC_WKSWK_YR_SE_06_XRND   // CVC_WKSWK_YR_SE.06
  rename Z9064700 CVC_WKSWK_YR_SE_07_XRND   // CVC_WKSWK_YR_SE.07
  rename Z9064800 CVC_WKSWK_YR_SE_08_XRND   // CVC_WKSWK_YR_SE.08
  rename Z9064900 CVC_WKSWK_YR_SE_09_XRND   // CVC_WKSWK_YR_SE.09
  rename Z9064901 CVC_WKSWK_YR_SE_10_XRND   // CVC_WKSWK_YR_SE.10
  rename Z9064902 CVC_WKSWK_YR_SE_11_XRND   // CVC_WKSWK_YR_SE.11
  rename Z9064903 CVC_WKSWK_YR_SE_12_XRND   // CVC_WKSWK_YR_SE.12
  rename Z9064904 CVC_WKSWK_YR_SE_13_XRND   // CVC_WKSWK_YR_SE.13
  rename Z9064905 CVC_WKSWK_YR_SE_14_XRND   // CVC_WKSWK_YR_SE.14
  rename Z9064906 CVC_WKSWK_YR_SE_15_XRND   // CVC_WKSWK_YR_SE.15
  rename Z9064907 CVC_WKSWK_YR_SE_16_XRND   // CVC_WKSWK_YR_SE.16
  rename Z9064908 CVC_WKSWK_YR_SE_17_XRND   // CVC_WKSWK_YR_SE.17
  rename Z9064909 CVC_WKSWK_YR_SE_18_XRND   // CVC_WKSWK_YR_SE.18
  rename Z9064910 CVC_WKSWK_YR_SE_19_XRND   // CVC_WKSWK_YR_SE.19
  rename Z9064911 CVC_WKSWK_YR_SE_20_XRND   // CVC_WKSWK_YR_SE.20
  rename Z9064912 CVC_WKSWK_YR_SE_21_XRND   // CVC_WKSWK_YR_SE.21
  rename Z9064913 CVC_WKSWK_YR_SE_22_XRND   // CVC_WKSWK_YR_SE.22
  rename Z9065000 CVC_WKSWK_YR_SE_98_XRND   // CVC_WKSWK_YR_SE.98
  rename Z9065100 CVC_WKSWK_YR_SE_99_XRND   // CVC_WKSWK_YR_SE.99
  rename Z9065201 CVC_WKSWK_TEEN2_XRND 
  rename Z9065301 CVC_WKSWK_ADULT2_ET_XRND 
  rename Z9065401 CVC_WKSWK_ADULT2_ALL_XRND 
  rename Z9065800 CVC_HOURS_WK_YR_ET_00_XRND   // CVC_HOURS_WK_YR_ET.00
  rename Z9065900 CVC_HOURS_WK_YR_ET_01_XRND   // CVC_HOURS_WK_YR_ET.01
  rename Z9066000 CVC_HOURS_WK_YR_ET_02_XRND   // CVC_HOURS_WK_YR_ET.02
  rename Z9066100 CVC_HOURS_WK_YR_ET_03_XRND   // CVC_HOURS_WK_YR_ET.03
  rename Z9066200 CVC_HOURS_WK_YR_ET_04_XRND   // CVC_HOURS_WK_YR_ET.04
  rename Z9066300 CVC_HOURS_WK_YR_ET_05_XRND   // CVC_HOURS_WK_YR_ET.05
  rename Z9066400 CVC_HOURS_WK_YR_ET_06_XRND   // CVC_HOURS_WK_YR_ET.06
  rename Z9066500 CVC_HOURS_WK_YR_ET_07_XRND   // CVC_HOURS_WK_YR_ET.07
  rename Z9066600 CVC_HOURS_WK_YR_ET_08_XRND   // CVC_HOURS_WK_YR_ET.08
  rename Z9066700 CVC_HOURS_WK_YR_ET_09_XRND   // CVC_HOURS_WK_YR_ET.09
  rename Z9066701 CVC_HOURS_WK_YR_ET_10_XRND   // CVC_HOURS_WK_YR_ET.10
  rename Z9066702 CVC_HOURS_WK_YR_ET_11_XRND   // CVC_HOURS_WK_YR_ET.11
  rename Z9066703 CVC_HOURS_WK_YR_ET_12_XRND   // CVC_HOURS_WK_YR_ET.12
  rename Z9066704 CVC_HOURS_WK_YR_ET_13_XRND   // CVC_HOURS_WK_YR_ET.13
  rename Z9066705 CVC_HOURS_WK_YR_ET_14_XRND   // CVC_HOURS_WK_YR_ET.14
  rename Z9066706 CVC_HOURS_WK_YR_ET_15_XRND   // CVC_HOURS_WK_YR_ET.15
  rename Z9066707 CVC_HOURS_WK_YR_ET_16_XRND   // CVC_HOURS_WK_YR_ET.16
  rename Z9066708 CVC_HOURS_WK_YR_ET_17_XRND   // CVC_HOURS_WK_YR_ET.17
  rename Z9066709 CVC_HOURS_WK_YR_ET_18_XRND   // CVC_HOURS_WK_YR_ET.18
  rename Z9066710 CVC_HOURS_WK_YR_ET_19_XRND   // CVC_HOURS_WK_YR_ET.19
  rename Z9066711 CVC_HOURS_WK_YR_ET_20_XRND   // CVC_HOURS_WK_YR_ET.20
  rename Z9066712 CVC_HOURS_WK_YR_ET_21_XRND   // CVC_HOURS_WK_YR_ET.21
  rename Z9066713 CVC_HOURS_WK_YR_ET_22_XRND   // CVC_HOURS_WK_YR_ET.22
  rename Z9066800 CVC_HOURS_WK_YR_ET_80_XRND   // CVC_HOURS_WK_YR_ET.80
  rename Z9066900 CVC_HOURS_WK_YR_ET_81_XRND   // CVC_HOURS_WK_YR_ET.81
  rename Z9067000 CVC_HOURS_WK_YR_ET_82_XRND   // CVC_HOURS_WK_YR_ET.82
  rename Z9067100 CVC_HOURS_WK_YR_ET_83_XRND   // CVC_HOURS_WK_YR_ET.83
  rename Z9067200 CVC_HOURS_WK_YR_ET_84_XRND   // CVC_HOURS_WK_YR_ET.84
  rename Z9067300 CVC_HOURS_WK_YR_ET_85_XRND   // CVC_HOURS_WK_YR_ET.85
  rename Z9067400 CVC_HOURS_WK_YR_ET_86_XRND   // CVC_HOURS_WK_YR_ET.86
  rename Z9067500 CVC_HOURS_WK_YR_ET_87_XRND   // CVC_HOURS_WK_YR_ET.87
  rename Z9067600 CVC_HOURS_WK_YR_ET_88_XRND   // CVC_HOURS_WK_YR_ET.88
  rename Z9067700 CVC_HOURS_WK_YR_ET_89_XRND   // CVC_HOURS_WK_YR_ET.89
  rename Z9067800 CVC_HOURS_WK_YR_ET_90_XRND   // CVC_HOURS_WK_YR_ET.90
  rename Z9067900 CVC_HOURS_WK_YR_ET_91_XRND   // CVC_HOURS_WK_YR_ET.91
  rename Z9068000 CVC_HOURS_WK_YR_ET_92_XRND   // CVC_HOURS_WK_YR_ET.92
  rename Z9068100 CVC_HOURS_WK_YR_ET_93_XRND   // CVC_HOURS_WK_YR_ET.93
  rename Z9068200 CVC_HOURS_WK_YR_ET_94_XRND   // CVC_HOURS_WK_YR_ET.94
  rename Z9068300 CVC_HOURS_WK_YR_ET_95_XRND   // CVC_HOURS_WK_YR_ET.95
  rename Z9068400 CVC_HOURS_WK_YR_ET_96_XRND   // CVC_HOURS_WK_YR_ET.96
  rename Z9068500 CVC_HOURS_WK_YR_ET_97_XRND   // CVC_HOURS_WK_YR_ET.97
  rename Z9068600 CVC_HOURS_WK_YR_ET_98_XRND   // CVC_HOURS_WK_YR_ET.98
  rename Z9068700 CVC_HOURS_WK_YR_ET_99_XRND   // CVC_HOURS_WK_YR_ET.99
  rename Z9068800 CVC_HOURS_WK_YR_ALL_00_XRND   // CVC_HOURS_WK_YR_ALL.00
  rename Z9068900 CVC_HOURS_WK_YR_ALL_01_XRND   // CVC_HOURS_WK_YR_ALL.01
  rename Z9069000 CVC_HOURS_WK_YR_ALL_02_XRND   // CVC_HOURS_WK_YR_ALL.02
  rename Z9069100 CVC_HOURS_WK_YR_ALL_03_XRND   // CVC_HOURS_WK_YR_ALL.03
  rename Z9069200 CVC_HOURS_WK_YR_ALL_04_XRND   // CVC_HOURS_WK_YR_ALL.04
  rename Z9069300 CVC_HOURS_WK_YR_ALL_05_XRND   // CVC_HOURS_WK_YR_ALL.05
  rename Z9069400 CVC_HOURS_WK_YR_ALL_06_XRND   // CVC_HOURS_WK_YR_ALL.06
  rename Z9069500 CVC_HOURS_WK_YR_ALL_07_XRND   // CVC_HOURS_WK_YR_ALL.07
  rename Z9069600 CVC_HOURS_WK_YR_ALL_08_XRND   // CVC_HOURS_WK_YR_ALL.08
  rename Z9069700 CVC_HOURS_WK_YR_ALL_09_XRND   // CVC_HOURS_WK_YR_ALL.09
  rename Z9069701 CVC_HOURS_WK_YR_ALL_10_XRND   // CVC_HOURS_WK_YR_ALL.10
  rename Z9069702 CVC_HOURS_WK_YR_ALL_11_XRND   // CVC_HOURS_WK_YR_ALL.11
  rename Z9069703 CVC_HOURS_WK_YR_ALL_12_XRND   // CVC_HOURS_WK_YR_ALL.12
  rename Z9069704 CVC_HOURS_WK_YR_ALL_13_XRND   // CVC_HOURS_WK_YR_ALL.13
  rename Z9069705 CVC_HOURS_WK_YR_ALL_14_XRND   // CVC_HOURS_WK_YR_ALL.14
  rename Z9069706 CVC_HOURS_WK_YR_ALL_15_XRND   // CVC_HOURS_WK_YR_ALL.15
  rename Z9069707 CVC_HOURS_WK_YR_ALL_16_XRND   // CVC_HOURS_WK_YR_ALL.16
  rename Z9069708 CVC_HOURS_WK_YR_ALL_17_XRND   // CVC_HOURS_WK_YR_ALL.17
  rename Z9069709 CVC_HOURS_WK_YR_ALL_18_XRND   // CVC_HOURS_WK_YR_ALL.18
  rename Z9069710 CVC_HOURS_WK_YR_ALL_19_XRND   // CVC_HOURS_WK_YR_ALL.19
  rename Z9069711 CVC_HOURS_WK_YR_ALL_20_XRND   // CVC_HOURS_WK_YR_ALL.20
  rename Z9069712 CVC_HOURS_WK_YR_ALL_21_XRND   // CVC_HOURS_WK_YR_ALL.21
  rename Z9069713 CVC_HOURS_WK_YR_ALL_22_XRND   // CVC_HOURS_WK_YR_ALL.22
  rename Z9069800 CVC_HOURS_WK_YR_ALL_80_XRND   // CVC_HOURS_WK_YR_ALL.80
  rename Z9069900 CVC_HOURS_WK_YR_ALL_81_XRND   // CVC_HOURS_WK_YR_ALL.81
  rename Z9070000 CVC_HOURS_WK_YR_ALL_82_XRND   // CVC_HOURS_WK_YR_ALL.82
  rename Z9070100 CVC_HOURS_WK_YR_ALL_83_XRND   // CVC_HOURS_WK_YR_ALL.83
  rename Z9070200 CVC_HOURS_WK_YR_ALL_84_XRND   // CVC_HOURS_WK_YR_ALL.84
  rename Z9070300 CVC_HOURS_WK_YR_ALL_85_XRND   // CVC_HOURS_WK_YR_ALL.85
  rename Z9070400 CVC_HOURS_WK_YR_ALL_86_XRND   // CVC_HOURS_WK_YR_ALL.86
  rename Z9070500 CVC_HOURS_WK_YR_ALL_87_XRND   // CVC_HOURS_WK_YR_ALL.87
  rename Z9070600 CVC_HOURS_WK_YR_ALL_88_XRND   // CVC_HOURS_WK_YR_ALL.88
  rename Z9070700 CVC_HOURS_WK_YR_ALL_89_XRND   // CVC_HOURS_WK_YR_ALL.89
  rename Z9070800 CVC_HOURS_WK_YR_ALL_90_XRND   // CVC_HOURS_WK_YR_ALL.90
  rename Z9070900 CVC_HOURS_WK_YR_ALL_91_XRND   // CVC_HOURS_WK_YR_ALL.91
  rename Z9071000 CVC_HOURS_WK_YR_ALL_92_XRND   // CVC_HOURS_WK_YR_ALL.92
  rename Z9071100 CVC_HOURS_WK_YR_ALL_93_XRND   // CVC_HOURS_WK_YR_ALL.93
  rename Z9071200 CVC_HOURS_WK_YR_ALL_94_XRND   // CVC_HOURS_WK_YR_ALL.94
  rename Z9071300 CVC_HOURS_WK_YR_ALL_95_XRND   // CVC_HOURS_WK_YR_ALL.95
  rename Z9071400 CVC_HOURS_WK_YR_ALL_96_XRND   // CVC_HOURS_WK_YR_ALL.96
  rename Z9071500 CVC_HOURS_WK_YR_ALL_97_XRND   // CVC_HOURS_WK_YR_ALL.97
  rename Z9071600 CVC_HOURS_WK_YR_ALL_98_XRND   // CVC_HOURS_WK_YR_ALL.98
  rename Z9071700 CVC_HOURS_WK_YR_ALL_99_XRND   // CVC_HOURS_WK_YR_ALL.99
  rename Z9071800 CVC_HOURS_WK_YR_SE_00_XRND   // CVC_HOURS_WK_YR_SE.00
  rename Z9071900 CVC_HOURS_WK_YR_SE_01_XRND   // CVC_HOURS_WK_YR_SE.01
  rename Z9072000 CVC_HOURS_WK_YR_SE_02_XRND   // CVC_HOURS_WK_YR_SE.02
  rename Z9072100 CVC_HOURS_WK_YR_SE_03_XRND   // CVC_HOURS_WK_YR_SE.03
  rename Z9072200 CVC_HOURS_WK_YR_SE_04_XRND   // CVC_HOURS_WK_YR_SE.04
  rename Z9072300 CVC_HOURS_WK_YR_SE_05_XRND   // CVC_HOURS_WK_YR_SE.05
  rename Z9072400 CVC_HOURS_WK_YR_SE_06_XRND   // CVC_HOURS_WK_YR_SE.06
  rename Z9072500 CVC_HOURS_WK_YR_SE_07_XRND   // CVC_HOURS_WK_YR_SE.07
  rename Z9072600 CVC_HOURS_WK_YR_SE_08_XRND   // CVC_HOURS_WK_YR_SE.08
  rename Z9072700 CVC_HOURS_WK_YR_SE_09_XRND   // CVC_HOURS_WK_YR_SE.09
  rename Z9072701 CVC_HOURS_WK_YR_SE_10_XRND   // CVC_HOURS_WK_YR_SE.10
  rename Z9072702 CVC_HOURS_WK_YR_SE_11_XRND   // CVC_HOURS_WK_YR_SE.11
  rename Z9072703 CVC_HOURS_WK_YR_SE_12_XRND   // CVC_HOURS_WK_YR_SE.12
  rename Z9072704 CVC_HOURS_WK_YR_SE_13_XRND   // CVC_HOURS_WK_YR_SE.13
  rename Z9072705 CVC_HOURS_WK_YR_SE_14_XRND   // CVC_HOURS_WK_YR_SE.14
  rename Z9072706 CVC_HOURS_WK_YR_SE_15_XRND   // CVC_HOURS_WK_YR_SE.15
  rename Z9072707 CVC_HOURS_WK_YR_SE_16_XRND   // CVC_HOURS_WK_YR_SE.16
  rename Z9072708 CVC_HOURS_WK_YR_SE_17_XRND   // CVC_HOURS_WK_YR_SE.17
  rename Z9072709 CVC_HOURS_WK_YR_SE_18_XRND   // CVC_HOURS_WK_YR_SE.18
  rename Z9072710 CVC_HOURS_WK_YR_SE_19_XRND   // CVC_HOURS_WK_YR_SE.19
  rename Z9072711 CVC_HOURS_WK_YR_SE_20_XRND   // CVC_HOURS_WK_YR_SE.20
  rename Z9072712 CVC_HOURS_WK_YR_SE_21_XRND   // CVC_HOURS_WK_YR_SE.21
  rename Z9072713 CVC_HOURS_WK_YR_SE_22_XRND   // CVC_HOURS_WK_YR_SE.22
  rename Z9072800 CVC_HOURS_WK_YR_SE_98_XRND   // CVC_HOURS_WK_YR_SE.98
  rename Z9072900 CVC_HOURS_WK_YR_SE_99_XRND   // CVC_HOURS_WK_YR_SE.99
  rename Z9073000 CVC_FIRST_COHAB_DATE_M_XRND   // CVC_FIRST_COHAB_DATE~M
  rename Z9073001 CVC_FIRST_COHAB_DATE_Y_XRND   // CVC_FIRST_COHAB_DATE~Y
  rename Z9073100 CVC_FIRST_COHAB_MONTH_XRND 
  rename Z9073200 CVC_FIRST_MARRY_DATE_M_XRND   // CVC_FIRST_MARRY_DATE~M
  rename Z9073201 CVC_FIRST_MARRY_DATE_Y_XRND   // CVC_FIRST_MARRY_DATE~Y
  rename Z9073300 CVC_FIRST_MARRY_MONTH_XRND 
  rename Z9073400 CVC_FIRST_MARRY_END_XRND 
  rename Z9073500 CVC_FIRST_MARRY_END_DATE_M_XRND   // CVC_FIRST_MARRY_END_DATE~M
  rename Z9073501 CVC_FIRST_MARRY_END_DATE_Y_XRND   // CVC_FIRST_MARRY_END_DATE~Y
  rename Z9073600 CVC_FIRST_MARRY_END_MONTH_XRND 
  rename Z9073700 CVC_UI_SPELLS_YR_00_XRND   // CVC_UI_SPELLS_YR.00
  rename Z9073800 CVC_UI_SPELLS_YR_01_XRND   // CVC_UI_SPELLS_YR.01
  rename Z9073900 CVC_UI_SPELLS_YR_02_XRND   // CVC_UI_SPELLS_YR.02
  rename Z9074000 CVC_UI_SPELLS_YR_03_XRND   // CVC_UI_SPELLS_YR.03
  rename Z9074100 CVC_UI_SPELLS_YR_04_XRND   // CVC_UI_SPELLS_YR.04
  rename Z9074200 CVC_UI_SPELLS_YR_05_XRND   // CVC_UI_SPELLS_YR.05
  rename Z9074300 CVC_UI_SPELLS_YR_06_XRND   // CVC_UI_SPELLS_YR.06
  rename Z9074400 CVC_UI_SPELLS_YR_07_XRND   // CVC_UI_SPELLS_YR.07
  rename Z9074500 CVC_UI_SPELLS_YR_08_XRND   // CVC_UI_SPELLS_YR.08
  rename Z9074600 CVC_UI_SPELLS_YR_09_XRND   // CVC_UI_SPELLS_YR.09
  rename Z9074601 CVC_UI_SPELLS_YR_10_XRND   // CVC_UI_SPELLS_YR.10
  rename Z9074602 CVC_UI_SPELLS_YR_11_XRND   // CVC_UI_SPELLS_YR.11
  rename Z9074603 CVC_UI_SPELLS_YR_12_XRND   // CVC_UI_SPELLS_YR.12
  rename Z9074604 CVC_UI_SPELLS_YR_13_XRND   // CVC_UI_SPELLS_YR.13
  rename Z9074605 CVC_UI_SPELLS_YR_14_XRND   // CVC_UI_SPELLS_YR.14
  rename Z9074606 CVC_UI_SPELLS_YR_15_XRND   // CVC_UI_SPELLS_YR.15
  rename Z9074607 CVC_UI_SPELLS_YR_16_XRND   // CVC_UI_SPELLS_YR.16
  rename Z9074608 CVC_UI_SPELLS_YR_17_XRND   // CVC_UI_SPELLS_YR.17
  rename Z9074609 CVC_UI_SPELLS_YR_18_XRND   // CVC_UI_SPELLS_YR.18
  rename Z9074610 CVC_UI_SPELLS_YR_19_XRND   // CVC_UI_SPELLS_YR.19
  rename Z9074611 CVC_UI_SPELLS_YR_20_XRND   // CVC_UI_SPELLS_YR.20
  rename Z9074612 CVC_UI_SPELLS_YR_21_XRND   // CVC_UI_SPELLS_YR.21
  rename Z9074613 CVC_UI_SPELLS_YR_22_XRND   // CVC_UI_SPELLS_YR.22
  rename Z9074700 CVC_UI_SPELLS_YR_97_XRND   // CVC_UI_SPELLS_YR.97
  rename Z9074800 CVC_UI_SPELLS_YR_98_XRND   // CVC_UI_SPELLS_YR.98
  rename Z9074900 CVC_UI_SPELLS_YR_99_XRND   // CVC_UI_SPELLS_YR.99
  rename Z9075000 CVC_UI_EVER_XRND 
  rename Z9075100 CVC_UI_YR_00_XRND   // CVC_UI_YR.00
  rename Z9075200 CVC_UI_YR_01_XRND   // CVC_UI_YR.01
  rename Z9075300 CVC_UI_YR_02_XRND   // CVC_UI_YR.02
  rename Z9075400 CVC_UI_YR_03_XRND   // CVC_UI_YR.03
  rename Z9075500 CVC_UI_YR_04_XRND   // CVC_UI_YR.04
  rename Z9075600 CVC_UI_YR_05_XRND   // CVC_UI_YR.05
  rename Z9075700 CVC_UI_YR_06_XRND   // CVC_UI_YR.06
  rename Z9075800 CVC_UI_YR_07_XRND   // CVC_UI_YR.07
  rename Z9075900 CVC_UI_YR_08_XRND   // CVC_UI_YR.08
  rename Z9076000 CVC_UI_YR_09_XRND   // CVC_UI_YR.09
  rename Z9076001 CVC_UI_YR_10_XRND   // CVC_UI_YR.10
  rename Z9076002 CVC_UI_YR_11_XRND   // CVC_UI_YR.11
  rename Z9076003 CVC_UI_YR_12_XRND   // CVC_UI_YR.12
  rename Z9076004 CVC_UI_YR_13_XRND   // CVC_UI_YR.13
  rename Z9076005 CVC_UI_YR_14_XRND   // CVC_UI_YR.14
  rename Z9076006 CVC_UI_YR_15_XRND   // CVC_UI_YR.15
  rename Z9076007 CVC_UI_YR_16_XRND   // CVC_UI_YR.16
  rename Z9076008 CVC_UI_YR_17_XRND   // CVC_UI_YR.17
  rename Z9076009 CVC_UI_YR_18_XRND   // CVC_UI_YR.18
  rename Z9076010 CVC_UI_YR_19_XRND   // CVC_UI_YR.19
  rename Z9076011 CVC_UI_YR_20_XRND   // CVC_UI_YR.20
  rename Z9076012 CVC_UI_YR_21_XRND   // CVC_UI_YR.21
  rename Z9076013 CVC_UI_YR_22_XRND   // CVC_UI_YR.22
  rename Z9076100 CVC_UI_YR_97_XRND   // CVC_UI_YR.97
  rename Z9076200 CVC_UI_YR_98_XRND   // CVC_UI_YR.98
  rename Z9076300 CVC_UI_YR_99_XRND   // CVC_UI_YR.99
  rename Z9076400 CVC_GOVNT_PRG_YR_00_XRND   // CVC_GOVNT_PRG_YR.00
  rename Z9076500 CVC_GOVNT_PRG_YR_01_XRND   // CVC_GOVNT_PRG_YR.01
  rename Z9076600 CVC_GOVNT_PRG_YR_02_XRND   // CVC_GOVNT_PRG_YR.02
  rename Z9076700 CVC_GOVNT_PRG_YR_03_XRND   // CVC_GOVNT_PRG_YR.03
  rename Z9076800 CVC_GOVNT_PRG_YR_04_XRND   // CVC_GOVNT_PRG_YR.04
  rename Z9076900 CVC_GOVNT_PRG_YR_05_XRND   // CVC_GOVNT_PRG_YR.05
  rename Z9077000 CVC_GOVNT_PRG_YR_06_XRND   // CVC_GOVNT_PRG_YR.06
  rename Z9077100 CVC_GOVNT_PRG_YR_07_XRND   // CVC_GOVNT_PRG_YR.07
  rename Z9077200 CVC_GOVNT_PRG_YR_08_XRND   // CVC_GOVNT_PRG_YR.08
  rename Z9077300 CVC_GOVNT_PRG_YR_09_XRND   // CVC_GOVNT_PRG_YR.09
  rename Z9077400 CVC_GOVNT_PRG_YR_80_XRND   // CVC_GOVNT_PRG_YR.80
  rename Z9077500 CVC_GOVNT_PRG_YR_81_XRND   // CVC_GOVNT_PRG_YR.81
  rename Z9077600 CVC_GOVNT_PRG_YR_82_XRND   // CVC_GOVNT_PRG_YR.82
  rename Z9077700 CVC_GOVNT_PRG_YR_83_XRND   // CVC_GOVNT_PRG_YR.83
  rename Z9077800 CVC_GOVNT_PRG_YR_84_XRND   // CVC_GOVNT_PRG_YR.84
  rename Z9077900 CVC_GOVNT_PRG_YR_85_XRND   // CVC_GOVNT_PRG_YR.85
  rename Z9078000 CVC_GOVNT_PRG_YR_86_XRND   // CVC_GOVNT_PRG_YR.86
  rename Z9078100 CVC_GOVNT_PRG_YR_87_XRND   // CVC_GOVNT_PRG_YR.87
  rename Z9078200 CVC_GOVNT_PRG_YR_88_XRND   // CVC_GOVNT_PRG_YR.88
  rename Z9078300 CVC_GOVNT_PRG_YR_89_XRND   // CVC_GOVNT_PRG_YR.89
  rename Z9078400 CVC_GOVNT_PRG_YR_90_XRND   // CVC_GOVNT_PRG_YR.90
  rename Z9078500 CVC_GOVNT_PRG_YR_91_XRND   // CVC_GOVNT_PRG_YR.91
  rename Z9078600 CVC_GOVNT_PRG_YR_92_XRND   // CVC_GOVNT_PRG_YR.92
  rename Z9078700 CVC_GOVNT_PRG_YR_93_XRND   // CVC_GOVNT_PRG_YR.93
  rename Z9078800 CVC_GOVNT_PRG_YR_94_XRND   // CVC_GOVNT_PRG_YR.94
  rename Z9078900 CVC_GOVNT_PRG_YR_95_XRND   // CVC_GOVNT_PRG_YR.95
  rename Z9079000 CVC_GOVNT_PRG_YR_96_XRND   // CVC_GOVNT_PRG_YR.96
  rename Z9079100 CVC_GOVNT_PRG_YR_97_XRND   // CVC_GOVNT_PRG_YR.97
  rename Z9079200 CVC_GOVNT_PRG_YR_98_XRND   // CVC_GOVNT_PRG_YR.98
  rename Z9079300 CVC_GOVNT_PRG_YR_99_XRND   // CVC_GOVNT_PRG_YR.99
  rename Z9079400 CVC_GOVNT_PRG_EVER_XRND 
  rename Z9079500 CVC_AMT_GOVNT_PRG_YR_00_XRND   // CVC_AMT_GOVNT_PRG_YR.00
  rename Z9079600 CVC_AMT_GOVNT_PRG_YR_01_XRND   // CVC_AMT_GOVNT_PRG_YR.01
  rename Z9079700 CVC_AMT_GOVNT_PRG_YR_02_XRND   // CVC_AMT_GOVNT_PRG_YR.02
  rename Z9079800 CVC_AMT_GOVNT_PRG_YR_03_XRND   // CVC_AMT_GOVNT_PRG_YR.03
  rename Z9079900 CVC_AMT_GOVNT_PRG_YR_04_XRND   // CVC_AMT_GOVNT_PRG_YR.04
  rename Z9080000 CVC_AMT_GOVNT_PRG_YR_05_XRND   // CVC_AMT_GOVNT_PRG_YR.05
  rename Z9080100 CVC_AMT_GOVNT_PRG_YR_06_XRND   // CVC_AMT_GOVNT_PRG_YR.06
  rename Z9080200 CVC_AMT_GOVNT_PRG_YR_07_XRND   // CVC_AMT_GOVNT_PRG_YR.07
  rename Z9080300 CVC_AMT_GOVNT_PRG_YR_08_XRND   // CVC_AMT_GOVNT_PRG_YR.08
  rename Z9080400 CVC_AMT_GOVNT_PRG_YR_09_XRND   // CVC_AMT_GOVNT_PRG_YR.09
  rename Z9080500 CVC_AMT_GOVNT_PRG_YR_80_XRND   // CVC_AMT_GOVNT_PRG_YR.80
  rename Z9080600 CVC_AMT_GOVNT_PRG_YR_81_XRND   // CVC_AMT_GOVNT_PRG_YR.81
  rename Z9080700 CVC_AMT_GOVNT_PRG_YR_82_XRND   // CVC_AMT_GOVNT_PRG_YR.82
  rename Z9080800 CVC_AMT_GOVNT_PRG_YR_83_XRND   // CVC_AMT_GOVNT_PRG_YR.83
  rename Z9080900 CVC_AMT_GOVNT_PRG_YR_84_XRND   // CVC_AMT_GOVNT_PRG_YR.84
  rename Z9081000 CVC_AMT_GOVNT_PRG_YR_85_XRND   // CVC_AMT_GOVNT_PRG_YR.85
  rename Z9081100 CVC_AMT_GOVNT_PRG_YR_86_XRND   // CVC_AMT_GOVNT_PRG_YR.86
  rename Z9081200 CVC_AMT_GOVNT_PRG_YR_87_XRND   // CVC_AMT_GOVNT_PRG_YR.87
  rename Z9081300 CVC_AMT_GOVNT_PRG_YR_88_XRND   // CVC_AMT_GOVNT_PRG_YR.88
  rename Z9081400 CVC_AMT_GOVNT_PRG_YR_89_XRND   // CVC_AMT_GOVNT_PRG_YR.89
  rename Z9081500 CVC_AMT_GOVNT_PRG_YR_90_XRND   // CVC_AMT_GOVNT_PRG_YR.90
  rename Z9081600 CVC_AMT_GOVNT_PRG_YR_91_XRND   // CVC_AMT_GOVNT_PRG_YR.91
  rename Z9081700 CVC_AMT_GOVNT_PRG_YR_92_XRND   // CVC_AMT_GOVNT_PRG_YR.92
  rename Z9081800 CVC_AMT_GOVNT_PRG_YR_93_XRND   // CVC_AMT_GOVNT_PRG_YR.93
  rename Z9081900 CVC_AMT_GOVNT_PRG_YR_94_XRND   // CVC_AMT_GOVNT_PRG_YR.94
  rename Z9082000 CVC_AMT_GOVNT_PRG_YR_95_XRND   // CVC_AMT_GOVNT_PRG_YR.95
  rename Z9082100 CVC_AMT_GOVNT_PRG_YR_96_XRND   // CVC_AMT_GOVNT_PRG_YR.96
  rename Z9082200 CVC_AMT_GOVNT_PRG_YR_97_XRND   // CVC_AMT_GOVNT_PRG_YR.97
  rename Z9082300 CVC_AMT_GOVNT_PRG_YR_98_XRND   // CVC_AMT_GOVNT_PRG_YR.98
  rename Z9082400 CVC_AMT_GOVNT_PRG_YR_99_XRND   // CVC_AMT_GOVNT_PRG_YR.99
  rename Z9082500 CVC_AMT_UI_YR_00_XRND   // CVC_AMT_UI_YR.00
  rename Z9082600 CVC_AMT_UI_YR_01_XRND   // CVC_AMT_UI_YR.01
  rename Z9082700 CVC_AMT_UI_YR_02_XRND   // CVC_AMT_UI_YR.02
  rename Z9082800 CVC_AMT_UI_YR_03_XRND   // CVC_AMT_UI_YR.03
  rename Z9082900 CVC_AMT_UI_YR_04_XRND   // CVC_AMT_UI_YR.04
  rename Z9083000 CVC_AMT_UI_YR_05_XRND   // CVC_AMT_UI_YR.05
  rename Z9083100 CVC_AMT_UI_YR_06_XRND   // CVC_AMT_UI_YR.06
  rename Z9083200 CVC_AMT_UI_YR_07_XRND   // CVC_AMT_UI_YR.07
  rename Z9083300 CVC_AMT_UI_YR_08_XRND   // CVC_AMT_UI_YR.08
  rename Z9083400 CVC_AMT_UI_YR_09_XRND   // CVC_AMT_UI_YR.09
  rename Z9083401 CVC_AMT_UI_YR_10_XRND   // CVC_AMT_UI_YR.10
  rename Z9083402 CVC_AMT_UI_YR_11_XRND   // CVC_AMT_UI_YR.11
  rename Z9083403 CVC_AMT_UI_YR_12_XRND   // CVC_AMT_UI_YR.12
  rename Z9083404 CVC_AMT_UI_YR_13_XRND   // CVC_AMT_UI_YR.13
  rename Z9083405 CVC_AMT_UI_YR_14_XRND   // CVC_AMT_UI_YR.14
  rename Z9083406 CVC_AMT_UI_YR_15_XRND   // CVC_AMT_UI_YR.15
  rename Z9083407 CVC_AMT_UI_YR_16_XRND   // CVC_AMT_UI_YR.16
  rename Z9083408 CVC_AMT_UI_YR_17_XRND   // CVC_AMT_UI_YR.17
  rename Z9083409 CVC_AMT_UI_YR_18_XRND   // CVC_AMT_UI_YR.18
  rename Z9083410 CVC_AMT_UI_YR_19_XRND   // CVC_AMT_UI_YR.19
  rename Z9083411 CVC_AMT_UI_YR_20_XRND   // CVC_AMT_UI_YR.20
  rename Z9083412 CVC_AMT_UI_YR_21_XRND   // CVC_AMT_UI_YR.21
  rename Z9083413 CVC_AMT_UI_YR_22_XRND   // CVC_AMT_UI_YR.22
  rename Z9083500 CVC_AMT_UI_YR_97_XRND   // CVC_AMT_UI_YR.97
  rename Z9083600 CVC_AMT_UI_YR_98_XRND   // CVC_AMT_UI_YR.98
  rename Z9083700 CVC_AMT_UI_YR_99_XRND   // CVC_AMT_UI_YR.99
  rename Z9083800 CVC_HGC_EVER_XRND 
  rename Z9083900 CVC_HIGHEST_DEGREE_EVER_XRND 
  rename Z9084000 CVC_SCH_ATTEND_EVER_XRND 
  rename Z9084100 CVC_GED_XRND 
  rename Z9084200 CVC_HS_DIPLOMA_XRND 
  rename Z9084300 CVC_AA_DEGREE_XRND 
  rename Z9084400 CVC_BA_DEGREE_XRND 
  rename Z9084500 CVC_PROF_DEGREE_XRND 
  rename Z9084600 CVC_PHD_DEGREE_XRND 
  rename Z9084700 CVC_MA_DEGREE_XRND 
  rename Z9085100 CVC_RND_XRND 
  rename Z9085200 CVC_VET_STATUS_XRND 
  rename Z9085300 CVC_TTL_RESIDENCES_XRND 
  rename Z9085400 CVC_TTL_BIO_CHILD_XRND 
  rename Z9121900 CVC_HH_NET_WORTH_30_XRND 
  rename Z9122000 CVC_HOUSE_VALUE_30_XRND 
  rename Z9122100 CVC_HOUSE_DEBT_30_XRND 
  rename Z9122200 CVC_HOUSE_TYPE_30_XRND 
  rename Z9122300 CVC_ASSETS_FINANCIAL_30_XRND 
  rename Z9122400 CVC_ASSETS_NONFINANCIAL_30_XRND 
  rename Z9122500 CVC_ASSETS_DEBTS_30_XRND 
  rename Z9122600 CVC_ASSETS_RND_30_XRND 
  rename Z9122900 CVC_COHAB_TTL_XRND 
  rename Z9123000 CVC_MARRIAGES_TTL_XRND 
  rename Z9141400 CVC_HH_NET_WORTH_35_XRND 
  rename Z9141500 CVC_HOUSE_VALUE_35_XRND 
  rename Z9141600 CVC_HOUSE_DEBT_35_XRND 
  rename Z9141700 CVC_HOUSE_TYPE_35_XRND 
  rename Z9141800 CVC_ASSETS_FINANCIAL_35_XRND 
  rename Z9141900 CVC_ASSETS_NONFINANCIAL_35_XRND 
  rename Z9142000 CVC_ASSETS_DEBTS_35_XRND 
  rename Z9142100 CVC_ASSETS_RND_35_XRND 
  rename Z9149100 CVC_MARSTAT_COLLAPSED_XRND 
  rename Z9156500 CVC_TTL_RESIDENCES_EDT_XRND 
  rename Z9156600 CVC_GAD7_SCORE_3839_XRND 
  rename Z9156700 CVC_GRIT_SCORE_XRND 
  rename Z9164500 CVC_HH_NET_WORTH_40_XRND 
  rename Z9164700 CVC_HOUSE_VALUE_40_XRND 
  rename Z9164900 CVC_HOUSE_DEBT_40_XRND 
  rename Z9165100 CVC_HOUSE_TYPE_40_XRND 
  rename Z9165200 CVC_ASSETS_FINANCIAL_40_XRND 
  rename Z9165400 CVC_ASSETS_NONFINANCIAL_40_XRND 
  rename Z9165600 CVC_ASSETS_DEBTS_40_XRND 
  rename Z9165800 CVC_ASSETS_RND_40_XRND 

*/
  /* *end* */  
/* To convert variable names to lower case use the TOLOWER command 
 *      (type findit tolower and follow the links to install).
 * TOLOWER VARLIST will change listed variables to lower case; 
 *  TOLOWER without a specified variable list will convert all variables in the dataset to lower case
 */
/* tolower */
