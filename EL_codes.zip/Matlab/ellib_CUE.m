function [b_cue, val] = ellib_CUE(mc_f, starting_value, optimization_method, optimization_options)
% This function calculates the Continuously Updating GMM Estimator (CUE)
%
% Written by Kirill Evdokimov and Yuichi Kitamura
% This version: 02/03/2011
%
% INPUTS:
%
% Arguments 'mc_f' and 'starting_value' are required, 
%    while the other arguments are optional.
%
% Function arguments:
%
% mc_f -  should be a HANDLE(@) to the moment condition function
%    The moment condition function should return an 'obs'X'm' matrix, where
%    'obs' is the number of observations, and 'm' is the number of moment
%    conditions.
%
% starting_value - the starting parameter value for the optimization procedure
%
% optimization_method - determine what optimization procedure will
%    be used to minimize the outerloop. The following values can be used:
%       'fminunc': MATLAB's routine 'fminunc' is used (default method)
%       'fminsearch': MATLAB's routine 'fminsearch' (Nelder-Mead) is used
%       'fminsims': Chris Sims' optimization routines are used (see 'fminsims.m')
%
% optimization_options - if you want to change any optimization options 
%    of the numerical optimization methods (fminunc, fminsearch, or fminsims), such as tolerance, 
%    specify those in the 'optimization_options' using optimset() and the options will be
%    passed to the corresponding optimization routine.
%
%
% OUTPUTS:
%  b_cue - the estimated parameter value
%
%  val - the value of the criterion function at the optimum.
%        'val' is set to NaN when CUE fails to converge.
%

  
  if ( nargin<2 || nargin>4 ) error('CUE: Wrong number of parameters'); end
  if ( nargin<3 )             optimization_method = 'fminunc'; end
  if ( nargin<4 )             optimization_options = optimset(); end
    
  global cue_mc_f
  cue_mc_f = mc_f;
  b0 = starting_value(:);

  switch lower(optimization_method)
    case 'fminunc'
      [b_cue,val,exit_flag] = fminunc(@ellib_CUE_crit, b0, optimization_options);
    case 'fminsearch'      
      [b_cue,val,exit_flag] = fminsearch(@ellib_CUE_crit, b0, optimization_options);
    case 'fminsims'
      [b_cue,val,exit_flag] = fminsims(@ellib_CUE_crit, b0, optimization_options);
    otherwise
      error('CUE: Unknown optimization method (wrong value of ''optimization_method''?)');
  end
  
  if exit_flag<=0
    warning('CUE: failed to converge');
    val = NaN;
    return
  end
end

%CUE criterion function
function val = ellib_CUE_crit(beta)
  global cue_mc_f
  w = cue_mc_f(beta);
  g_bar = mean(w)';
  obs = size(w,1);
  %w = w-repmat(mean(w),obs,1);
  w_lr = w'*w/obs;
  val = obs*g_bar'*(w_lr\g_bar);
end