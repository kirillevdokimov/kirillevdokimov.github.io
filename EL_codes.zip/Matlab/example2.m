function example2()
%    
%      Example2.m - this file contains an example of use
%   of the Empirical Likelihood (EL) estimator.
%
%      This example considers minimum distance estimation of the
%   covariance structure of earnings and hours, based on 
%   Abowd and Card (1989,Ecta). The model of this example is
%   described in Section 5 of Altonji and Segal (1996,JBES). 
%   The sample consists of 1536 men, with data on changes in 
%   (log-) earnings and hours for years 1969-1979. Assuming 
%   stationarity, there are 39 parameters to estimate 
%   (hours variance, 9 hours autocovariances, earnings variance, 
%   9 earnings autocovariances, and 19 hours/earnings covariances). 
%   There are 210 moment conditions, which are coded in the function 
%   'mc_md' that can be found in the file 'example2.m'. We calculate 
%   GMM, CUE, and EL estimators.
%   
%      The data is loaded from the accompanying file 'example2_data.txt, 
%   which is obtained from the data of Altonji and Segal (1996,JBES).
%
%
%      Written by Kirill Evdokimov and Yuichi Kitamura              
%
%      This version: 02/03/2011



  fprintf('================================\n Example 2 of use of the EL codes \n\n\n');  
  load_and_prepare_the_data; % This function loads the dataset from 'psid.txt' 
            % and then transforms and prepares the data so that it is easier 
            % to calculate the moment conditions
  
  b0 = zeros(39,1); %starting value
  % There are 39 parameters in the model:
  % params(1) - hours variances
  % params(2:10) - 9 hours autocovariances
  % params(11)   - earnings variance
  % params(12:20) - 9 earnings autocovariances
  % params(21:39) - 19 hours/earnings autocovariances

  use_gmm2 = 1;
  fprintf('================================\n  GMM1 calculation starts\n');
  tic

  optimization_options = optimset('LargeScale','off', 'Display','iter'); %We turn LargeScale off since we do not supply gradient for GMM/CUE
  optimization_options = optimset(optimization_options, 'MaxFunEvals',20000,'MaxIter',20000,'TolX',1e-7,'TolFun',1e-9,'Display','iter'); 
  % GMM, CUE, and EL estimators can use three different estimation
  % procedures: MATLAB's 'fminunc' and 'fminsearch', as well as Chris Sims'
  % optimization routine wrapped in the function 'fminsims'.
  optimization_method = 'fminunc'; %You can alternatively use 'fminsims' and 'fminsearch'
  [b_gmm1,gmm1_val,b_gmm2,gmm2_val] = ellib_GMM(@mc_md, b0, optimization_method, optimization_options);
  gmm_toc = toc;
  fprintf('  Calculation of GMM1 finished\n');
  if ~isfinite(gmm1_val)
    fprintf('GMM1 failed to converge!\n');
  else
    display_results('  GMM1 Results:', b_gmm1, gmm1_val);
    b0 = b_gmm1;
  end

  if use_gmm2
    if ~isfinite(gmm2_val)
      fprintf('GMM2 failed to converge!\n');
    else
      display_results('  GMM2 Results:', b_gmm2, gmm2_val);
      b0 = b_gmm2;
    end
  end
  fprintf('Caclulation of GMM took %2.1f seconds\n', gmm_toc);
  
  use_cue = 1;
  if use_cue
    fprintf('================================\n  CUE calculation starts\n');
    tic
    [b_cue,cue_val] = ellib_CUE(@mc_md, b0, optimization_method, optimization_options);
    cue_toc = toc;
    disp('  Calculation of CUE finished');
    if ~isfinite(cue_val)
      disp('CUE failed to converge!');
    else
      display_results('  CUE Results:', b_cue, cue_val, cue_toc);
      b0 = b_cue;
    end
    fprintf('Caclulation of CUE took %2.1f seconds\n', cue_toc);
  end

  fprintf('================================\n  EL calculation starts\n');
  tic
  optimization_method = 'fminsims'; % you can alternatively use 'fminunc' and 'fminsearch',
         % but Chris Sims code appears to be both faster and more robust
  [b_el,el_val] = ellib_EL(@mc_md, b0, optimization_method, optimization_options);
  if ~isfinite(el_val)
    fprintf('EL failed to converge!\n');  % Even if EL failed to converge, 
         % the global variables 'el_best_value' and 'el_best_b' contain the best criterion 
         % function value achieved and the corresponding parameter value.
  end
  fprintf('  Calculation of EL finished\n');
  el_toc = toc;
  display_results('  EL Results:', b_el, el_val, el_toc);

  
  %Now we print all the results together:
  fprintf('\n==================================\n  All results together:\n');
  fprintf('\n  Here:\n   ''E'' stands for changes in log-Earnings,\n   ''H'' stands for changes in log-Hours,\n   and T=0,1,2 is the lag of the covariance.\n\n');
  
  
  display_results('  GMM1 Results:', b_gmm1, gmm1_val);
  if use_gmm2
    display_results('  GMM2 Results:', b_gmm2, gmm2_val);
  end
  fprintf('Caclulation of GMM took %3.1f seconds\n', gmm_toc);
  if use_cue
    display_results('  CUE Results:', b_cue, cue_val, cue_toc);
  end
  display_results('  EL Results:', b_el, el_val, el_toc);
  
  fprintf('We have 1536 observations, 210 moments, and 39 parameters\n');
  fprintf('The tests of over-identifying restrictions are distributed as chi^2 with 210-39=171 d.f. under the null\n');
  fprintf('The 90%%/95%%/99%% quantiles are: %3.1f/%3.1f/%3.1f\n', chi2inv([0.90, 0.95, 0.99] ,171));
end

function display_results(title, b, val, time_took)
%This function displays the estimated parameters in a convenient way
  fprintf('%s\n', title);
  fprintf('      LAG:           T=0     T=1     T=2\n');
  fprintf('Cov(E(t),E(t-T))   %6.3f  %6.3f  %6.3f\n',b(11),b(12),b(13));
  fprintf('Cov(H(t),H(t-T))   %6.3f  %6.3f  %6.3f\n',b(1), b(2), b(3));
  fprintf('Cov(H(t),E(t-T))   %6.3f  %6.3f  %6.3f\n',b(30),b(31),b(32));
  fprintf('Cov(E(t),H(t-T))   %6.3f  %6.3f  %6.3f\n',b(30),b(29),b(28));
  if nargin>=3
    fprintf('Over-id test: %3.1f\n', val);
  end
  if nargin==4
    fprintf('The calculation took %3.1f seconds\n', time_took);
  end
end


function load_and_prepare_the_data()
  %This function loads the dataset from 'example1_data.txt' and then transforms and
  %prepares the data so that it is easier to calculate the moment conditions
  
  %Load the data
  data = load('example2_data.txt'); %load the dataset
  if ~all(size(data)==[1536 20])
    error('Wrong dataset?!'); 
  end

  %Prepare and transform the data so that it is easier to calculate moment conditions
  global v_h v_e v_h2 v_e2 v_hA v_eA v_heA v_all
  v_h = data(:,1:10);
  v_e = data(:,11:20); %v_h and v_e are both 1536 x 10

  v_h2 = v_h.^2; 
  v_e2 = v_e.^2;

  v_hA = []; 
  v_eA = []; 
  for i=2:10
    for j=1:(i-1)
      v_hA = [v_hA v_h(:,i).*v_h(:,j)]; %#ok<AGROW>
      v_eA = [v_eA v_e(:,i).*v_e(:,j)]; %#ok<AGROW>
    end  
  end

  v_heA = [];
  for i=1:10
    for j=1:10;
      v_heA = [v_heA v_h(:,i).*v_e(:,j)]; %#ok<AGROW>
    end  
  end

  v_all = [v_h2 v_e2 v_hA v_eA v_heA];

  if ~all(size(v_all)==[1536 210])
    error('PSID moment conditions: ivalid size, something is wrong!'); 
  end
  fprintf('We have 1536 observations, 210 moments, and 39 parameters\n');
end

function w = mc_md(params)
  % Moment conditions for PSID data in Altonji-Segal(1996)
  %
  % This is a set of moment conditions for PSID data as described in
  % Altonji-Segal(1996)(see also Abowd and Card, 1987).
  % 
  % Params includes 39 parameters:
  % params(1) - hours variances
  % params(2:10) - 9 hours autocovariances
  % params(11) - 9 earnings variance
  % params(12:20) - 9 earnings autocovariances
  % params(21:39) - 19 hours/earnings autocovariances
  %

  if length(params)~=39
    error('Incorrect number of parameters!');
  end


  % Here the moment conditions start. They rely on the correct order of
  % the data in v_all.
  global v_all
  if ~all(size(v_all)==[1536 210])
    error('PSID moment conditions: ivalid size!'); 
  end


  h_var = params(1);      % params(1) - hours variances
  h_cov = params(2:10);  % params(2:10) - 9 hours autocovariances
  e_var = params(11);     % params(11) - earnings variance
  e_cov = params(12:20); % params(12:20) - 9 earnings autocovariances
  he_cov = params(21:39); % params(21:39) - 19 hours/earnings autocovariances

  index = 1; %current moment condition number we are dealing with

  w = v_all;

  %hours covariance
  for i=1:10
    w(:,index) = w(:,index)-h_var;
    index = index+1;
  end

  % earnings covariance
  for i=1:10
    w(:,index) = w(:,index)-e_var;
    index = index+1;
  end

  % hours autocovariances
  s = 1;
  for i=2:10
    for j=1:(i-1)
      w(:,index) = w(:,index)-h_cov(i-j);
      index = index+1; 
    end  
  end

  % earnings autocovariances
  s = 1;
  for i=2:10
    for j=1:(i-1)
      w(:,index) = w(:,index)-e_cov(i-j);
      index = index+1; 
    end  
  end

  % hours/earnings covariances
  % eh_cov(t) = Cov(HOURS(j),EARNINGS(j+10+t)) where t can run from -9 to 9
  for i=1:10
    for j=1:10
      w(:,index) = w(:,index)-he_cov(10+i-j); 
      index = index+1; 
    end  
  end

  if index~=210+1
    error('Incorrect number of momemnts! Check the implementation!');
  end
end

