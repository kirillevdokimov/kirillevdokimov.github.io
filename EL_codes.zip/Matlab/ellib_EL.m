function [b_res,el_val] = ellib_EL(mc_f, starting_value, ...
                    optimization_method, optimization_options, use_quick_grad, block_length, block_shift)

% This function calculates the Empirical Likelihood estimator (EL)
%
% Written by Kirill Evdokimov and Yuichi Kitamura
% This version: 02/03/2011
%
% INPUTS:
%
% Arguments 'mc_f' and 'starting_value' are required, 
%    while the other arguments are optional.
%
% Function arguments:
%
% mc_f should be a HANDLE(@) to the moment condition function
%    The moment condition function should return an 'obs'X'm' matrix, where
%    'obs' is the number of observations, and 'm' is the number of moment
%    conditions.
%
% starting_value - the starting parameter value for the optimization procedure
%
% optimization_method - determine what optimization procedure will
%    be used to minimize the outerloop. The following values can be used:
%       'fminunc': MATLAB's routine 'fminunc' is used (default method)
%       'fminsearch': MATLAB's routine 'fminsearch' (Nelder-Mead) is used
%       'fminsims': Chris Sims' optimization routines are used (see 'fminsims.m')
%
% optimization_options - if you want to change any optimization options 
%    of the numerical optimization methods (fminunc, fminsearch, or fminsims), such as tolerance, 
%    specify those in the 'optimization_options' using optimset() and the options will be
%    passed to the corresponding optimization routine.
%
% use_quick_grad - when nonzero a quick method of calculation of the gradient of the 
%   outerloop criterion function is used. The idea is to use the envelope theorem, which 
%   allows calculating the gradient of the outerloop without re-evaluating the innerloop. 
%   This option improves the speed of the algorithm, but sometimes appears to cause 
%   instabilities of the numerical optimization procedures. 
%   By default use_quick_grad = 1 and the the quick gradient method is used.
%
% block_length - blocked empirical likelihood (see Kitamura 1997) when block_length>1. 
%   This option should be used when dealing with time-series data. 
%   When the data are i.i.d., one should have block_length=1, which is the default value. 
%
% block_shift - is used for blocked EL, see Kitamura (1997). 
%   By default block_shift = 1.
%
% 
% OUTPUTS:
%  b_res - the estimator value
%
%  el_val - the value of the criterion function at the optimum.
%           The value of el_val is set to NaN when EL fails to converge.
%


   
  if nargin<2 error('EL: Too few arguments'); end
  if nargin>7 error('EL: Too many arguments'); end
  if nargin<7 block_shift = 1; end
  if nargin<6 block_length = 1; end %by default we compute the standard EL (i.e. not blocked)
  if nargin<5 use_quick_grad = 1; end %by default we use quick calculation of the gradient, which relies on the envelope theorem.
                       %This method may cause problems when optimization
                       %approaches the boundary of the area where the
                       %innerloop converges.
  if nargin<4 optimization_options = optimset; end
  if nargin<3 optimization_method = 'fminsims'; end
  
  global el_f el_block_length el_block_shift
  global el_output %#ok<NUSED> %use for debugging; this allows you access the output of the optimization procedure
  el_f = mc_f;
  el_block_length = block_length;
  el_block_shift = block_shift;

  
  global el_best_value el_best_b %'el_best_value' and 'el_best_b' always contain the best value achived
                              % in the outerloop and the corresponding parameter value.
                              % These can be used if optimization fails. 
  el_best_value = realmax; %initializing
  el_best_b = NaN; %initializing
  
  global el_last_value el_last_b %the last value and the parameter for which the innerloop was calculated
  el_last_value = realmax; %initializing
  el_last_b = NaN; %initializing
  
  %we try the starting value
  b0 = starting_value(:);    
  el_val_b0 = ellib_EL_crit(b0);
  if ~isfinite(el_val_b0) || (el_val_b0>=sqrt(realmax)) %innerloop diverges at the starting value
    warning('EL: Innerloop diverged at the stating_value.\nPlease supply another starting value.');
    el_val = NaN;
    b_res = NaN(size(b0));
    return
  end
                              
  if use_quick_grad
    optimization_options = optimset(optimization_options,'GradObj','on'); %We calculate gradient
      % together with the function value at a point using nested feature of
      % the problem. This greatly improves the speed of the algorithm.
  else
    optimization_options = optimset(optimization_options,'GradObj','off');
  end
  
  switch lower(optimization_method)
    case 'fminsearch'
      fprintf('Using *fminsearch* (Nelder-Mead) to minimize the outerloop\n');
      [b_res,el_val,exit_flag] = fminsearch(@ellib_EL_crit,b0, optimization_options);
    case 'fminunc'
      fprintf('Using *fminunc* to minimize the outerloop\n');
      [b_res,el_val,exit_flag] = fminunc(@ellib_EL_crit,b0,optimization_options);
    case 'fminsims'
      fprintf('Using *Chris Sims'' codes* to minimize the outerloop\n');
      [b_res,el_val,exit_flag] = fminsims(@ellib_EL_crit,b0,optimization_options);
    otherwise
      error('EL: Unknown optimization method (wrong value of ''optimization_method''?)');
  end
  
  if exit_flag<=0
    warning('EL: Outerloop minimization procedure failed to converge!');
    el_val = NaN;
  end
end



