function [elval, grad_innerloop]= ellib_EL_crit(b)
% This function calculates the value of the EL criterion function at
% point 'b' by maximizing the value of the "innerloop". This function is
% also able to calculate the gradient of the EL criterion using the
% envelope theorem and without recalculating the value of the "innerloop".
%
% This function can only be called after function ellib_EL has been
% called, because ellib_EL initializes the necessary global parameters,
% including the moment condition function ('el_f').
%
% Written by Kirill Evdokimov and Yuichi Kitamura
% This version: 02/03/2011
  
  
  if nargout>2
    error('EL:outerloop: Hessian is not calculated by this function!');
  end

  el_use_two_sided_moment_gradient = 1; %when nonzero two sided 
                      %numerical gradient calculation is performed
  
  global el_f %Moment condition function handle. Should be specified in advance.
  global el_block_length el_block_shift %Block construction parameters (length 
    %and shift). Should be specified in advance.
  global el_best_value el_best_b %'el_best_value' and 'el_best_b' always contain the best value achived
                              % in the outerloop and the corresponding parameter value.
                              % These can be used if optimization fails.
  global el_last_value el_last_b %the last value and the parameter for which the innerloop was calculated
  
  mc_at_b = el_f(b);
  obs = size(mc_at_b,1); %number of observations
  if el_block_length>1 %make the moment conditions blocked, if needed
    mc_at_b = ellib_make_block_mc(mc_at_b, el_block_length, el_block_shift);
  end
  
  if all(isfinite(el_last_b)) && max(abs(el_last_b(:)-b(:)))<eps(1.0)
    elval = el_last_value; %no need to recalculate the innerloop
  else
    elval = ellib_innerloop(mc_at_b); %performing the innerloop optimization
    el_last_b = b;
    el_last_value = elval;
  end
  
  if (~isfinite(elval)) || (elval>=sqrt(realmax)) %innerloop failed to converge at the point
    elval = sqrt(realmax); %the innerloop diverged, so we return "infinity"!
    if nargout>1 %we are asked to calculate the gradient
      grad_innerloop = zeros(length(b),1); %This is done because of the way fminunc works
    end
    return
  end 

  if el_block_length>1 
    correction = obs/(el_block_length*(floor((obs-el_block_length)/el_block_shift)+1)); %Multiplier that corrects for the fact that we use blocked moment conditions, see Kitamura (1997)
    elval = correction*elval;
  else
    correction = 1; %is needed when we calculate gradient
  end

  if elval<el_best_value %update the best value and the corresponding parameter value
    el_best_value = elval;
    el_best_b = b;
  end  
  
  global el_prob el_lambda
  if nargout>1  %we are asked to calculate the gradient 
    grad_innerloop = zeros(length(b),1);
    if el_block_length>1 %make the moment conditions blocked, if needed
      processed_mc = @(beta) (ellib_make_block_mc(el_f(beta), el_block_length, el_block_shift));
    else
      processed_mc = @(beta) (el_f(beta));
    end
    for i=1:length(b)
      param = [zeros(i-1,1); 1; zeros(length(b)-i,1)];
      delta = 1e-6;
      mc_at_plus = processed_mc(b+delta*param);
      if el_use_two_sided_moment_gradient
        mc_at_minus = processed_mc(b-delta*param);
        grad_innerloop(i,1) = correction*2*el_prob'*(mc_at_plus-mc_at_minus)/(2*delta)*el_lambda;
      else
        grad_innerloop(i,1) = correction*2*el_prob'*(mc_at_plus-mc_at_b)/delta*el_lambda;
      end
    end
  end
end


function elval = ellib_innerloop(w)
  %ellib_innerloop: calculates EL innerloop,
  % parameter 'w' should be <moment_conditions evaluated at some b>

  global el_prob el_lambda % the 'probabilities' and lambda vector will be 
                           % stored here if the innerloop converges  

  % tuning parameters:
  
  el_printdiag = 0; %ellib_innerloop function prints information messages 
      %when this parameter is nonzero. Otherwise only warnings and errors
      %are displayed.
  
  el_max_innerloop_iterations = 100; %maximum number of iterations
       % in the innerloop before it returns "Failed to converge". 


  el_tolerance_grad_direc = 1e-7; %stopping tolerance to determine whether innerloop converged

  el_min_step_mul = 0.001; %minimum multiplier of the direction vector
  
  el_max_moment_val = 1e10; %if any number among moment values 
    % (i.e. in w) is bigger than this in absolute value, we report
    % divergence of the innerlooop. This is an important parameter that
    % depends on the problem. Making this too large may lead to
    % numerical instability of the innerloop optimization algorithm (the
    % 'direc' matrix may be badly conditioned, which would lead to a bad
    % behavior of 'direc = direc\grad;' line below

  if ellib_isbig(w,el_max_moment_val) %if the values of moment conditions are 'too big'
            %there will be nummerical problems inverting 'direc' matrix, see above
    elval=NaN;
    return
  end

  [n,cols] = size(w);  
  
  grad_tmp = zeros(n,cols);  

  lam = zeros(cols,1);
  testmax = .999999*n;
  iter = 1; 
  while iter <=el_max_innerloop_iterations;
    if el_printdiag ~= 0
      fprintf(1, 'EL innerloop: iteration %d\n', iter);
    end
    el_prob = 1./(1+w*lam);

    for j=1:cols
      grad_tmp(:,j) = el_prob.*w(:,j);
    end
    direc = grad_tmp'*grad_tmp;    
    grad = -sum(grad_tmp)';
  
    if ~ellib_isbig(direc,sqrt(realmax)) && ~ellib_isbig(grad,sqrt(realmax))
      if rcond(direc)<1000*eps
        warning('EL-innerloop: rcond = %g\n', rcond(direc));
      end
      direc = direc\grad;
      test = grad'*direc;  
    else
      test = testmax + 1; %set the convergence criterion too large
    end
        
    if test > testmax
      if el_printdiag
        fprintf(1, 'EL innerloop failed to converge (zero is not in the convex hull?)\n');
      end
      elval = NaN;      
      return
    end
  
    if test <= el_tolerance_grad_direc;
      elval = - 2*sum(log(el_prob));
      el_lambda = lam;
      return
    end

    lik = sum(log(el_prob));
    step = 1;    
    improved = 0;

    while step >= el_min_step_mul && improved == 0;
      lamtry = lam - step*direc;
      el_prob = 1.0 + (w*lamtry);    
      if any(el_prob <= 0) == 0 && sum(-log(el_prob)) < lik;
        %checked positivity and that the criterion got smaller
        improved = 1;
        lam = lamtry;
      else
        step = step/2;
      end       
    end;
    if improved==0
      if el_printdiag
        fprintf(1, 'EL innerloop: stepsize failed to find increase\n');
      end
      elval = NaN; 
      return
    end    
    iter = iter + 1;
  end

  if el_printdiag
    fprintf(1, 'EL innerloop: Maximum iterations reached\n');
  end

  elval = NaN;
end


function b_w = ellib_make_block_mc(w, block_len, block_shift)
  %ellib_make_block_mc: Constructs blocked moment conditions

  if block_len==1
    b_w = w;
    return
  end

  [iid_N, m] = size(w);
  b_N = ceil((iid_N-block_len+1)/block_shift);
  b_w = zeros(b_N,m);

  for i=1:b_N
    %summation can be done faster using the running sum add/subtact trick, but the
    %precision maybe an issue, so we stick to the straightforward way
    b_w(i,:)=sum(w((i-1)*block_shift+1 : (i-1)*block_shift+block_len,:));
  end
end

function ib = ellib_isbig(x, maxvalue)
  % ellib_isbig: returns zero if all elements of X are finite and abs(x)<maxvalue,
  % nonzero otherwise 
  ib = any(~isfinite(x(:))) || any(abs(x(:))>=maxvalue);
end
