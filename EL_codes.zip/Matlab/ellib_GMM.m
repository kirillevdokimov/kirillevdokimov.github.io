function [b_gmm1, val1, b_gmm2, val2] = ellib_GMM(mc_f, starting_value, optimization_method, optimization_options)
% Calculates one and two step GMM
%
% Written by Kirill Evdokimov and Yuichi Kitamura
% This version: 02/03/2011
%
% INPUTS:
%
% Arguments 'mc_f' and 'starting_value' are required, 
%    while the other arguments are optional.
%
% Function arguments:
%
% mc_f should be a HANDLE(@) to the moment condition function
%    The moment condition function should return an 'obs'X'm' matrix, where
%    'obs' is the number of observations, and 'm' is the number of moment
%    conditions.
%
% starting_value - the starting parameter value for the optimization procedure
%
% optimization_method - determine what optimization procedure will
%    be used to minimize the outerloop. The following values can be used:
%       'fminunc': MATLAB's routine 'fminunc' is used (default method)
%       'fminsearch': MATLAB's routine 'fminsearch' (Nelder-Mead) is used
%       'fminsims': Chris Sims' optimization routines are used (see 'fminsims.m')
%
% optimization_options - if you want to change any optimization options 
%    of the numerical optimization methods (fminunc, fminsearch, or fminsims), such as tolerance, 
%    specify those in the 'optimization_options' using optimset() and the options will be
%    passed to the corresponding optimization routine.
%
%
%  This function calculates two step GMM only if the number of output arguments is bigger than two.
%
%
% OUTPUTS:
%  b_gmm1 - the estimated one step GMM (GMM1) parameter value (starting with identity weighting matrix)
%
%  val1 - the value of the criterion function at the optimum.
%        'val' is set to NaN when GMM1 fails to converge.
%
%  b_gmm2 - the estimated two step GMM (GMM2) parameter value
%
%  val2 - the value of the criterion function at the optimum.
%        'val' is set to NaN when GMM2 fails to converge.
%
 
  
  global weighting_matrix gmm_mc_f
  gmm_mc_f = mc_f;
  weighting_matrix = 1; %1st step gmm
  b0 = starting_value(:);

  if ( nargin<2 || nargin>4 ) error('GMM: Wrong number of parameters'); end
  if ( nargin<4 )             optimization_options = optimset(); end
  if ( nargin<3 )             optimization_method = 'fminunc'; end 
  if ( nargout>2)             run2step = 1; end 
 
  switch lower(optimization_method)
    case 'fminsearch'      
      [b_gmm1,val1,exit_flag] = fminsearch(@ellib_GMM_crit, b0, optimization_options);
    case 'fminunc'
      [b_gmm1,val1,exit_flag] = fminunc(@ellib_GMM_crit, b0, optimization_options);
    case 'fminsims'
      [b_gmm1,val1,exit_flag] = fminsims(@ellib_GMM_crit, b0, optimization_options);
    otherwise
      error('GMM1: Unknown optimization method (wrong value of ''optimization_method''?)');
  end
  
  if exit_flag<=0
    warning('GMM1 failed to converge');
      val1 = NaN;
      b_gmm2 = NaN;
      val2 = NaN;
    return
  end

  if run2step
    w = gmm_mc_f(b_gmm1);
    obs = size(w,1);
    %w = w - repmat(mean(w),obs,1);
    weighting_matrix = inv(w'*w/obs);  

    switch lower(optimization_method)
      case 'fminsearch'      
        [b_gmm2,val2,exit_flag2] = fminsearch(@ellib_GMM_crit, b_gmm1, optimization_options);
      case 'fminunc'
        [b_gmm2,val2,exit_flag2] = fminunc(@ellib_GMM_crit, b_gmm1,optimization_options);
      case 'fminsims'
        [b_gmm2,val2,exit_flag2] = fminsims(@ellib_GMM_crit, b_gmm1, optimization_options);
      otherwise
        error('GMM2: Unknown optimization method (wrong value of ''optimization_method''?)');
    end

    if exit_flag2<=0
      warning('GMM2 failed to converge (but GMM1 has converged)');
      val2 = NaN;
      return
    end
  else
    b_gmm2 = NaN;
    val2 = NaN;
  end
end

function val = ellib_GMM_crit(beta)
  %Criterion function used by the 'ellib_GMM' function

  global weighting_matrix gmm_mc_f %the weighting matrix
  
  w = gmm_mc_f(beta);
  g_bar = mean(w)';
  val = size(w,1)*g_bar'*weighting_matrix*g_bar;
end

