function example1()
%    
%      Example1.m - this file contains an example of use
%   of the Empirical Likelihood (EL) estimator.
%
%      This example estimates a dynamic panel model of earnings.    
%   The data are taken from Altonji and Segal (1996, JBES).    
%   The moment conditions are DIFF and SYS moment conditions   
%   from Blundell and Bond (1998,JOE). The example calculates  
%   GMM, CUE, and EL estimators. This example is very similar 
%   to an example in Imbens (2002, JBES), although a slightly
%   different dataset is used. 
%
%      The model is E_{i,t} = theta * E_{i,t-1} + eta_{i} + eps_{i,t}, where
%   E_{i,t}=log(Earnings_{i,t}), 'theta' is the autoregressive parameter 
%   of interest, eta_{i} is the fixed effect, eps_{i,t} is the idiosincratic shock.
%
%      The data is loaded from the accompanying file 'example1_data.txt, 
%   which is obtained from the data of Altonji and Segal (1996,JBES).
%
%
%      Written by Kirill Evdokimov and Yuichi Kitamura              
%
%      This version: 02/03/2011                                     
%


  fprintf('================================\n Example 1 of use of the EL codes \n\n\n');
  load_and_prepare_the_data;
  
  b0 = 0;
  fprintf('================================  GMM1 calculation starts\n');
  tic
  optimization_options = optimset('LargeScale','off', 'Display','iter'); %We turn LargeScale off since we do not supply gradient for GMM/CUE
  optimization_options = optimset(optimization_options, 'MaxFunEvals',20000,'MaxIter',20000,'TolX',1e-5,'TolFun',1e-7,'Display','iter');
  
  
  % GMM, CUE, and EL estimators can use three different estimation
  % procedures: MATLAB's 'fminunc' and 'fminsearch', as well as Chris Sims'
  % optimization routine wrapped in the function 'fminsims'.
  
  optimization_method = 'fminunc'; %You can alternatively use 'fminsims' and 'fminsearch'
  
  [b_gmm1,gmm1_val,b_gmm2,gmm2_val] = ellib_GMM(@mc_dp, b0, optimization_method, optimization_options);
  gmm_toc = toc;
  fprintf('  Calculation of GMM1 finished\n');
  if ~isfinite(gmm1_val)
    fprintf('GMM1 failed to converge!\n');
  else
    fprintf('GMM1: theta = %2.2f, val = %3.2f\n',b_gmm1, gmm1_val);
    b0 = b_gmm1;
    if ~isfinite(gmm2_val)
      fprintf('GMM2 failed to converge!\n');
    else
      fprintf('GMM2: theta = %2.2f, val = %3.2f\n',b_gmm2, gmm2_val);
      b0 = b_gmm2;
    end
  end
  
  fprintf('Caclulation of GMM took %2.1f seconds\n', gmm_toc);

  use_cue = 1;
  if use_cue
    fprintf('================================\n  CUE calculation starts\n');
    tic
    [b_cue,cue_val] = ellib_CUE(@mc_dp, b0, optimization_method, optimization_options);
    cue_toc = toc;
    fprintf('  Calculation of CUE finished\n');
    if ~isfinite(cue_val)
      fprintf('CUE failed to converge!\n');
    else
      fprintf('CUE : theta = %2.2f, val = %3.2f\n',b_cue, cue_val);
      b0 = b_cue;
    end
    fprintf('Caclulation of CUE took %2.1f seconds\n', cue_toc);
  end

  fprintf('================================\n  EL calculation starts\n');
  tic
  
  [b_el,el_val] = ellib_EL(@mc_dp, b0, optimization_method, optimization_options);
  if ~isfinite(el_val)
    fprintf('EL failed to converge!\n');
  end
  fprintf('  Calculation of EL finished\n');
  el_toc = toc;
  fprintf('EL  : theta = %2.2f, val = %3.2f\n', b_el, el_val);
  fprintf('Caclulation of EL took %2.1f seconds\n', el_toc);
  
  
  %Now we print all the results together:
  fprintf('\n==================================\nAll results together:\n');
  fprintf('GMM1: theta = %2.2f, val = %3.2f\n',b_gmm1, gmm1_val);
  fprintf('GMM2: theta = %2.2f, val = %3.2f\n',b_gmm2, gmm2_val);
  fprintf('CUE : theta = %2.2f, val = %3.2f\n',b_cue, cue_val);
  fprintf('EL  : theta = %2.2f, val = %3.2f\n',b_el, el_val);

  
  plot_criterion_function = 1;
  if plot_criterion_function
  
    fprintf('\nPreparing the plot of EL criterion function\n');
    % Plot the criterion function
    
    plot_grid = [0:0.01:0.34 0.35:0.001:0.50 0.51:0.01:1.0]; 
    % If you change the above to -1:0.01:1, you will see that the innerloop
    % fails to converge for b < -0.4. See the discussion in the 'description.txt'
    
    plot_vals = zeros(length(plot_grid),1);
    for i=1:length(plot_grid)
      if mod(i,10)==1
        fprintf('Current b = %3.2f, %2d out of %3d points.\n', plot_grid(i), i, length(plot_grid));
      end
      el_val_plot = ellib_EL_crit(plot_grid(i));
      if isfinite(el_val_plot) && el_val_plot<sqrt(realmax)
        plot_vals(i) = el_val_plot; 
      else %the elval is NaN when the innerloop diverges. The innerloop 
         %diverges when zero is not in the convex hull of the moment conditions.
        plot_vals(i) = -1;
      end
    end
    fprintf('Done calculating. Now plotting...\n');
    newplot;
    hold on
    %plot only the points where the innerloop converged
    plot(plot_grid(plot_vals>=0),plot_vals(plot_vals>=0),'-ko','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',3,'LineWidth',1); 

    %We may also calculate the the Confidence Interval for the parameter by
    %  inverting the criterion function:

    %plot the points corresponding to the 95% confidence interval
    ci_points = (plot_vals<el_val+chi2inv(0.95, 1)) & (plot_vals>=0);
    plot(plot_grid(ci_points),plot_vals(ci_points),'-ko','MarkerEdgeColor','r','MarkerFaceColor','r','MarkerSize',3,'LineWidth',1); 
    ci_left  = min(plot_grid(ci_points));
    ci_right = max(plot_grid(ci_points));
    fprintf('95%% EL confidence interval is (%1.3f,%1.3f)\n', ci_left, ci_right); %Please note, that 
       % in general EL confidence intervals may not have the simple form, and
       % may consist of a union of intervals.

    if any(plot_vals<0)%show the parameter values for which the innerloop failed to converge
      plot(plot_grid(plot_vals<0),plot_vals(plot_vals<0),'-ko','MarkerEdgeColor','b','MarkerFaceColor','b','MarkerSize',3);
      legend('Critreion Function', 'Confidence Interval', 'Innerloop failed to converge');
    else
      legend('Critreion Function', 'Confidence Interval');
    end
    hold off
  end

  fprintf('\n==================================\nAll results together:\n');
  fprintf('GMM1: theta = %2.2f, val = %3.1f\n',b_gmm1, gmm1_val);
  fprintf('GMM2: theta = %2.2f, val = %3.1f\n',b_gmm2, gmm2_val);
  fprintf('CUE : theta = %2.2f, val = %3.1f\n',b_cue, cue_val);
  fprintf('EL  : theta = %2.2f, val = %3.1f\n',b_el, el_val);
  fprintf('95%% EL confidence interval is (%1.3f,%1.3f)\n', ci_left, ci_right);
  
  fprintf('\nCaclulation of GMM took %2.2f seconds\n', gmm_toc);
  fprintf('Caclulation of CUE took %2.2f seconds\n', cue_toc);
  fprintf('Caclulation of EL took %2.2f seconds\n', el_toc);
end

function load_and_prepare_the_data()
  % This function loads the data from 'example2_data.txt' and then prepares them
  %   for the moment condition function mc_dp. The data are a PSID extract, obtained by
  %   Alronji and Segal (1996).

  global v_y v_dy maxT obs
  obs = 1536;
  maxT = 11;
  data = load('example1_data.txt'); %dataset filename
  if ~all(size(data)==[obs maxT])
    error('Data has wrong size! Is it a wrong file?'); 
  end
  
  v_y = log(data(:,1:maxT)); %log of earnings data
  means_v_y = mean(v_y); %demean the data
  v_y = v_y - repmat(means_v_y,obs,1);
  v_dy(:,2:maxT) = v_y(:,2:maxT)-v_y(:,1:maxT-1);
  
  fprintf('There are 1536 observation, 54 moment conditions, and one parameter\n');
end

function mc = mc_dp(theta)
  % These are moment conditions for dynamic panel from Blundell and Bond
  % (1998), that are used to estimate the autoregressive parameter. The
  % intercept and time effects are not estimated since the data were
  % demeaned in advance.
  
  global v_y v_dy maxT obs %these variables were prepared by 'prepare_data()'
  numofmoments = (maxT-1)*(maxT-2)/2+(maxT-2);
  mc_i = 1; %moment condition index    
  mc = zeros(obs,numofmoments); %moment conditions

  for j = 3:maxT %DIF moment conditions
      de = v_dy(:,j)-theta*v_dy(:,j-1);
      for s = 1:j-2
          mc(:,mc_i)=v_y(:,s).*de;
          mc_i = mc_i+1;
      end    
  end
  
  for j = 2:maxT  %SYS moment conditions
      w = v_y(:,j)-theta*v_y(:,j-1);
      if j>=3
        mc(:,mc_i)=v_dy(:,j-1).*w;
        mc_i = mc_i+1;
      end
  end
end
